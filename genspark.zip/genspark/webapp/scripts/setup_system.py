#!/usr/bin/env python3
"""
Comprehensive System Setup Script

This script initializes the entire RL Document Summarization system,
including dependencies, services, models, and configurations.
"""

import os
import sys
import subprocess
import time
import json
import requests
import argparse
from pathlib import Path
from typing import Dict, Any, List, Optional
import shutil
import tempfile

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root))

from configs.app_config import get_config
from configs.logging_config import setup_logging, get_logger


class Colors:
    """Terminal color codes"""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'


class SystemSetup:
    """Main system setup class"""
    
    def __init__(self, environment: str = "development", skip_gpu: bool = False):
        self.environment = environment
        self.skip_gpu = skip_gpu
        self.config = get_config(environment)
        self.logger = get_logger("setup")
        
        # Setup directories
        self.project_root = project_root
        self.data_dir = self.project_root / "data"
        self.models_dir = self.project_root / "models"
        self.logs_dir = self.project_root / "logs"
        
        # Service status tracking
        self.services_status = {
            'redis': False,
            'ollama': False,
            'huggingface': False,
            'groq_api': False
        }
        
        print(f"{Colors.BOLD}{Colors.BLUE}🚀 RL Document Summarization System Setup{Colors.END}")
        print(f"{Colors.CYAN}Environment: {environment}{Colors.END}")
        print(f"{Colors.CYAN}Project Root: {self.project_root}{Colors.END}")
        print("-" * 60)
    
    def print_step(self, message: str, step_num: int = None):
        """Print a setup step message"""
        if step_num:
            print(f"\n{Colors.BOLD}{Colors.YELLOW}📋 Step {step_num}: {message}{Colors.END}")
        else:
            print(f"\n{Colors.BOLD}{Colors.GREEN}✅ {message}{Colors.END}")
    
    def print_error(self, message: str):
        """Print an error message"""
        print(f"{Colors.BOLD}{Colors.RED}❌ {message}{Colors.END}")
    
    def print_warning(self, message: str):
        """Print a warning message"""
        print(f"{Colors.BOLD}{Colors.YELLOW}⚠️  {message}{Colors.END}")
    
    def print_info(self, message: str):
        """Print an info message"""
        print(f"{Colors.CYAN}ℹ️  {message}{Colors.END}")
    
    def run_command(self, command: str, cwd: Path = None, capture_output: bool = False) -> Optional[str]:
        """Run a shell command with error handling"""
        try:
            if cwd is None:
                cwd = self.project_root
            
            if capture_output:
                result = subprocess.run(
                    command, 
                    shell=True, 
                    cwd=cwd, 
                    capture_output=True, 
                    text=True,
                    timeout=300  # 5 minute timeout
                )
                if result.returncode == 0:
                    return result.stdout.strip()
                else:
                    self.print_error(f"Command failed: {command}")
                    self.print_error(f"Error: {result.stderr}")
                    return None
            else:
                result = subprocess.run(command, shell=True, cwd=cwd)
                return str(result.returncode == 0)
        
        except subprocess.TimeoutExpired:
            self.print_error(f"Command timed out: {command}")
            return None
        except Exception as e:
            self.print_error(f"Command execution failed: {e}")
            return None
    
    def check_python_version(self):
        """Check Python version compatibility"""
        self.print_step("Checking Python version", 1)
        
        version = sys.version_info
        if version.major == 3 and version.minor >= 9:
            self.print_info(f"Python {version.major}.{version.minor}.{version.micro} ✅")
        else:
            self.print_error(f"Python 3.9+ required, found {version.major}.{version.minor}")
            sys.exit(1)
    
    def create_directories(self):
        """Create necessary directories"""
        self.print_step("Creating project directories", 2)
        
        directories = [
            self.data_dir / "uploads",
            self.data_dir / "embeddings",
            self.data_dir / "episodes",
            self.models_dir / "checkpoints",
            self.models_dir / "cache",
            self.models_dir / "logs",
            self.logs_dir,
            self.project_root / "configs" / "ssl",
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)
            self.print_info(f"Created: {directory}")
    
    def check_and_install_dependencies(self):
        """Check and install Python dependencies"""
        self.print_step("Installing Python dependencies", 3)
        
        # Install main requirements
        self.print_info("Installing main requirements...")
        result = self.run_command("pip install -r requirements.txt")
        if not result or result == "False":
            self.print_error("Failed to install main requirements")
            return False
        
        # Install backend requirements
        backend_req = self.project_root / "backend" / "requirements.txt"
        if backend_req.exists():
            self.print_info("Installing backend requirements...")
            result = self.run_command(f"pip install -r {backend_req}")
            if not result or result == "False":
                self.print_error("Failed to install backend requirements")
                return False
        
        # Install frontend requirements
        frontend_req = self.project_root / "frontend" / "requirements.txt"
        if frontend_req.exists():
            self.print_info("Installing frontend requirements...")
            result = self.run_command(f"pip install -r {frontend_req}")
            if not result or result == "False":
                self.print_error("Failed to install frontend requirements")
                return False
        
        # Install PyTorch (with or without CUDA)
        if not self.skip_gpu and self.check_cuda_availability():
            self.print_info("Installing PyTorch with CUDA support...")
            torch_cmd = "pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118"
        else:
            self.print_info("Installing PyTorch (CPU only)...")
            torch_cmd = "pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu"
        
        result = self.run_command(torch_cmd)
        if not result or result == "False":
            self.print_warning("PyTorch installation may have issues, continuing...")
        
        return True
    
    def check_cuda_availability(self) -> bool:
        """Check if CUDA is available"""
        try:
            result = self.run_command("nvidia-smi", capture_output=True)
            return result is not None
        except:
            return False
    
    def setup_environment_file(self):
        """Setup environment variables file"""
        self.print_step("Setting up environment file", 4)
        
        env_file = self.project_root / ".env"
        env_example = self.project_root / ".env.example"
        
        if not env_file.exists() and env_example.exists():
            shutil.copy(env_example, env_file)
            self.print_info("Created .env from .env.example")
        
        # Check for required environment variables
        required_vars = ["GROQ_API_KEY", "HUGGING_FACE_TOKEN"]
        missing_vars = []
        
        if env_file.exists():
            with open(env_file, 'r') as f:
                content = f.read()
                for var in required_vars:
                    if f"{var}=" not in content or f"{var}=your_" in content:
                        missing_vars.append(var)
        
        if missing_vars:
            self.print_warning(f"Please set the following environment variables in .env:")
            for var in missing_vars:
                print(f"  - {var}")
    
    def check_redis_service(self):
        """Check Redis service availability"""
        self.print_step("Checking Redis service", 5)
        
        try:
            import redis
            redis_url = self.config.database.redis_url
            r = redis.from_url(redis_url)
            r.ping()
            self.print_info("Redis connection successful ✅")
            self.services_status['redis'] = True
        except Exception as e:
            self.print_warning(f"Redis not available: {e}")
            self.print_info("You can start Redis with: redis-server")
    
    def check_ollama_service(self):
        """Check Ollama service availability"""
        self.print_step("Checking Ollama service", 6)
        
        try:
            ollama_host = self.config.model.ollama_host
            response = requests.get(f"{ollama_host}/api/tags", timeout=10)
            if response.status_code == 200:
                self.print_info("Ollama service is running ✅")
                self.services_status['ollama'] = True
                
                # Check if embedding model is available
                self.check_ollama_embedding_model()
            else:
                raise requests.RequestException("Service not responding")
        except Exception as e:
            self.print_warning(f"Ollama not available: {e}")
            self.print_info("You can start Ollama with: ollama serve")
    
    def check_ollama_embedding_model(self):
        """Check and pull Ollama embedding model"""
        try:
            model_name = self.config.model.ollama_model
            self.print_info(f"Checking embedding model: {model_name}")
            
            # Try to pull the model
            result = self.run_command(f"ollama pull {model_name}", capture_output=True)
            if result:
                self.print_info(f"Embedding model {model_name} ready ✅")
            else:
                self.print_warning(f"Could not pull model {model_name}")
        except Exception as e:
            self.print_warning(f"Error with embedding model: {e}")
    
    def check_api_keys(self):
        """Check API key validity"""
        self.print_step("Validating API keys", 7)
        
        # Check Groq API key
        groq_key = self.config.model.groq_api_key
        if groq_key and groq_key != "your_groq_api_key":
            try:
                # Simple API validation (this would need actual Groq client)
                self.print_info("Groq API key configured ✅")
                self.services_status['groq_api'] = True
            except Exception as e:
                self.print_warning(f"Groq API key validation failed: {e}")
        else:
            self.print_warning("Groq API key not configured")
        
        # Check HuggingFace token
        hf_token = os.getenv("HUGGING_FACE_TOKEN")
        if hf_token and hf_token != "your_hf_token":
            self.print_info("HuggingFace token configured ✅")
            self.services_status['huggingface'] = True
        else:
            self.print_warning("HuggingFace token not configured")
    
    def initialize_faiss_index(self):
        """Initialize FAISS vector index"""
        self.print_step("Initializing FAISS index", 8)
        
        try:
            setup_faiss_script = self.project_root / "scripts" / "setup_faiss.py"
            if setup_faiss_script.exists():
                result = self.run_command(f"python {setup_faiss_script}")
                if result and result != "False":
                    self.print_info("FAISS index initialized ✅")
                else:
                    self.print_warning("FAISS index initialization may have issues")
            else:
                self.print_warning("FAISS setup script not found")
        except Exception as e:
            self.print_warning(f"FAISS initialization error: {e}")
    
    def prepare_initial_model(self):
        """Prepare initial model setup"""
        self.print_step("Preparing initial model setup", 9)
        
        try:
            initial_ft_script = self.project_root / "scripts" / "initial_fine_tune.py"
            if initial_ft_script.exists():
                if self.environment == "production":
                    self.print_info("Running initial fine-tuning for production...")
                    result = self.run_command(f"python {initial_ft_script}")
                    if result and result != "False":
                        self.print_info("Initial model fine-tuning completed ✅")
                    else:
                        self.print_warning("Initial fine-tuning completed with warnings")
                else:
                    self.print_info("Skipping fine-tuning in development mode")
                    self.print_info(f"Run manually: python {initial_ft_script}")
            else:
                self.print_warning("Initial fine-tune script not found")
        except Exception as e:
            self.print_warning(f"Model preparation error: {e}")
    
    def test_system_integration(self):
        """Test basic system integration"""
        self.print_step("Testing system integration", 10)
        
        # Test imports
        try:
            from backend.app.services.embedding_service import EmbeddingService
            from backend.app.services.rag_pipeline import RAGPipeline
            self.print_info("Core services import successfully ✅")
        except ImportError as e:
            self.print_error(f"Import error: {e}")
        
        # Test configuration loading
        try:
            config_dict = self.config.to_dict()
            self.print_info("Configuration loading works ✅")
        except Exception as e:
            self.print_error(f"Configuration error: {e}")
    
    def generate_setup_report(self):
        """Generate setup completion report"""
        self.print_step("Setup Summary")
        
        print(f"\n{Colors.BOLD}📊 Service Status:{Colors.END}")
        for service, status in self.services_status.items():
            status_icon = "✅" if status else "❌"
            print(f"  {status_icon} {service.replace('_', ' ').title()}")
        
        print(f"\n{Colors.BOLD}📁 Key Directories:{Colors.END}")
        print(f"  📂 Data: {self.data_dir}")
        print(f"  🤖 Models: {self.models_dir}")
        print(f"  📝 Logs: {self.logs_dir}")
        
        print(f"\n{Colors.BOLD}🚀 Next Steps:{Colors.END}")
        if not all(self.services_status.values()):
            print(f"  1. Start missing services:")
            if not self.services_status['redis']:
                print(f"     redis-server")
            if not self.services_status['ollama']:
                print(f"     ollama serve")
            if not self.services_status['groq_api']:
                print(f"     Set GROQ_API_KEY in .env")
            if not self.services_status['huggingface']:
                print(f"     Set HUGGING_FACE_TOKEN in .env")
        
        print(f"  2. Start the application:")
        print(f"     cd backend && python run.py")
        print(f"     cd frontend && streamlit run app.py")
        
        print(f"\n{Colors.BOLD}{Colors.GREEN}🎉 Setup completed!{Colors.END}")
        if self.environment == "development":
            print(f"  Frontend: http://localhost:8501")
            print(f"  Backend: http://localhost:5000")
    
    def run_setup(self):
        """Run the complete setup process"""
        try:
            self.check_python_version()
            self.create_directories()
            self.check_and_install_dependencies()
            self.setup_environment_file()
            self.check_redis_service()
            self.check_ollama_service()
            self.check_api_keys()
            self.initialize_faiss_index()
            
            if self.environment in ["production", "staging"]:
                self.prepare_initial_model()
            
            self.test_system_integration()
            self.generate_setup_report()
            
        except KeyboardInterrupt:
            self.print_error("Setup interrupted by user")
            sys.exit(1)
        except Exception as e:
            self.print_error(f"Setup failed with error: {e}")
            self.logger.exception("Setup error")
            sys.exit(1)


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Setup RL Document Summarization System")
    parser.add_argument(
        "--env", 
        choices=["development", "production", "testing"], 
        default="development",
        help="Environment to setup for"
    )
    parser.add_argument(
        "--skip-gpu", 
        action="store_true",
        help="Skip GPU/CUDA setup"
    )
    parser.add_argument(
        "--quick", 
        action="store_true",
        help="Quick setup (skip model downloads)"
    )
    
    args = parser.parse_args()
    
    # Setup logging
    setup_logging(level="INFO", colored_console=True)
    
    # Run setup
    setup = SystemSetup(
        environment=args.env,
        skip_gpu=args.skip_gpu
    )
    
    setup.run_setup()


if __name__ == "__main__":
    main()