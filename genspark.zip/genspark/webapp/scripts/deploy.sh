#!/bin/bash

# Deployment Script for RL Document Summarization System
# Supports development, staging, and production deployments

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"
COMPOSE_FILE="$PROJECT_ROOT/docker/docker-compose.yml"
ENV_FILE="$PROJECT_ROOT/.env"

# Default values
ENVIRONMENT="development"
SERVICES="all"
FORCE_REBUILD=false
DETACHED=true
SKIP_TESTS=false
BACKUP_DATA=false

# Print functions
print_banner() {
    echo -e "${BOLD}${BLUE}"
    echo "=============================================="
    echo "  RL Document Summarization - Deployment"
    echo "=============================================="
    echo -e "${NC}"
}

print_step() {
    echo -e "\n${BOLD}${YELLOW}📋 $1${NC}"
}

print_success() {
    echo -e "${BOLD}${GREEN}✅ $1${NC}"
}

print_error() {
    echo -e "${BOLD}${RED}❌ $1${NC}"
}

print_warning() {
    echo -e "${BOLD}${YELLOW}⚠️  $1${NC}"
}

print_info() {
    echo -e "${CYAN}ℹ️  $1${NC}"
}

# Usage function
usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -e, --env ENVIRONMENT    Environment: development, staging, production (default: development)"
    echo "  -s, --services SERVICES  Services to deploy: all, backend, frontend, workers (default: all)"
    echo "  -f, --force              Force rebuild of Docker images"
    echo "  -t, --test              Run tests before deployment"
    echo "  -b, --backup            Backup existing data before deployment"
    echo "  --no-detach             Run services in foreground (don't detach)"
    echo "  -h, --help              Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 --env production --force"
    echo "  $0 --services backend --no-detach"
    echo "  $0 --test --backup"
    exit 1
}

# Parse command line arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -e|--env)
                ENVIRONMENT="$2"
                shift 2
                ;;
            -s|--services)
                SERVICES="$2"
                shift 2
                ;;
            -f|--force)
                FORCE_REBUILD=true
                shift
                ;;
            -t|--test)
                SKIP_TESTS=false
                shift
                ;;
            -b|--backup)
                BACKUP_DATA=true
                shift
                ;;
            --no-detach)
                DETACHED=false
                shift
                ;;
            -h|--help)
                usage
                ;;
            *)
                echo "Unknown option: $1"
                usage
                ;;
        esac
    done
}

# Validate environment
validate_environment() {
    case $ENVIRONMENT in
        development|staging|production)
            print_info "Environment: $ENVIRONMENT"
            ;;
        *)
            print_error "Invalid environment: $ENVIRONMENT"
            exit 1
            ;;
    esac
}

# Check prerequisites
check_prerequisites() {
    print_step "Checking Prerequisites"
    
    # Check if Docker is installed
    if ! command -v docker &> /dev/null; then
        print_error "Docker is not installed"
        exit 1
    fi
    
    # Check if Docker Compose is installed
    if ! command -v docker-compose &> /dev/null && ! docker compose version &> /dev/null; then
        print_error "Docker Compose is not installed"
        exit 1
    fi
    
    # Check if project files exist
    if [[ ! -f "$COMPOSE_FILE" ]]; then
        print_error "Docker Compose file not found: $COMPOSE_FILE"
        exit 1
    fi
    
    # Check environment file
    if [[ ! -f "$ENV_FILE" ]]; then
        print_warning "Environment file not found: $ENV_FILE"
        if [[ -f "$PROJECT_ROOT/.env.example" ]]; then
            print_info "Creating .env from .env.example"
            cp "$PROJECT_ROOT/.env.example" "$ENV_FILE"
        else
            print_error "No .env.example file found to copy from"
            exit 1
        fi
    fi
    
    print_success "Prerequisites check passed"
}

# Backup data
backup_data() {
    if [[ "$BACKUP_DATA" == true ]]; then
        print_step "Backing up Data"
        
        BACKUP_DIR="$PROJECT_ROOT/backups/$(date +%Y%m%d_%H%M%S)"
        mkdir -p "$BACKUP_DIR"
        
        # Backup data directory
        if [[ -d "$PROJECT_ROOT/data" ]]; then
            cp -r "$PROJECT_ROOT/data" "$BACKUP_DIR/"
            print_info "Data backed up to: $BACKUP_DIR/data"
        fi
        
        # Backup models directory
        if [[ -d "$PROJECT_ROOT/models" ]]; then
            cp -r "$PROJECT_ROOT/models" "$BACKUP_DIR/"
            print_info "Models backed up to: $BACKUP_DIR/models"
        fi
        
        # Backup logs directory
        if [[ -d "$PROJECT_ROOT/logs" ]]; then
            cp -r "$PROJECT_ROOT/logs" "$BACKUP_DIR/"
            print_info "Logs backed up to: $BACKUP_DIR/logs"
        fi
        
        print_success "Backup completed: $BACKUP_DIR"
    fi
}

# Run tests
run_tests() {
    if [[ "$SKIP_TESTS" == false ]]; then
        print_step "Running Tests"
        
        cd "$PROJECT_ROOT"
        
        # Run unit tests
        if python -m pytest tests/unit/ --quiet; then
            print_success "Unit tests passed"
        else
            print_error "Unit tests failed"
            exit 1
        fi
        
        # Run integration tests (optional, may require services)
        if [[ -d "tests/integration" ]]; then
            print_info "Skipping integration tests (require running services)"
        fi
    fi
}

# Pull latest images
pull_images() {
    print_step "Pulling Latest Images"
    
    cd "$PROJECT_ROOT"
    
    if command -v docker-compose &> /dev/null; then
        docker-compose -f "$COMPOSE_FILE" pull
    else
        docker compose -f "$COMPOSE_FILE" pull
    fi
    
    print_success "Images pulled"
}

# Build services
build_services() {
    print_step "Building Services"
    
    cd "$PROJECT_ROOT"
    
    BUILD_ARGS=""
    if [[ "$FORCE_REBUILD" == true ]]; then
        BUILD_ARGS="--no-cache"
    fi
    
    case $SERVICES in
        all)
            SERVICES_LIST=""
            ;;
        backend)
            SERVICES_LIST="backend celery_worker celery_beat"
            ;;
        frontend)
            SERVICES_LIST="frontend"
            ;;
        workers)
            SERVICES_LIST="celery_worker celery_beat"
            ;;
        *)
            SERVICES_LIST="$SERVICES"
            ;;
    esac
    
    if command -v docker-compose &> /dev/null; then
        docker-compose -f "$COMPOSE_FILE" build $BUILD_ARGS $SERVICES_LIST
    else
        docker compose -f "$COMPOSE_FILE" build $BUILD_ARGS $SERVICES_LIST
    fi
    
    print_success "Services built"
}

# Start services
start_services() {
    print_step "Starting Services"
    
    cd "$PROJECT_ROOT"
    
    # Determine services to start
    case $SERVICES in
        all)
            SERVICES_LIST=""
            ;;
        backend)
            SERVICES_LIST="redis backend celery_worker celery_beat"
            ;;
        frontend)
            SERVICES_LIST="frontend"
            ;;
        workers)
            SERVICES_LIST="redis celery_worker celery_beat"
            ;;
        *)
            SERVICES_LIST="$SERVICES"
            ;;
    esac
    
    # Start services
    if [[ "$DETACHED" == true ]]; then
        if command -v docker-compose &> /dev/null; then
            docker-compose -f "$COMPOSE_FILE" up -d $SERVICES_LIST
        else
            docker compose -f "$COMPOSE_FILE" up -d $SERVICES_LIST
        fi
        print_success "Services started in detached mode"
    else
        if command -v docker-compose &> /dev/null; then
            docker-compose -f "$COMPOSE_FILE" up $SERVICES_LIST
        else
            docker compose -f "$COMPOSE_FILE" up $SERVICES_LIST
        fi
    fi
}

# Health check
health_check() {
    print_step "Running Health Checks"
    
    # Wait a moment for services to start
    sleep 10
    
    # Check backend health
    if curl -f -s http://localhost:5000/health > /dev/null 2>&1; then
        print_success "Backend health check passed"
    else
        print_warning "Backend health check failed (may still be starting)"
    fi
    
    # Check frontend health
    if curl -f -s http://localhost:8501/healthz > /dev/null 2>&1; then
        print_success "Frontend health check passed"
    else
        print_warning "Frontend health check failed (may still be starting)"
    fi
    
    # Check Redis
    if docker exec rl_summarization_redis redis-cli ping > /dev/null 2>&1; then
        print_success "Redis health check passed"
    else
        print_warning "Redis health check failed"
    fi
    
    # Check Ollama
    if curl -f -s http://localhost:11434/api/tags > /dev/null 2>&1; then
        print_success "Ollama health check passed"
    else
        print_warning "Ollama health check failed"
    fi
}

# Show service status
show_status() {
    print_step "Service Status"
    
    cd "$PROJECT_ROOT"
    
    if command -v docker-compose &> /dev/null; then
        docker-compose -f "$COMPOSE_FILE" ps
    else
        docker compose -f "$COMPOSE_FILE" ps
    fi
}

# Show logs
show_logs() {
    print_step "Recent Logs"
    
    cd "$PROJECT_ROOT"
    
    if command -v docker-compose &> /dev/null; then
        docker-compose -f "$COMPOSE_FILE" logs --tail=20
    else
        docker compose -f "$COMPOSE_FILE" logs --tail=20
    fi
}

# Print access information
print_access_info() {
    print_step "Access Information"
    
    echo -e "${CYAN}📱 Frontend (Streamlit):"
    echo -e "   🌐 http://localhost:8501${NC}"
    echo -e "${CYAN}🔧 Backend (Flask API):"
    echo -e "   🌐 http://localhost:5000${NC}"
    echo -e "   📚 API Docs: http://localhost:5000/docs${NC}"
    echo -e "${CYAN}📊 Redis:"
    echo -e "   🌐 localhost:6379${NC}"
    echo -e "${CYAN}🤖 Ollama:"
    echo -e "   🌐 http://localhost:11434${NC}"
    
    if [[ "$ENVIRONMENT" == "production" ]]; then
        echo -e "${CYAN}🌐 Nginx (Load Balancer):"
        echo -e "   🌐 http://localhost${NC}"
    fi
}

# Environment-specific setup
setup_environment() {
    print_step "Setting up $ENVIRONMENT Environment"
    
    # Create environment-specific .env file
    ENV_TEMPLATE="$PROJECT_ROOT/.env.$ENVIRONMENT"
    if [[ -f "$ENV_TEMPLATE" ]]; then
        print_info "Using environment template: $ENV_TEMPLATE"
        cp "$ENV_TEMPLATE" "$ENV_FILE"
    fi
    
    # Environment-specific configurations
    case $ENVIRONMENT in
        development)
            print_info "Development mode: Debug enabled, hot reload"
            ;;
        staging)
            print_info "Staging mode: Production-like with debugging"
            ;;
        production)
            print_info "Production mode: Optimized for performance"
            # Additional production setup
            ;;
    esac
}

# Cleanup function
cleanup() {
    print_step "Cleaning up"
    
    cd "$PROJECT_ROOT"
    
    # Stop services if running
    if command -v docker-compose &> /dev/null; then
        docker-compose -f "$COMPOSE_FILE" down
    else
        docker compose -f "$COMPOSE_FILE" down
    fi
    
    print_success "Cleanup completed"
}

# Signal handler for graceful shutdown
trap cleanup EXIT

# Main deployment function
main() {
    print_banner
    
    parse_args "$@"
    validate_environment
    check_prerequisites
    setup_environment
    backup_data
    run_tests
    pull_images
    build_services
    start_services
    
    if [[ "$DETACHED" == true ]]; then
        health_check
        show_status
        show_logs
        print_access_info
        
        echo ""
        print_success "Deployment completed successfully!"
        print_info "Use 'docker-compose logs -f' to follow logs"
        print_info "Use 'docker-compose down' to stop services"
    fi
}

# Run main function
main "$@"