"""
FAISS Index Setup Script

Initializes the FAISS index for document embeddings.
"""

import sys
import os
from pathlib import Path

# Add the backend directory to Python path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'backend'))

from app import create_app
from app.services.faiss_manager import FaissManager
from app.services.embedding_service import EmbeddingService


def setup_faiss_index():
    """Initialize FAISS index and embedding service."""
    
    print("🔧 Setting up FAISS index...")
    
    # Create Flask app context
    app = create_app()
    
    with app.app_context():
        # Ensure directories exist
        app.config['ensure_directories']()
        
        # Initialize FAISS manager
        faiss_manager = FaissManager()
        
        # Initialize embedding service
        embedding_service = EmbeddingService()
        
        # Validate embedding service
        print("🔍 Validating embedding service...")
        embed_status = embedding_service.validate_ollama_connection()
        
        if embed_status['connected']:
            print("✅ Embedding service connected successfully")
            
            if embed_status['embedding_model_available']:
                print(f"✅ Embedding model '{embedding_service.embedding_model}' available")
            else:
                print(f"⚠️  Embedding model '{embedding_service.embedding_model}' not available")
                print("   Please install it with: ollama pull nomic-embed-text")
        else:
            print("❌ Cannot connect to Ollama service")
            print("   Please ensure Ollama is running: ollama serve")
            return False
        
        # Get index info
        index_info = faiss_manager.get_index_info()
        print(f"📊 FAISS Index Status:")
        print(f"   - Total vectors: {index_info['total_vectors']}")
        print(f"   - Total documents: {index_info['total_documents']}")
        print(f"   - Index trained: {index_info['index_trained']}")
        print(f"   - Index type: {index_info['index_type']}")
        
        if index_info['index_file_exists']:
            print("✅ FAISS index file exists")
        else:
            print("ℹ️  FAISS index will be created on first document upload")
        
        print("🎉 FAISS setup completed successfully!")
        return True


if __name__ == "__main__":
    success = setup_faiss_index()
    sys.exit(0 if success else 1)