#!/usr/bin/env python3
"""
Service Management Script

Provides utilities for managing system services including:
- Starting/stopping individual services
- Monitoring service health
- Viewing logs and metrics  
- Database management
- Model management
"""

import os
import sys
import time
import json
import argparse
import subprocess
import signal
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
import psutil
import requests

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.append(str(project_root))

from configs.app_config import get_config
from configs.logging_config import setup_logging, get_logger


class Colors:
    """Terminal color codes"""
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    PURPLE = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'
    END = '\033[0m'


class ServiceManager:
    """Main service management class"""
    
    def __init__(self, environment: str = "development"):
        self.environment = environment
        self.config = get_config(environment)
        self.logger = get_logger("service_manager")
        self.project_root = project_root
        
        # Service definitions
        self.services = {
            'redis': {
                'command': ['redis-server'],
                'port': 6379,
                'health_check': self._check_redis_health,
                'description': 'Redis Cache & Message Broker'
            },
            'ollama': {
                'command': ['ollama', 'serve'],
                'port': 11434,
                'health_check': self._check_ollama_health,
                'description': 'Ollama Embedding Service'
            },
            'backend': {
                'command': ['python', 'run.py'],
                'port': 5000,
                'cwd': self.project_root / 'backend',
                'health_check': self._check_backend_health,
                'description': 'Flask Backend API'
            },
            'celery_worker': {
                'command': ['celery', '-A', 'celery_app.celery', 'worker', '--loglevel=info'],
                'cwd': self.project_root / 'backend',
                'health_check': self._check_celery_worker_health,
                'description': 'Celery Task Worker'
            },
            'celery_beat': {
                'command': ['celery', '-A', 'celery_app.celery', 'beat', '--loglevel=info'],
                'cwd': self.project_root / 'backend',
                'health_check': self._check_celery_beat_health,
                'description': 'Celery Periodic Task Scheduler'
            },
            'frontend': {
                'command': ['streamlit', 'run', 'app.py', '--server.port=8501'],
                'port': 8501,
                'cwd': self.project_root / 'frontend',
                'health_check': self._check_frontend_health,
                'description': 'Streamlit Frontend'
            }
        }
        
        # Running process tracking
        self.running_processes = {}
    
    def print_status(self, message: str, status: str = "info"):
        """Print colored status message"""
        colors = {
            'info': Colors.CYAN,
            'success': Colors.GREEN,
            'warning': Colors.YELLOW,
            'error': Colors.RED
        }
        color = colors.get(status, Colors.WHITE)
        print(f"{color}{message}{Colors.END}")
    
    def _check_port_in_use(self, port: int) -> bool:
        """Check if a port is currently in use"""
        try:
            for conn in psutil.net_connections():
                if conn.laddr.port == port and conn.status == 'LISTEN':
                    return True
            return False
        except:
            return False
    
    def _check_redis_health(self) -> bool:
        """Check Redis health"""
        try:
            import redis
            r = redis.from_url(self.config.database.redis_url)
            r.ping()
            return True
        except:
            return False
    
    def _check_ollama_health(self) -> bool:
        """Check Ollama health"""
        try:
            response = requests.get(f"{self.config.model.ollama_host}/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def _check_backend_health(self) -> bool:
        """Check backend health"""
        try:
            response = requests.get("http://localhost:5000/health", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def _check_celery_worker_health(self) -> bool:
        """Check Celery worker health"""
        try:
            result = subprocess.run(
                ['celery', '-A', 'celery_app.celery', 'inspect', 'ping'],
                cwd=self.project_root / 'backend',
                capture_output=True,
                text=True,
                timeout=10
            )
            return result.returncode == 0 and 'pong' in result.stdout.lower()
        except:
            return False
    
    def _check_celery_beat_health(self) -> bool:
        """Check Celery beat health"""
        try:
            # Check if celerybeat-schedule file exists and is recent
            schedule_file = self.project_root / 'backend' / 'celerybeat-schedule'
            if schedule_file.exists():
                # Check if file was modified within last 5 minutes
                mtime = schedule_file.stat().st_mtime
                return (time.time() - mtime) < 300
            return False
        except:
            return False
    
    def _check_frontend_health(self) -> bool:
        """Check frontend health"""
        try:
            response = requests.get("http://localhost:8501/healthz", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def start_service(self, service_name: str, background: bool = True) -> bool:
        """Start a specific service"""
        if service_name not in self.services:
            self.print_status(f"Unknown service: {service_name}", "error")
            return False
        
        service = self.services[service_name]
        
        # Check if service is already running
        if 'port' in service and self._check_port_in_use(service['port']):
            self.print_status(f"{service_name} appears to be already running on port {service['port']}", "warning")
            return True
        
        try:
            self.print_status(f"Starting {service_name}: {service['description']}")
            
            # Setup process arguments
            kwargs = {
                'cwd': service.get('cwd', self.project_root)
            }
            
            if background:
                kwargs.update({
                    'stdout': subprocess.PIPE,
                    'stderr': subprocess.PIPE,
                    'start_new_session': True
                })
            
            # Start the process
            process = subprocess.Popen(service['command'], **kwargs)
            
            if background:
                self.running_processes[service_name] = process
                
                # Give service time to start
                time.sleep(2)
                
                # Check if process is still running
                if process.poll() is None:
                    self.print_status(f"✅ {service_name} started (PID: {process.pid})", "success")
                    return True
                else:
                    stdout, stderr = process.communicate()
                    self.print_status(f"❌ {service_name} failed to start", "error")
                    if stderr:
                        print(f"Error: {stderr.decode()}")
                    return False
            else:
                # Wait for process to complete (foreground mode)
                return_code = process.wait()
                return return_code == 0
                
        except Exception as e:
            self.print_status(f"❌ Failed to start {service_name}: {e}", "error")
            return False
    
    def stop_service(self, service_name: str) -> bool:
        """Stop a specific service"""
        if service_name not in self.services:
            self.print_status(f"Unknown service: {service_name}", "error")
            return False
        
        try:
            # If we have a tracked process, terminate it
            if service_name in self.running_processes:
                process = self.running_processes[service_name]
                if process.poll() is None:  # Process is still running
                    self.print_status(f"Stopping {service_name}...")
                    process.terminate()
                    
                    # Wait for graceful termination
                    try:
                        process.wait(timeout=10)
                        self.print_status(f"✅ {service_name} stopped gracefully", "success")
                    except subprocess.TimeoutExpired:
                        self.print_status(f"Force killing {service_name}...", "warning")
                        process.kill()
                        process.wait()
                        self.print_status(f"✅ {service_name} force killed", "success")
                    
                    del self.running_processes[service_name]
                    return True
            
            # If no tracked process, try to find and kill by port
            service = self.services[service_name]
            if 'port' in service:
                port = service['port']
                for proc in psutil.process_iter(['pid', 'name', 'connections']):
                    try:
                        for conn in proc.info['connections'] or []:
                            if conn.laddr.port == port and conn.status == 'LISTEN':
                                proc.terminate()
                                self.print_status(f"✅ Stopped {service_name} (PID: {proc.pid})", "success")
                                return True
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        continue
            
            self.print_status(f"⚠️  No running process found for {service_name}", "warning")
            return True
            
        except Exception as e:
            self.print_status(f"❌ Failed to stop {service_name}: {e}", "error")
            return False
    
    def restart_service(self, service_name: str) -> bool:
        """Restart a specific service"""
        self.print_status(f"Restarting {service_name}...")
        self.stop_service(service_name)
        time.sleep(2)
        return self.start_service(service_name)
    
    def get_service_status(self) -> Dict[str, Dict[str, Any]]:
        """Get status of all services"""
        status = {}
        
        for service_name, service_info in self.services.items():
            is_healthy = service_info['health_check']()
            
            # Check if port is in use (if applicable)
            port_in_use = False
            if 'port' in service_info:
                port_in_use = self._check_port_in_use(service_info['port'])
            
            # Check if we have a tracked process
            tracked_process = service_name in self.running_processes
            process_running = False
            pid = None
            
            if tracked_process:
                process = self.running_processes[service_name]
                process_running = process.poll() is None
                pid = process.pid if process_running else None
            
            status[service_name] = {
                'description': service_info['description'],
                'healthy': is_healthy,
                'port': service_info.get('port'),
                'port_in_use': port_in_use,
                'tracked_process': tracked_process,
                'process_running': process_running,
                'pid': pid,
                'status': 'running' if is_healthy else ('starting' if port_in_use else 'stopped')
            }
        
        return status
    
    def print_service_status(self):
        """Print formatted service status"""
        status = self.get_service_status()
        
        print(f"\n{Colors.BOLD}{Colors.BLUE}🔍 Service Status:{Colors.END}")
        print("-" * 80)
        
        for service_name, info in status.items():
            # Status emoji and color
            if info['healthy']:
                status_emoji = "✅"
                status_color = Colors.GREEN
            elif info['port_in_use'] or info['process_running']:
                status_emoji = "🟡"
                status_color = Colors.YELLOW
            else:
                status_emoji = "❌"
                status_color = Colors.RED
            
            # Format port info
            port_info = f" (:{info['port']})" if info['port'] else ""
            
            # Format PID info
            pid_info = f" [PID: {info['pid']}]" if info['pid'] else ""
            
            print(f"{status_emoji} {status_color}{service_name:15}{Colors.END} {info['description']}{port_info}{pid_info}")
            
            # Additional details
            if info['status'] == 'starting':
                print(f"   {Colors.YELLOW}⏳ Service is starting...{Colors.END}")
            elif not info['healthy'] and info['port_in_use']:
                print(f"   {Colors.YELLOW}⚠️  Port in use but health check failed{Colors.END}")
    
    def show_logs(self, service_name: str, lines: int = 50):
        """Show logs for a service"""
        if service_name not in self.running_processes:
            self.print_status(f"No tracked process for {service_name}", "warning")
            return
        
        process = self.running_processes[service_name]
        if process.poll() is not None:
            self.print_status(f"Process for {service_name} is not running", "warning")
            return
        
        # This is simplified - in practice you'd want to implement proper log tailing
        self.print_status(f"Logs for {service_name} (last {lines} lines):")
        print("-" * 60)
    
    def cleanup_all(self):
        """Stop all tracked services"""
        self.print_status("Stopping all services...")
        
        for service_name in list(self.running_processes.keys()):
            self.stop_service(service_name)
        
        self.print_status("✅ All services stopped", "success")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description="Manage RL Summarization Services")
    parser.add_argument(
        "--env",
        choices=["development", "production", "testing"],
        default="development",
        help="Environment"
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Status command
    subparsers.add_parser("status", help="Show service status")
    
    # Start command
    start_parser = subparsers.add_parser("start", help="Start service(s)")
    start_parser.add_argument("services", nargs="*", help="Service names (or 'all')")
    start_parser.add_argument("--foreground", action="store_true", help="Run in foreground")
    
    # Stop command
    stop_parser = subparsers.add_parser("stop", help="Stop service(s)")
    stop_parser.add_argument("services", nargs="*", help="Service names (or 'all')")
    
    # Restart command
    restart_parser = subparsers.add_parser("restart", help="Restart service(s)")
    restart_parser.add_argument("services", nargs="*", help="Service names (or 'all')")
    
    # Logs command
    logs_parser = subparsers.add_parser("logs", help="Show service logs")
    logs_parser.add_argument("service", help="Service name")
    logs_parser.add_argument("--lines", type=int, default=50, help="Number of lines")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    # Setup logging
    setup_logging(level="INFO", colored_console=True)
    
    # Create service manager
    manager = ServiceManager(args.env)
    
    # Setup signal handler for cleanup
    def signal_handler(sig, frame):
        print(f"\n{Colors.YELLOW}Received signal {sig}, cleaning up...{Colors.END}")
        manager.cleanup_all()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Execute commands
    try:
        if args.command == "status":
            manager.print_service_status()
        
        elif args.command == "start":
            services = args.services if args.services else ["all"]
            if "all" in services:
                services = list(manager.services.keys())
            
            for service in services:
                if service in manager.services:
                    manager.start_service(service, background=not args.foreground)
                else:
                    manager.print_status(f"Unknown service: {service}", "error")
        
        elif args.command == "stop":
            services = args.services if args.services else ["all"]
            if "all" in services:
                services = list(manager.services.keys())
            
            for service in services:
                if service in manager.services:
                    manager.stop_service(service)
                else:
                    manager.print_status(f"Unknown service: {service}", "error")
        
        elif args.command == "restart":
            services = args.services if args.services else ["all"]
            if "all" in services:
                services = list(manager.services.keys())
            
            for service in services:
                if service in manager.services:
                    manager.restart_service(service)
                else:
                    manager.print_status(f"Unknown service: {service}", "error")
        
        elif args.command == "logs":
            manager.show_logs(args.service, args.lines)
        
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}Interrupted by user{Colors.END}")
        manager.cleanup_all()
    except Exception as e:
        manager.print_status(f"Error: {e}", "error")
        sys.exit(1)


if __name__ == "__main__":
    main()