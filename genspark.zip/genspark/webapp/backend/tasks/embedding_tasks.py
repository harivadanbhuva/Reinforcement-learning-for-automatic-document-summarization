"""
Celery tasks for document embedding and processing.

Handles asynchronous document processing, embedding generation,
and FAISS index updates.
"""

import time
from datetime import datetime
from celery import current_task
from celery_app import celery_app

# Import Flask app context
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app
from app.services.document_processor import DocumentProcessor
from app.services.embedding_service import EmbeddingService
from app.services.faiss_manager import FaissManager
from app.services.jsonl_logger import JsonlLogger


@celery_app.task(bind=True, name='tasks.embedding_tasks.embed_document_async')
def embed_document_async(self, doc_id: str, file_path: str, filename: str):
    """
    Asynchronously process and embed a document.
    
    Args:
        doc_id: Document identifier
        file_path: Path to the uploaded file
        filename: Original filename
    """
    try:
        # Update task state
        self.update_state(
            state='PROGRESS',
            meta={'status': 'Starting document processing', 'progress': 0}
        )
        
        # Create Flask app context
        app = create_app()
        
        with app.app_context():
            # Initialize services
            doc_processor = DocumentProcessor()
            embedding_service = EmbeddingService()
            faiss_manager = FaissManager()
            logger = JsonlLogger()
            
            # Step 1: Process document
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Extracting and cleaning text', 'progress': 20}
            )
            
            processing_result = doc_processor.process_document(doc_id, file_path, filename)
            
            if 'error' in processing_result:
                raise Exception(f"Document processing failed: {processing_result['error']}")
            
            # Step 2: Generate embeddings
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Generating embeddings', 'progress': 40}
            )
            
            chunks = doc_processor.get_document_chunks(doc_id)
            if not chunks:
                raise Exception("No chunks found for embedding")
            
            embedded_chunks = embedding_service.embed_document_chunks(chunks, doc_id)
            
            # Step 3: Add to FAISS index
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Updating vector index', 'progress': 70}
            )
            
            chunks_added = faiss_manager.add_document_chunks(embedded_chunks, doc_id)
            
            # Step 4: Log completion
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Finalizing', 'progress': 90}
            )
            
            # Log document processing episode
            episode_data = {
                'episode_id': f'doc_process_{doc_id}',
                'phase': 'document_processing',
                'timestamp': datetime.utcnow().isoformat(),
                'doc_id': doc_id,
                'filename': filename,
                'file_path': file_path,
                'processing_results': {
                    'chunks_created': len(chunks),
                    'chunks_embedded': len(embedded_chunks),
                    'chunks_indexed': chunks_added,
                    'word_count': processing_result['statistics']['word_count'],
                    'character_count': processing_result['statistics']['character_count']
                },
                'task_id': self.request.id
            }
            
            logger.log_episode(episode_data, 'document_processing.jsonl')
            
            # Final result
            result = {
                'status': 'completed',
                'doc_id': doc_id,
                'filename': filename,
                'chunks_processed': chunks_added,
                'processing_time_seconds': time.time() - self.request.called_directly,
                'document_stats': processing_result['statistics']
            }
            
            self.update_state(
                state='SUCCESS',
                meta={'status': 'Document processing completed', 'progress': 100, 'result': result}
            )
            
            return result
            
    except Exception as e:
        error_result = {
            'status': 'failed',
            'doc_id': doc_id,
            'filename': filename,
            'error': str(e)
        }
        
        self.update_state(
            state='FAILURE',
            meta={'status': f'Document processing failed: {str(e)}', 'error': str(e)}
        )
        
        # Log error episode
        try:
            with app.app_context():
                logger = JsonlLogger()
                error_episode = {
                    'episode_id': f'doc_process_error_{doc_id}',
                    'phase': 'document_processing_error',
                    'timestamp': datetime.utcnow().isoformat(),
                    'doc_id': doc_id,
                    'filename': filename,
                    'error': str(e),
                    'task_id': self.request.id
                }
                logger.log_episode(error_episode, 'document_processing.jsonl')
        except Exception:
            pass  # Don't fail on logging errors
        
        raise Exception(str(e))


@celery_app.task(bind=True, name='tasks.embedding_tasks.reembed_document')
def reembed_document(self, doc_id: str):
    """
    Re-embed an existing document with updated embeddings.
    
    Args:
        doc_id: Document identifier
    """
    try:
        self.update_state(
            state='PROGRESS',
            meta={'status': 'Starting re-embedding process', 'progress': 0}
        )
        
        app = create_app()
        
        with app.app_context():
            doc_processor = DocumentProcessor()
            embedding_service = EmbeddingService()
            faiss_manager = FaissManager()
            
            # Get existing document
            doc_info = doc_processor.get_document_info(doc_id)
            if not doc_info:
                raise Exception(f"Document {doc_id} not found")
            
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Removing old embeddings', 'progress': 25}
            )
            
            # Remove from FAISS
            faiss_manager.remove_document(doc_id)
            
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Generating new embeddings', 'progress': 50}
            )
            
            # Get chunks and re-embed
            chunks = doc_processor.get_document_chunks(doc_id)
            embedded_chunks = embedding_service.embed_document_chunks(chunks, doc_id)
            
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Updating vector index', 'progress': 75}
            )
            
            # Add back to FAISS
            chunks_added = faiss_manager.add_document_chunks(embedded_chunks, doc_id)
            
            result = {
                'status': 'completed',
                'doc_id': doc_id,
                'chunks_reembedded': chunks_added,
                'filename': doc_info.get('filename', 'unknown')
            }
            
            self.update_state(
                state='SUCCESS',
                meta={'status': 'Re-embedding completed', 'progress': 100, 'result': result}
            )
            
            return result
            
    except Exception as e:
        self.update_state(
            state='FAILURE',
            meta={'status': f'Re-embedding failed: {str(e)}', 'error': str(e)}
        )
        
        raise Exception(str(e))


@celery_app.task(bind=True, name='tasks.embedding_tasks.batch_embed_documents')
def batch_embed_documents(self, doc_ids: list):
    """
    Embed multiple documents in batch.
    
    Args:
        doc_ids: List of document identifiers
    """
    try:
        total_docs = len(doc_ids)
        results = []
        
        self.update_state(
            state='PROGRESS',
            meta={'status': f'Starting batch embedding for {total_docs} documents', 'progress': 0}
        )
        
        app = create_app()
        
        with app.app_context():
            for i, doc_id in enumerate(doc_ids):
                try:
                    progress = (i / total_docs) * 100
                    self.update_state(
                        state='PROGRESS',
                        meta={
                            'status': f'Processing document {i+1}/{total_docs}',
                            'progress': progress,
                            'current_doc': doc_id
                        }
                    )
                    
                    # Process single document
                    doc_processor = DocumentProcessor()
                    embedding_service = EmbeddingService()
                    faiss_manager = FaissManager()
                    
                    chunks = doc_processor.get_document_chunks(doc_id)
                    if chunks:
                        embedded_chunks = embedding_service.embed_document_chunks(chunks, doc_id)
                        chunks_added = faiss_manager.add_document_chunks(embedded_chunks, doc_id)
                        
                        results.append({
                            'doc_id': doc_id,
                            'status': 'success',
                            'chunks_added': chunks_added
                        })
                    else:
                        results.append({
                            'doc_id': doc_id,
                            'status': 'failed',
                            'error': 'No chunks found'
                        })
                        
                except Exception as e:
                    results.append({
                        'doc_id': doc_id,
                        'status': 'failed',
                        'error': str(e)
                    })
            
            # Final result
            successful = len([r for r in results if r['status'] == 'success'])
            failed = len([r for r in results if r['status'] == 'failed'])
            
            final_result = {
                'status': 'completed',
                'total_documents': total_docs,
                'successful': successful,
                'failed': failed,
                'results': results
            }
            
            self.update_state(
                state='SUCCESS',
                meta={
                    'status': f'Batch embedding completed: {successful} success, {failed} failed',
                    'progress': 100,
                    'result': final_result
                }
            )
            
            return final_result
            
    except Exception as e:
        self.update_state(
            state='FAILURE',
            meta={'status': f'Batch embedding failed: {str(e)}', 'error': str(e)}
        )
        
        raise Exception(str(e))


@celery_app.task(name='tasks.embedding_tasks.validate_embeddings')
def validate_embeddings():
    """
    Validate the integrity of embeddings and FAISS index.
    """
    try:
        app = create_app()
        
        with app.app_context():
            faiss_manager = FaissManager()
            embedding_service = EmbeddingService()
            
            # Get index info
            index_info = faiss_manager.get_index_info()
            
            # Validate embedding service
            embedding_stats = embedding_service.get_embedding_statistics()
            
            # Test search functionality
            test_results = []
            test_queries = ["test query", "machine learning", "artificial intelligence"]
            
            for query in test_queries:
                try:
                    results = faiss_manager.search(query, top_k=1)
                    test_results.append({
                        'query': query,
                        'results_count': len(results),
                        'status': 'success'
                    })
                except Exception as e:
                    test_results.append({
                        'query': query,
                        'error': str(e),
                        'status': 'failed'
                    })
            
            validation_result = {
                'status': 'completed',
                'timestamp': datetime.utcnow().isoformat(),
                'index_info': index_info,
                'embedding_stats': embedding_stats,
                'search_tests': test_results,
                'validation_passed': all(t['status'] == 'success' for t in test_results)
            }
            
            return validation_result
            
    except Exception as e:
        return {
            'status': 'failed',
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }