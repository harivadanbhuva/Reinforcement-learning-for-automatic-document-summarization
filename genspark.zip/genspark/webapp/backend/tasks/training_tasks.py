"""
Celery tasks for DPO model training.

Handles asynchronous DPO training, model evaluation, and training requirements checking.
"""

import time
from datetime import datetime, timedelta
from celery import current_task
from celery_app import celery_app

# Import Flask app context
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app
from app.services.dpo_trainer import DPOTrainer
from app.services.jsonl_logger import JsonlLogger
from app.services.qwen_generator import QwenGenerator


@celery_app.task(bind=True, name='tasks.training_tasks.train_dpo_model')
def train_dpo_model(self, training_id: str, config: dict):
    """
    Train the Qwen model using Direct Preference Optimization.
    
    Args:
        training_id: Unique training identifier
        config: Training configuration dictionary
    """
    try:
        # Update initial state
        self.update_state(
            state='PROGRESS',
            meta={'status': 'Initializing DPO training', 'progress': 0, 'stage': 'initialization'}
        )
        
        app = create_app()
        
        with app.app_context():
            logger = JsonlLogger()
            dpo_trainer = DPOTrainer()
            
            # Log training start
            start_episode = {
                'training_id': training_id,
                'episode_id': f'train_start_{training_id}',
                'phase': 'dpo_training_started',
                'timestamp': datetime.utcnow().isoformat(),
                'config': config,
                'task_id': self.request.id,
                'status': 'started'
            }
            logger.log_episode(start_episode, 'phase4_training.jsonl')
            
            # Step 1: Check training requirements
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Checking training requirements', 'progress': 10, 'stage': 'validation'}
            )
            
            preferences, data_stats = dpo_trainer.prepare_training_data()
            
            if not preferences:
                raise Exception(f"Insufficient training data: {data_stats.get('error', 'Unknown error')}")
            
            # Step 2: Load model for training
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Loading model for training', 'progress': 20, 'stage': 'model_loading'}
            )
            
            current_model_version = config.get('current_model_version', 'qwen-sft-base')
            config['current_model_version'] = current_model_version
            
            if not dpo_trainer.load_model_for_training(current_model_version):
                raise Exception("Failed to load model for training")
            
            # Step 3: Start training
            self.update_state(
                state='PROGRESS',
                meta={
                    'status': f'Training with {len(preferences)} preferences',
                    'progress': 30,
                    'stage': 'training',
                    'preferences_count': len(preferences)
                }
            )
            
            # Custom progress callback for training
            def training_progress_callback(epoch, batch, total_batches, loss):
                # Calculate training progress (30% to 80%)
                epoch_progress = (epoch + (batch / total_batches)) / config.get('max_epochs', 1)
                overall_progress = 30 + (epoch_progress * 50)
                
                self.update_state(
                    state='PROGRESS',
                    meta={
                        'status': f'Epoch {epoch}, Batch {batch}/{total_batches}',
                        'progress': min(80, overall_progress),
                        'stage': 'training',
                        'current_loss': loss,
                        'epoch': epoch,
                        'batch': batch,
                        'total_batches': total_batches
                    }
                )
            
            # Perform DPO training
            training_result = dpo_trainer.train_dpo_model(training_id, config)
            
            if training_result.get('status') == 'failed':
                raise Exception(f"Training failed: {training_result.get('error', 'Unknown error')}")
            
            # Step 4: Save and validate model
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Saving trained model', 'progress': 85, 'stage': 'saving'}
            )
            
            new_model_version = training_result.get('model_version_after')
            
            # Step 5: Validate trained model
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Validating trained model', 'progress': 90, 'stage': 'validation'}
            )
            
            # Quick validation test
            try:
                qwen_generator = QwenGenerator()
                qwen_generator.load_model_version(new_model_version)
                
                test_result = qwen_generator.generate_dual_summaries(
                    "Test query",
                    "This is a test context for validating the trained model."
                )
                
                validation_passed = len(test_result['summary_a']) > 10 and len(test_result['summary_b']) > 10
                training_result['validation_passed'] = validation_passed
                
            except Exception as e:
                training_result['validation_passed'] = False
                training_result['validation_error'] = str(e)
            
            # Clean up training models
            dpo_trainer.cleanup_models()
            
            # Step 6: Log completion
            completion_episode = {
                'training_id': training_id,
                'episode_id': f'train_complete_{training_id}',
                'phase': 'dpo_training_completed',
                'timestamp': datetime.utcnow().isoformat(),
                'completion_timestamp': datetime.utcnow().isoformat(),
                'status': 'completed',
                'model_version_before': current_model_version,
                'model_version_after': new_model_version,
                'training_metrics': {
                    'final_loss': training_result.get('final_loss', 0.0),
                    'total_batches': training_result.get('total_batches', 0),
                    'preferences_used': training_result.get('preferences_used', 0),
                    'training_duration_seconds': training_result.get('training_duration_seconds', 0),
                    'validation_passed': training_result.get('validation_passed', False)
                },
                'config': config,
                'task_id': self.request.id
            }
            logger.log_episode(completion_episode, 'phase4_training.jsonl')
            
            # Final success state
            final_result = {
                'status': 'completed',
                'training_id': training_id,
                'model_version_before': current_model_version,
                'model_version_after': new_model_version,
                'training_metrics': training_result,
                'preferences_used': len(preferences),
                'data_statistics': data_stats
            }
            
            self.update_state(
                state='SUCCESS',
                meta={
                    'status': 'DPO training completed successfully',
                    'progress': 100,
                    'stage': 'completed',
                    'result': final_result
                }
            )
            
            return final_result
            
    except Exception as e:
        error_message = str(e)
        
        # Log error
        try:
            with app.app_context():
                logger = JsonlLogger()
                error_episode = {
                    'training_id': training_id,
                    'episode_id': f'train_error_{training_id}',
                    'phase': 'dpo_training_failed',
                    'timestamp': datetime.utcnow().isoformat(),
                    'completion_timestamp': datetime.utcnow().isoformat(),
                    'status': 'failed',
                    'error': error_message,
                    'config': config,
                    'task_id': self.request.id
                }
                logger.log_episode(error_episode, 'phase4_training.jsonl')
                
                # Cleanup if possible
                try:
                    dpo_trainer = DPOTrainer()
                    dpo_trainer.cleanup_models()
                except Exception:
                    pass
                    
        except Exception:
            pass  # Don't fail on logging errors
        
        self.update_state(
            state='FAILURE',
            meta={
                'status': f'DPO training failed: {error_message}',
                'error': error_message,
                'stage': 'failed'
            }
        )
        
        raise Exception(error_message)


@celery_app.task(name='tasks.training_tasks.check_training_requirements')
def check_training_requirements():
    """
    Check if training requirements are met.
    """
    try:
        app = create_app()
        
        with app.app_context():
            logger = JsonlLogger()
            qwen_generator = QwenGenerator()
            
            # Get current model info
            model_info = qwen_generator.get_model_info()
            current_model_version = model_info.get('version', 'unknown')
            
            # Count total preferences
            all_preferences = logger.read_episodes('preferences.jsonl')
            
            # Count preferences for current model
            current_model_preferences = [
                p for p in all_preferences 
                if p.get('model_version') == current_model_version
            ]
            
            # Count new preferences since last training
            training_episodes = logger.read_episodes('phase4_training.jsonl')
            
            last_training_time = None
            if training_episodes:
                # Find last successful training
                successful_trainings = [
                    ep for ep in training_episodes 
                    if ep.get('status') == 'completed' and ep.get('model_version_after')
                ]
                
                if successful_trainings:
                    latest_training = max(successful_trainings, key=lambda x: x.get('timestamp', ''))
                    last_training_time = latest_training.get('timestamp')
            
            # Count new preferences since last training
            new_preferences = all_preferences
            if last_training_time:
                new_preferences = [
                    p for p in all_preferences
                    if p.get('timestamp', '') > last_training_time
                ]
            
            # Check requirements
            min_preferences = 50  # Minimum preferences needed
            min_new_preferences = 20  # Minimum new preferences since last training
            
            can_train = (
                len(all_preferences) >= min_preferences and
                len(new_preferences) >= min_new_preferences
            )
            
            # Calculate preference distribution
            preference_distribution = {'A': 0, 'B': 0}
            for pref in new_preferences:
                user_pref = pref.get('user_preference', '')
                if user_pref in preference_distribution:
                    preference_distribution[user_pref] += 1
            
            requirements = {
                'can_train': can_train,
                'current_model_version': current_model_version,
                'total_preferences': len(all_preferences),
                'current_model_preferences': len(current_model_preferences),
                'new_preferences': len(new_preferences),
                'last_training_time': last_training_time,
                'requirements': {
                    'min_total_preferences': min_preferences,
                    'min_new_preferences': min_new_preferences,
                    'total_preferences_met': len(all_preferences) >= min_preferences,
                    'new_preferences_met': len(new_preferences) >= min_new_preferences
                },
                'preference_distribution': preference_distribution,
                'recommendation': _get_training_recommendation(
                    len(all_preferences), len(new_preferences), can_train
                )
            }
            
            return requirements
            
    except Exception as e:
        return {
            'can_train': False,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }


@celery_app.task(bind=True, name='tasks.training_tasks.evaluate_model_performance')
def evaluate_model_performance(self, model_version: str, test_queries: list = None):
    """
    Evaluate model performance with test queries.
    
    Args:
        model_version: Model version to evaluate
        test_queries: Optional list of test queries
    """
    try:
        self.update_state(
            state='PROGRESS',
            meta={'status': 'Starting model evaluation', 'progress': 0}
        )
        
        app = create_app()
        
        with app.app_context():
            qwen_generator = QwenGenerator()
            
            # Load model
            self.update_state(
                state='PROGRESS',
                meta={'status': f'Loading model {model_version}', 'progress': 20}
            )
            
            if not qwen_generator.load_model_version(model_version):
                raise Exception(f"Failed to load model version {model_version}")
            
            # Run performance validation
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Running performance tests', 'progress': 50}
            )
            
            validation_result = qwen_generator.validate_model_performance(test_queries)
            
            # Additional metrics
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Calculating additional metrics', 'progress': 80}
            )
            
            model_info = qwen_generator.get_model_info()
            
            evaluation_result = {
                'status': 'completed',
                'model_version': model_version,
                'evaluation_timestamp': datetime.utcnow().isoformat(),
                'model_info': model_info,
                'performance_validation': validation_result,
                'recommendations': _generate_model_recommendations(validation_result)
            }
            
            self.update_state(
                state='SUCCESS',
                meta={
                    'status': 'Model evaluation completed',
                    'progress': 100,
                    'result': evaluation_result
                }
            )
            
            return evaluation_result
            
    except Exception as e:
        self.update_state(
            state='FAILURE',
            meta={'status': f'Model evaluation failed: {str(e)}', 'error': str(e)}
        )
        
        raise Exception(str(e))


@celery_app.task(name='tasks.training_tasks.cleanup_old_checkpoints')
def cleanup_old_checkpoints(keep_latest: int = 5):
    """
    Clean up old model checkpoints to save disk space.
    
    Args:
        keep_latest: Number of latest checkpoints to keep
    """
    try:
        app = create_app()
        
        with app.app_context():
            qwen_generator = QwenGenerator()
            
            # Get all available model versions
            versions = qwen_generator.get_available_model_versions()
            
            # Sort by creation date (newest first)
            versions.sort(key=lambda x: x.get('created_at', ''), reverse=True)
            
            # Keep only the specified number of latest versions
            versions_to_delete = versions[keep_latest:]
            
            deleted_count = 0
            freed_space_mb = 0
            
            for version_info in versions_to_delete:
                try:
                    version_path = Path(version_info['path'])
                    
                    if version_path.exists() and version_path.is_dir():
                        # Calculate size before deletion
                        size_mb = version_info.get('size_mb', 0)
                        
                        # Delete checkpoint directory
                        import shutil
                        shutil.rmtree(version_path)
                        
                        deleted_count += 1
                        freed_space_mb += size_mb
                        
                except Exception as e:
                    continue  # Skip failed deletions
            
            cleanup_result = {
                'status': 'completed',
                'cleanup_timestamp': datetime.utcnow().isoformat(),
                'total_versions_checked': len(versions),
                'versions_deleted': deleted_count,
                'versions_kept': len(versions) - deleted_count,
                'freed_space_mb': freed_space_mb,
                'keep_latest_count': keep_latest
            }
            
            return cleanup_result
            
    except Exception as e:
        return {
            'status': 'failed',
            'error': str(e),
            'cleanup_timestamp': datetime.utcnow().isoformat()
        }


def _get_training_recommendation(total_prefs: int, new_prefs: int, can_train: bool) -> str:
    """Generate training recommendation based on preference counts."""
    if can_train:
        return "Ready for training! You have sufficient preferences for DPO fine-tuning."
    elif total_prefs < 50:
        return f"Need {50 - total_prefs} more total preferences before training can begin."
    elif new_prefs < 20:
        return f"Need {20 - new_prefs} more new preferences since last training."
    else:
        return "Requirements check failed. Please verify your preferences data."


def _generate_model_recommendations(validation_result: dict) -> list:
    """Generate recommendations based on model performance."""
    recommendations = []
    
    success_rate = validation_result.get('success_rate', 0)
    avg_time = validation_result.get('average_generation_time_ms', 0)
    
    if success_rate < 0.8:
        recommendations.append("Model success rate is low. Consider additional training or debugging.")
    
    if avg_time > 5000:  # 5 seconds
        recommendations.append("Model generation time is high. Consider optimization or hardware upgrade.")
    
    if success_rate >= 0.95:
        recommendations.append("Model performance is excellent. Ready for production use.")
    
    if not recommendations:
        recommendations.append("Model performance is within acceptable ranges.")
    
    return recommendations