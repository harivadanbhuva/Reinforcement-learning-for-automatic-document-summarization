"""
Celery tasks for system maintenance and optimization.

Handles periodic maintenance tasks like index optimization,
cache cleanup, and system health monitoring.
"""

import time
from datetime import datetime, timedelta
from pathlib import Path
from celery import current_task
from celery_app import celery_app

# Import Flask app context
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app
from app.services.faiss_manager import FaissManager
from app.services.embedding_service import EmbeddingService
from app.services.jsonl_logger import JsonlLogger


@celery_app.task(bind=True, name='tasks.maintenance_tasks.optimize_faiss_index')
def optimize_faiss_index(self):
    """
    Optimize FAISS index for better performance.
    """
    try:
        self.update_state(
            state='PROGRESS',
            meta={'status': 'Starting FAISS index optimization', 'progress': 0}
        )
        
        app = create_app()
        
        with app.app_context():
            faiss_manager = FaissManager()
            
            # Get current index info
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Analyzing current index', 'progress': 20}
            )
            
            index_info = faiss_manager.get_index_info()
            original_size = index_info.get('index_file_size_mb', 0)
            
            # Backup current index
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Creating index backup', 'progress': 40}
            )
            
            backup_path = faiss_manager.index_path / f"backup_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}"
            backup_path.mkdir(exist_ok=True)
            
            import shutil
            if faiss_manager.index_file.exists():
                shutil.copy2(faiss_manager.index_file, backup_path / "index.faiss")
            if faiss_manager.metadata_file.exists():
                shutil.copy2(faiss_manager.metadata_file, backup_path / "metadata.pkl")
            
            # Rebuild index (simplified - in practice would implement more sophisticated optimization)
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Rebuilding optimized index', 'progress': 60}
            )
            
            # For now, just save the index which may optimize internal structure
            faiss_manager._save_index()
            
            # Validate optimized index
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Validating optimized index', 'progress': 80}
            )
            
            # Test search functionality
            test_results = []
            try:
                results = faiss_manager.search("optimization test", top_k=5)
                test_results.append({'test': 'search', 'status': 'success', 'results': len(results)})
            except Exception as e:
                test_results.append({'test': 'search', 'status': 'failed', 'error': str(e)})
            
            # Get new index info
            new_index_info = faiss_manager.get_index_info()
            new_size = new_index_info.get('index_file_size_mb', 0)
            
            optimization_result = {
                'status': 'completed',
                'optimization_timestamp': datetime.utcnow().isoformat(),
                'original_size_mb': original_size,
                'new_size_mb': new_size,
                'size_change_mb': new_size - original_size,
                'backup_path': str(backup_path),
                'test_results': test_results,
                'index_info': new_index_info
            }
            
            self.update_state(
                state='SUCCESS',
                meta={
                    'status': 'FAISS index optimization completed',
                    'progress': 100,
                    'result': optimization_result
                }
            )
            
            return optimization_result
            
    except Exception as e:
        self.update_state(
            state='FAILURE',
            meta={'status': f'Index optimization failed: {str(e)}', 'error': str(e)}
        )
        
        raise Exception(str(e))


@celery_app.task(bind=True, name='tasks.maintenance_tasks.cleanup_cache')
def cleanup_cache(self, older_than_days: int = 7):
    """
    Clean up old cache files and temporary data.
    
    Args:
        older_than_days: Remove cache files older than this many days
    """
    try:
        self.update_state(
            state='PROGRESS',
            meta={'status': 'Starting cache cleanup', 'progress': 0}
        )
        
        app = create_app()
        
        with app.app_context():
            embedding_service = EmbeddingService()
            
            # Clean embedding cache
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Cleaning embedding cache', 'progress': 25}
            )
            
            cache_cleaned = 0
            if embedding_service.cache_enabled:
                # Get cache directory
                cache_dir = embedding_service.cache_dir
                
                if cache_dir.exists():
                    cutoff_time = datetime.utcnow() - timedelta(days=older_than_days)
                    
                    for cache_file in cache_dir.glob("*.json"):
                        try:
                            file_time = datetime.fromtimestamp(cache_file.stat().st_mtime)
                            if file_time < cutoff_time:
                                cache_file.unlink()
                                cache_cleaned += 1
                        except Exception:
                            continue
            
            # Clean temporary files
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Cleaning temporary files', 'progress': 50}
            )
            
            temp_cleaned = 0
            temp_dirs = ['/tmp', './temp', './cache']
            
            for temp_dir in temp_dirs:
                temp_path = Path(temp_dir)
                if temp_path.exists():
                    try:
                        cutoff_time = datetime.utcnow() - timedelta(days=older_than_days)
                        
                        for temp_file in temp_path.glob("*summarization*"):
                            try:
                                if temp_file.is_file():
                                    file_time = datetime.fromtimestamp(temp_file.stat().st_mtime)
                                    if file_time < cutoff_time:
                                        temp_file.unlink()
                                        temp_cleaned += 1
                            except Exception:
                                continue
                    except Exception:
                        continue
            
            # Clean old log files
            self.update_state(
                state='PROGRESS',
                meta={'status': 'Cleaning old log files', 'progress': 75}
            )
            
            logs_cleaned = 0
            log_dirs = ['./logs', '/var/log']
            
            for log_dir in log_dirs:
                log_path = Path(log_dir)
                if log_path.exists():
                    try:
                        cutoff_time = datetime.utcnow() - timedelta(days=older_than_days * 2)  # Keep logs longer
                        
                        for log_file in log_path.glob("*.log*"):
                            try:
                                if log_file.is_file():
                                    file_time = datetime.fromtimestamp(log_file.stat().st_mtime)
                                    if file_time < cutoff_time and log_file.stat().st_size > 100 * 1024 * 1024:  # 100MB
                                        log_file.unlink()
                                        logs_cleaned += 1
                            except Exception:
                                continue
                    except Exception:
                        continue
            
            cleanup_result = {
                'status': 'completed',
                'cleanup_timestamp': datetime.utcnow().isoformat(),
                'older_than_days': older_than_days,
                'files_cleaned': {
                    'embedding_cache': cache_cleaned,
                    'temporary_files': temp_cleaned,
                    'log_files': logs_cleaned,
                    'total': cache_cleaned + temp_cleaned + logs_cleaned
                }
            }
            
            self.update_state(
                state='SUCCESS',
                meta={
                    'status': f'Cache cleanup completed: {cleanup_result["files_cleaned"]["total"]} files removed',
                    'progress': 100,
                    'result': cleanup_result
                }
            )
            
            return cleanup_result
            
    except Exception as e:
        self.update_state(
            state='FAILURE',
            meta={'status': f'Cache cleanup failed: {str(e)}', 'error': str(e)}
        )
        
        raise Exception(str(e))


@celery_app.task(name='tasks.maintenance_tasks.system_health_check')
def system_health_check():
    """
    Perform comprehensive system health check.
    """
    try:
        app = create_app()
        
        with app.app_context():
            health_status = {
                'timestamp': datetime.utcnow().isoformat(),
                'overall_status': 'healthy',
                'components': {},
                'recommendations': []
            }
            
            # Check FAISS index health
            try:
                faiss_manager = FaissManager()
                index_info = faiss_manager.get_index_info()
                
                faiss_health = {
                    'status': 'healthy' if index_info['total_vectors'] > 0 else 'warning',
                    'total_vectors': index_info['total_vectors'],
                    'total_documents': index_info['total_documents'],
                    'index_trained': index_info['index_trained']
                }
                
                if index_info['total_vectors'] == 0:
                    health_status['recommendations'].append("FAISS index is empty - no documents have been processed")
                
                health_status['components']['faiss'] = faiss_health
                
            except Exception as e:
                health_status['components']['faiss'] = {
                    'status': 'error',
                    'error': str(e)
                }
                health_status['overall_status'] = 'degraded'
            
            # Check embedding service health
            try:
                embedding_service = EmbeddingService()
                embedding_stats = embedding_service.get_embedding_statistics()
                
                embedding_health = {
                    'status': 'healthy',
                    'cache_enabled': embedding_stats['cache_enabled'],
                    'cache_size': embedding_stats['cache_size'],
                    'model': embedding_stats['model']
                }
                
                health_status['components']['embeddings'] = embedding_health
                
            except Exception as e:
                health_status['components']['embeddings'] = {
                    'status': 'error',
                    'error': str(e)
                }
                health_status['overall_status'] = 'degraded'
            
            # Check episode logging health
            try:
                logger = JsonlLogger()
                
                # Check each episode file
                episode_health = {}
                
                for filename in ['phase2_rag.jsonl', 'phase3_ab_testing.jsonl', 'phase4_training.jsonl', 'preferences.jsonl']:
                    try:
                        stats = logger.get_episode_statistics(filename)
                        episode_health[filename] = {
                            'status': 'healthy',
                            'total_episodes': stats['total_episodes'],
                            'file_size_mb': stats.get('file_size_mb', 0)
                        }
                    except Exception as e:
                        episode_health[filename] = {
                            'status': 'error',
                            'error': str(e)
                        }
                
                health_status['components']['episode_logging'] = episode_health
                
            except Exception as e:
                health_status['components']['episode_logging'] = {
                    'status': 'error',
                    'error': str(e)
                }
                health_status['overall_status'] = 'degraded'
            
            # Check disk space
            try:
                import shutil
                
                disk_usage = {}
                paths_to_check = ['./data', './models', './cache', './logs']
                
                for path in paths_to_check:
                    path_obj = Path(path)
                    if path_obj.exists():
                        total, used, free = shutil.disk_usage(path_obj)
                        disk_usage[path] = {
                            'total_gb': round(total / (1024**3), 2),
                            'used_gb': round(used / (1024**3), 2),
                            'free_gb': round(free / (1024**3), 2),
                            'usage_percent': round((used / total) * 100, 2)
                        }
                        
                        if (used / total) > 0.9:  # 90% full
                            health_status['recommendations'].append(f"Disk usage for {path} is high: {disk_usage[path]['usage_percent']:.1f}%")
                
                health_status['components']['disk_usage'] = {
                    'status': 'healthy',
                    'paths': disk_usage
                }
                
            except Exception as e:
                health_status['components']['disk_usage'] = {
                    'status': 'error',
                    'error': str(e)
                }
            
            # Determine overall status
            component_statuses = [comp.get('status', 'unknown') for comp in health_status['components'].values()]
            
            if 'error' in component_statuses:
                health_status['overall_status'] = 'degraded'
            elif 'warning' in component_statuses:
                health_status['overall_status'] = 'warning'
            
            # Add general recommendations
            if not health_status['recommendations']:
                health_status['recommendations'].append("System is operating normally")
            
            return health_status
            
    except Exception as e:
        return {
            'timestamp': datetime.utcnow().isoformat(),
            'overall_status': 'error',
            'error': str(e),
            'components': {}
        }


@celery_app.task(name='tasks.maintenance_tasks.archive_old_episodes')
def archive_old_episodes(archive_older_than_days: int = 90):
    """
    Archive old episode data to reduce file sizes.
    
    Args:
        archive_older_than_days: Archive episodes older than this many days
    """
    try:
        app = create_app()
        
        with app.app_context():
            logger = JsonlLogger()
            
            archive_results = {}
            
            # Archive each episode file
            for filename in ['phase2_rag.jsonl', 'phase3_ab_testing.jsonl', 'phase4_training.jsonl']:
                try:
                    # Create archive
                    archive_timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
                    archive_filename = f"{filename.replace('.jsonl', '')}_archive_{archive_timestamp}.jsonl"
                    
                    # Get old episodes
                    cutoff_date = (datetime.utcnow() - timedelta(days=archive_older_than_days)).isoformat()
                    
                    all_episodes = logger.read_episodes(filename)
                    old_episodes = [ep for ep in all_episodes if ep.get('timestamp', '') < cutoff_date]
                    recent_episodes = [ep for ep in all_episodes if ep.get('timestamp', '') >= cutoff_date]
                    
                    if old_episodes:
                        # Save archived episodes
                        archive_path = logger.data_path / 'archive'
                        archive_path.mkdir(exist_ok=True)
                        
                        archive_file = archive_path / archive_filename
                        
                        with open(archive_file, 'w', encoding='utf-8') as f:
                            for episode in old_episodes:
                                f.write(json.dumps(episode, ensure_ascii=False) + '\n')
                        
                        # Rewrite main file with only recent episodes
                        main_file = logger.episode_files[filename]
                        
                        with open(main_file, 'w', encoding='utf-8') as f:
                            for episode in recent_episodes:
                                f.write(json.dumps(episode, ensure_ascii=False) + '\n')
                        
                        archive_results[filename] = {
                            'status': 'completed',
                            'episodes_archived': len(old_episodes),
                            'episodes_remaining': len(recent_episodes),
                            'archive_file': str(archive_file)
                        }
                    else:
                        archive_results[filename] = {
                            'status': 'no_action',
                            'message': 'No episodes old enough to archive'
                        }
                        
                except Exception as e:
                    archive_results[filename] = {
                        'status': 'error',
                        'error': str(e)
                    }
            
            total_archived = sum(
                result.get('episodes_archived', 0) 
                for result in archive_results.values()
            )
            
            return {
                'status': 'completed',
                'archive_timestamp': datetime.utcnow().isoformat(),
                'archive_older_than_days': archive_older_than_days,
                'total_episodes_archived': total_archived,
                'results': archive_results
            }
            
    except Exception as e:
        return {
            'status': 'failed',
            'error': str(e),
            'archive_timestamp': datetime.utcnow().isoformat()
        }


@celery_app.task(name='tasks.maintenance_tasks.generate_system_report')
def generate_system_report():
    """
    Generate comprehensive system usage and performance report.
    """
    try:
        app = create_app()
        
        with app.app_context():
            logger = JsonlLogger()
            
            report = {
                'report_timestamp': datetime.utcnow().isoformat(),
                'report_period': '30_days',
                'summary': {},
                'detailed_stats': {}
            }
            
            # Calculate date range
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=30)
            
            # Analyze each phase
            phase_stats = {}
            
            for phase, filename in [
                ('rag_generation', 'phase2_rag.jsonl'),
                ('ab_testing', 'phase3_ab_testing.jsonl'),
                ('training', 'phase4_training.jsonl')
            ]:
                try:
                    episodes = logger.read_episodes(filename)
                    
                    # Filter to report period
                    period_episodes = [
                        ep for ep in episodes 
                        if start_date.isoformat() <= ep.get('timestamp', '') <= end_date.isoformat()
                    ]
                    
                    phase_stats[phase] = {
                        'total_episodes': len(period_episodes),
                        'daily_average': len(period_episodes) / 30,
                        'peak_day': None,  # Would calculate actual peak
                        'unique_users': len(set(ep.get('user_id', 'anonymous') for ep in period_episodes))
                    }
                    
                    if phase == 'ab_testing' and period_episodes:
                        # Calculate preference distribution
                        preferences = {}
                        for ep in period_episodes:
                            pref = ep.get('user_preference')
                            if pref:
                                preferences[pref] = preferences.get(pref, 0) + 1
                        
                        phase_stats[phase]['preferences'] = preferences
                    
                except Exception as e:
                    phase_stats[phase] = {'error': str(e)}
            
            report['detailed_stats']['phases'] = phase_stats
            
            # System health summary
            try:
                health_check = system_health_check()
                report['detailed_stats']['system_health'] = health_check
            except Exception as e:
                report['detailed_stats']['system_health'] = {'error': str(e)}
            
            # Generate summary
            total_interactions = sum(
                stats.get('total_episodes', 0) 
                for stats in phase_stats.values()
            )
            
            report['summary'] = {
                'total_interactions_30_days': total_interactions,
                'average_daily_interactions': total_interactions / 30,
                'system_status': health_check.get('overall_status', 'unknown'),
                'active_phases': len([p for p in phase_stats.values() if p.get('total_episodes', 0) > 0])
            }
            
            return report
            
    except Exception as e:
        return {
            'status': 'failed',
            'error': str(e),
            'report_timestamp': datetime.utcnow().isoformat()
        }