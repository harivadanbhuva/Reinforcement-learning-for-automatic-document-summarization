"""
Celery tasks for asynchronous processing.

This package contains background tasks for:
- Document embedding and processing
- DPO model training
- Index maintenance and optimization
"""