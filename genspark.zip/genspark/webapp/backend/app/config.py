"""
Configuration settings for the Flask application.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    """Base configuration class."""
    
    # Basic Flask config
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    
    # API Keys
    GROQ_API_KEY = os.environ.get('GROQ_API_KEY')
    HUGGING_FACE_TOKEN = os.environ.get('HUGGING_FACE_TOKEN')
    DUCKDUCKGO_API_KEY = os.environ.get('DUCKDUCKGO_API_KEY', '')
    WIKIPEDIA_API_KEY = os.environ.get('WIKIPEDIA_API_KEY', '')
    
    # Model Configuration
    MODEL_BASE_NAME = os.environ.get('MODEL_BASE_NAME', 'Qwen/Qwen2.5-7B-Instruct')
    MODEL_CACHE_DIR = Path(os.environ.get('MODEL_CACHE_DIR', './models/cache'))
    ACTIVE_MODEL_VERSION = os.environ.get('ACTIVE_MODEL_VERSION', 'qwen-sft-base')
    
    # Service URLs
    OLLAMA_HOST = os.environ.get('OLLAMA_HOST', 'http://localhost:11434')
    REDIS_URL = os.environ.get('REDIS_URL', 'redis://localhost:6379')
    
    # Database Paths
    FAISS_INDEX_PATH = Path(os.environ.get('FAISS_INDEX_PATH', './data/embeddings/faiss_index'))
    JSONL_DATA_PATH = Path(os.environ.get('JSONL_DATA_PATH', './data/episodes'))
    PREFERENCES_PATH = Path(os.environ.get('PREFERENCES_PATH', './data/preferences'))
    DOCUMENTS_PATH = Path('./data/documents')
    CHECKPOINTS_PATH = Path('./models/checkpoints')
    
    # Training Configuration
    BATCH_SIZE = int(os.environ.get('BATCH_SIZE', 64))
    LEARNING_RATE = float(os.environ.get('LEARNING_RATE', 5e-6))
    DPO_BETA = float(os.environ.get('DPO_BETA', 0.1))
    MAX_EPOCHS = int(os.environ.get('MAX_EPOCHS', 3))
    GRADIENT_ACCUMULATION_STEPS = int(os.environ.get('GRADIENT_ACCUMULATION_STEPS', 4))
    
    # Server Configuration
    FLASK_HOST = os.environ.get('FLASK_HOST', '0.0.0.0')
    FLASK_PORT = int(os.environ.get('FLASK_PORT', 5000))
    FLASK_DEBUG = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    
    # Celery Configuration
    CELERY_BROKER_URL = os.environ.get('CELERY_BROKER_URL', 'redis://localhost:6379/0')
    CELERY_RESULT_BACKEND = os.environ.get('CELERY_RESULT_BACKEND', 'redis://localhost:6379/0')
    
    # Cache Configuration
    CACHE_TYPE = "RedisCache"
    CACHE_REDIS_URL = REDIS_URL
    CACHE_DEFAULT_TIMEOUT = 300
    
    # Resource Limits
    MAX_DOCUMENT_SIZE_MB = int(os.environ.get('MAX_DOCUMENT_SIZE_MB', 50))
    MAX_CONTEXT_LENGTH = int(os.environ.get('MAX_CONTEXT_LENGTH', 4096))
    MAX_SUMMARY_LENGTH = int(os.environ.get('MAX_SUMMARY_LENGTH', 500))
    EMBEDDING_BATCH_SIZE = int(os.environ.get('EMBEDDING_BATCH_SIZE', 32))
    
    # Feature Flags
    ENABLE_AGENTS = os.environ.get('ENABLE_AGENTS', 'true').lower() == 'true'
    ENABLE_DPO_TRAINING = os.environ.get('ENABLE_DPO_TRAINING', 'true').lower() == 'true'
    ENABLE_CACHING = os.environ.get('ENABLE_CACHING', 'true').lower() == 'true'
    ENABLE_METRICS = os.environ.get('ENABLE_METRICS', 'true').lower() == 'true'
    
    # Development Settings
    DEV_MODE = os.environ.get('DEV_MODE', 'false').lower() == 'true'
    MOCK_GROQ_API = os.environ.get('MOCK_GROQ_API', 'false').lower() == 'true'
    MOCK_OLLAMA = os.environ.get('MOCK_OLLAMA', 'false').lower() == 'true'
    
    # Logging
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOG_FILE = os.environ.get('LOG_FILE', './logs/app.log')
    
    @classmethod
    def ensure_directories(cls):
        """Create necessary directories if they don't exist."""
        directories = [
            cls.MODEL_CACHE_DIR,
            cls.FAISS_INDEX_PATH,
            cls.JSONL_DATA_PATH,
            cls.PREFERENCES_PATH,
            cls.DOCUMENTS_PATH / 'raw',
            cls.DOCUMENTS_PATH / 'processed',
            cls.CHECKPOINTS_PATH,
            Path('./logs')
        ]
        
        for directory in directories:
            directory.mkdir(parents=True, exist_ok=True)


class DevelopmentConfig(Config):
    """Development configuration."""
    FLASK_DEBUG = True
    DEV_MODE = True


class ProductionConfig(Config):
    """Production configuration."""
    FLASK_DEBUG = False
    DEV_MODE = False


class TestingConfig(Config):
    """Testing configuration."""
    TESTING = True
    FLASK_DEBUG = True
    REDIS_URL = 'redis://localhost:6379/1'  # Use different Redis DB for testing


# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}