"""
Summarization API endpoints.

Handles RAG-based summarization (Phase 2) and Qwen model dual summarization (Phase 3).
"""

import uuid
from datetime import datetime
from flask import Blueprint, request, jsonify, current_app

from app.services.rag_pipeline import RagPipeline
from app.services.qwen_generator import QwenGenerator
from app.services.agent_service import AgentService
from app.services.jsonl_logger import JsonlLogger
from app.utils.validators import validate_query

summarization_bp = Blueprint('summarization', __name__)


@summarization_bp.route('/summarize/rag', methods=['POST'])
def generate_rag_summary():
    """
    Generate summary using RAG pipeline (Phase 2).
    
    Expects JSON:
    {
        "query": "What are the main benefits?",
        "doc_id": "document_id_or_null",
        "mode": "extractive" or "abstractive"
    }
    
    Returns:
        JSON with generated summary and metadata
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'JSON data required'}), 400
        
        # Validate input
        query = data.get('query')
        if not query:
            return jsonify({'error': 'Query is required'}), 400
        
        doc_id = data.get('doc_id')
        mode = data.get('mode', 'extractive')
        
        if mode not in ['extractive', 'abstractive']:
            return jsonify({'error': 'Mode must be "extractive" or "abstractive"'}), 400
        
        # Initialize services
        rag_pipeline = RagPipeline()
        logger = JsonlLogger()
        
        episode_id = str(uuid.uuid4())
        
        if mode == 'extractive':
            # Extractive RAG summarization
            result = rag_pipeline.generate_extractive_summary(query, doc_id)
            
        else:
            # Abstractive summarization with agents
            if not current_app.config['ENABLE_AGENTS']:
                return jsonify({'error': 'Agent-based summarization is disabled'}), 400
            
            agent_service = AgentService()
            result = rag_pipeline.generate_abstractive_summary(query, doc_id, agent_service)
        
        # Log episode
        episode_data = {
            'episode_id': episode_id,
            'phase': 'rag_generation',
            'timestamp': datetime.utcnow().isoformat(),
            'query': query,
            'doc_id': doc_id,
            'mode': mode,
            'context': result.get('context', ''),
            'summary': result['summary'],
            'sources': result.get('sources', {}),
            'model_used': result.get('model', 'gpt-oss-120b'),
            'generation_time_ms': result.get('generation_time_ms', 0)
        }
        
        logger.log_episode(episode_data, 'phase2_rag.jsonl')
        
        return jsonify({
            'episode_id': episode_id,
            'summary': result['summary'],
            'mode': mode,
            'sources': result.get('sources', {}),
            'metadata': {
                'query': query,
                'doc_id': doc_id,
                'context_length': len(result.get('context', '')),
                'summary_length': len(result['summary']),
                'generation_time_ms': result.get('generation_time_ms', 0)
            }
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"RAG summarization error: {str(e)}")
        return jsonify({'error': 'Failed to generate summary'}), 500


@summarization_bp.route('/summarize/qwen', methods=['POST'])
def generate_qwen_summaries():
    """
    Generate dual summaries using fine-tuned Qwen model (Phase 3).
    
    Expects JSON:
    {
        "query": "What are the main benefits?",
        "context": "Retrieved context from FAISS...",
        "doc_id": "optional_document_id"
    }
    
    Returns:
        JSON with both Summary A (extractive) and Summary B (abstractive)
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'JSON data required'}), 400
        
        # Validate input
        query = data.get('query')
        if not query:
            return jsonify({'error': 'Query is required'}), 400
        
        context = data.get('context', '')
        doc_id = data.get('doc_id')
        
        # If context not provided, retrieve from FAISS
        if not context and doc_id:
            rag_pipeline = RagPipeline()
            context_result = rag_pipeline.retrieve_context(query, doc_id)
            context = context_result.get('context', '')
        
        # Initialize Qwen generator
        qwen_generator = QwenGenerator()
        logger = JsonlLogger()
        
        episode_id = str(uuid.uuid4())
        
        # Generate both summaries
        result = qwen_generator.generate_dual_summaries(query, context)
        
        # Log A/B testing episode
        episode_data = {
            'episode_id': episode_id,
            'phase': 'ab_testing',
            'timestamp': datetime.utcnow().isoformat(),
            'query': query,
            'context': context,
            'doc_id': doc_id,
            'summary_a': result['summary_a'],
            'summary_b': result['summary_b'],
            'model_version': result['model_version'],
            'generation_metadata': {
                'tokens_a': result.get('tokens_a', 0),
                'tokens_b': result.get('tokens_b', 0),
                'generation_time_ms': result.get('generation_time_ms', 0)
            }
        }
        
        logger.log_episode(episode_data, 'phase3_ab_testing.jsonl')
        
        return jsonify({
            'episode_id': episode_id,
            'summary_a': result['summary_a'],
            'summary_b': result['summary_b'],
            'model_version': result['model_version'],
            'metadata': {
                'query': query,
                'context_length': len(context),
                'tokens_a': result.get('tokens_a', 0),
                'tokens_b': result.get('tokens_b', 0),
                'generation_time_ms': result.get('generation_time_ms', 0)
            }
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Qwen summarization error: {str(e)}")
        return jsonify({'error': 'Failed to generate dual summaries'}), 500


@summarization_bp.route('/summarize/history', methods=['GET'])
def get_summary_history():
    """
    Get summarization history for a user or document.
    
    Query parameters:
        - doc_id: Filter by document ID (optional)
        - phase: Filter by phase (rag_generation, ab_testing) (optional)
        - limit: Number of entries to return (default: 20)
        - offset: Offset for pagination (default: 0)
    
    Returns:
        JSON with summarization history
    """
    try:
        doc_id = request.args.get('doc_id')
        phase = request.args.get('phase')
        limit = min(int(request.args.get('limit', 20)), 100)  # Max 100
        offset = int(request.args.get('offset', 0))
        
        logger = JsonlLogger()
        
        # Build filters
        filters = {}
        if doc_id:
            filters['doc_id'] = doc_id
        if phase:
            filters['phase'] = phase
        
        # Get history based on phase
        if phase == 'rag_generation' or not phase:
            rag_history = logger.read_episodes('phase2_rag.jsonl', filters, limit, offset)
        else:
            rag_history = []
        
        if phase == 'ab_testing' or not phase:
            ab_history = logger.read_episodes('phase3_ab_testing.jsonl', filters, limit, offset)
        else:
            ab_history = []
        
        # Combine and sort by timestamp
        all_history = rag_history + ab_history
        all_history.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
        # Apply limit and offset to combined results
        paginated_history = all_history[offset:offset + limit]
        
        return jsonify({
            'history': paginated_history,
            'count': len(paginated_history),
            'total_available': len(all_history),
            'filters_applied': filters
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get summary history error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve summary history'}), 500


@summarization_bp.route('/summarize/batch', methods=['POST'])
def batch_summarize():
    """
    Generate summaries for multiple queries in batch.
    
    Expects JSON:
    {
        "queries": ["Query 1", "Query 2", ...],
        "doc_id": "optional_document_id",
        "mode": "extractive" or "abstractive"
    }
    
    Returns:
        JSON with batch summary results
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'JSON data required'}), 400
        
        queries = data.get('queries', [])
        if not queries or not isinstance(queries, list):
            return jsonify({'error': 'Queries list is required'}), 400
        
        if len(queries) > 10:  # Limit batch size
            return jsonify({'error': 'Maximum 10 queries per batch'}), 400
        
        doc_id = data.get('doc_id')
        mode = data.get('mode', 'extractive')
        
        # Initialize services
        rag_pipeline = RagPipeline()
        results = []
        
        for i, query in enumerate(queries):
            try:
                if mode == 'extractive':
                    result = rag_pipeline.generate_extractive_summary(query, doc_id)
                else:
                    agent_service = AgentService()
                    result = rag_pipeline.generate_abstractive_summary(query, doc_id, agent_service)
                
                results.append({
                    'query_index': i,
                    'query': query,
                    'summary': result['summary'],
                    'status': 'success'
                })
                
            except Exception as e:
                results.append({
                    'query_index': i,
                    'query': query,
                    'error': str(e),
                    'status': 'failed'
                })
        
        return jsonify({
            'batch_id': str(uuid.uuid4()),
            'results': results,
            'successful_count': len([r for r in results if r['status'] == 'success']),
            'failed_count': len([r for r in results if r['status'] == 'failed'])
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Batch summarization error: {str(e)}")
        return jsonify({'error': 'Batch summarization failed'}), 500