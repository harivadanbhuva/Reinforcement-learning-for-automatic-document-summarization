"""
Document management API endpoints.

Handles document upload, processing, embedding, and management operations.
"""

import os
import uuid
from pathlib import Path
from flask import Blueprint, request, jsonify, current_app
from werkzeug.utils import secure_filename
from werkzeug.exceptions import BadRequest, RequestEntityTooLarge

from app.services.document_processor import DocumentProcessor
from app.services.embedding_service import EmbeddingService
from app.services.faiss_manager import FaissManager
from app.utils.validators import validate_file_type, validate_file_size
from tasks.embedding_tasks import embed_document_async

documents_bp = Blueprint('documents', __name__)

# Allowed file extensions
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'docx', 'doc'}

def allowed_file(filename):
    """Check if file extension is allowed."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@documents_bp.route('/upload', methods=['POST'])
def upload_document():
    """
    Upload and process a document.
    
    Returns:
        JSON response with document ID and processing status
    """
    try:
        # Check if file is provided
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Validate file
        if not allowed_file(file.filename):
            return jsonify({
                'error': f'File type not allowed. Supported types: {", ".join(ALLOWED_EXTENSIONS)}'
            }), 400
        
        # Check file size
        file_size = len(file.read())
        file.seek(0)  # Reset file pointer
        
        max_size = current_app.config['MAX_DOCUMENT_SIZE_MB'] * 1024 * 1024
        if file_size > max_size:
            return jsonify({
                'error': f'File too large. Maximum size: {current_app.config["MAX_DOCUMENT_SIZE_MB"]}MB'
            }), 413
        
        # Generate unique document ID and secure filename
        doc_id = str(uuid.uuid4())
        filename = secure_filename(file.filename)
        
        # Save file to raw documents directory
        raw_path = current_app.config['DOCUMENTS_PATH'] / 'raw' / f"{doc_id}_{filename}"
        file.save(str(raw_path))
        
        # Process document asynchronously
        task = embed_document_async.delay(doc_id, str(raw_path), filename)
        
        return jsonify({
            'doc_id': doc_id,
            'filename': filename,
            'task_id': task.id,
            'status': 'processing',
            'message': 'Document uploaded successfully and processing started'
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Document upload error: {str(e)}")
        return jsonify({'error': 'Internal server error during upload'}), 500


@documents_bp.route('/documents', methods=['GET'])
def list_documents():
    """
    List all processed documents.
    
    Returns:
        JSON list of document information
    """
    try:
        processor = DocumentProcessor()
        documents = processor.list_documents()
        
        return jsonify({
            'documents': documents,
            'count': len(documents)
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"List documents error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve documents'}), 500


@documents_bp.route('/documents/<doc_id>', methods=['GET'])
def get_document(doc_id):
    """
    Get information about a specific document.
    
    Args:
        doc_id: Document identifier
        
    Returns:
        JSON document information
    """
    try:
        processor = DocumentProcessor()
        document_info = processor.get_document_info(doc_id)
        
        if not document_info:
            return jsonify({'error': 'Document not found'}), 404
        
        return jsonify(document_info), 200
        
    except Exception as e:
        current_app.logger.error(f"Get document error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve document information'}), 500


@documents_bp.route('/documents/<doc_id>', methods=['DELETE'])
def delete_document(doc_id):
    """
    Delete a document and its embeddings.
    
    Args:
        doc_id: Document identifier
        
    Returns:
        JSON confirmation of deletion
    """
    try:
        processor = DocumentProcessor()
        faiss_manager = FaissManager()
        
        # Remove document files
        success = processor.delete_document(doc_id)
        
        if not success:
            return jsonify({'error': 'Document not found'}), 404
        
        # Remove from FAISS index
        faiss_manager.remove_document(doc_id)
        
        return jsonify({
            'message': f'Document {doc_id} deleted successfully'
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Delete document error: {str(e)}")
        return jsonify({'error': 'Failed to delete document'}), 500


@documents_bp.route('/documents/<doc_id>/content', methods=['GET'])
def get_document_content(doc_id):
    """
    Get the processed content of a document.
    
    Args:
        doc_id: Document identifier
        
    Returns:
        JSON with document content and metadata
    """
    try:
        processor = DocumentProcessor()
        content = processor.get_document_content(doc_id)
        
        if not content:
            return jsonify({'error': 'Document content not found'}), 404
        
        return jsonify({
            'doc_id': doc_id,
            'content': content,
            'word_count': len(content.split()),
            'character_count': len(content)
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get document content error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve document content'}), 500


@documents_bp.route('/documents/<doc_id>/chunks', methods=['GET'])
def get_document_chunks(doc_id):
    """
    Get the chunks of a processed document.
    
    Args:
        doc_id: Document identifier
        
    Returns:
        JSON with document chunks
    """
    try:
        processor = DocumentProcessor()
        chunks = processor.get_document_chunks(doc_id)
        
        if not chunks:
            return jsonify({'error': 'Document chunks not found'}), 404
        
        return jsonify({
            'doc_id': doc_id,
            'chunks': chunks,
            'chunk_count': len(chunks)
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get document chunks error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve document chunks'}), 500


@documents_bp.route('/documents/search', methods=['POST'])
def search_documents():
    """
    Search documents using semantic similarity.
    
    Expects JSON: {"query": "search query", "top_k": 5}
    
    Returns:
        JSON with relevant document chunks
    """
    try:
        data = request.get_json()
        if not data or 'query' not in data:
            return jsonify({'error': 'Query is required'}), 400
        
        query = data['query']
        top_k = data.get('top_k', 5)
        
        faiss_manager = FaissManager()
        results = faiss_manager.search(query, top_k=top_k)
        
        return jsonify({
            'query': query,
            'results': results,
            'count': len(results)
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Document search error: {str(e)}")
        return jsonify({'error': 'Search failed'}), 500