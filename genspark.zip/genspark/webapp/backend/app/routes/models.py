"""
Model management API endpoints.

Handles model information, version management, and performance metrics.
"""

import os
import json
from datetime import datetime
from flask import Blueprint, request, jsonify, current_app
from pathlib import Path

from app.services.qwen_generator import QwenGenerator
from app.services.jsonl_logger import JsonlLogger

models_bp = Blueprint('models', __name__)


@models_bp.route('/model/info', methods=['GET'])
def get_model_info():
    """
    Get current model information and metadata.
    
    Returns:
        JSON with model version, configuration, and status
    """
    try:
        qwen_generator = QwenGenerator()
        logger = JsonlLogger()
        
        # Get current model information
        model_info = qwen_generator.get_model_info()
        
        # Get model configuration
        config_path = current_app.config['CHECKPOINTS_PATH'] / model_info['version'] / 'model_config.json'
        
        model_config = {}
        if config_path.exists():
            with open(config_path, 'r') as f:
                model_config = json.load(f)
        
        # Get training history for this model
        training_history = logger.read_episodes(
            'phase4_training.jsonl', 
            {'model_version_after': model_info['version']}
        )
        
        # Get preference statistics for this model
        preferences = logger.read_episodes(
            'preferences.jsonl',
            {'model_version': model_info['version']}
        )
        
        preference_stats = {
            'total_preferences': len(preferences),
            'preference_a': len([p for p in preferences if p.get('user_preference') == 'A']),
            'preference_b': len([p for p in preferences if p.get('user_preference') == 'B'])
        }
        
        if preference_stats['total_preferences'] > 0:
            preference_stats['preference_rate_a'] = preference_stats['preference_a'] / preference_stats['total_preferences']
            preference_stats['preference_rate_b'] = preference_stats['preference_b'] / preference_stats['total_preferences']
        else:
            preference_stats['preference_rate_a'] = 0
            preference_stats['preference_rate_b'] = 0
        
        return jsonify({
            'model_info': model_info,
            'model_config': model_config,
            'training_history': training_history[-5:] if training_history else [],  # Last 5 training sessions
            'preference_statistics': preference_stats,
            'performance_metrics': _calculate_model_performance_metrics(model_info['version'])
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get model info error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve model information'}), 500


@models_bp.route('/model/versions', methods=['GET'])
def list_model_versions():
    """
    List all available model versions/checkpoints.
    
    Returns:
        JSON with list of model versions and their metadata
    """
    try:
        checkpoints_path = current_app.config['CHECKPOINTS_PATH']
        
        if not checkpoints_path.exists():
            return jsonify({'versions': [], 'count': 0}), 200
        
        versions = []
        
        for version_dir in checkpoints_path.iterdir():
            if version_dir.is_dir():
                version_info = {
                    'version': version_dir.name,
                    'path': str(version_dir),
                    'created_at': None,
                    'size_mb': 0,
                    'config': {}
                }
                
                # Get creation time
                stat = version_dir.stat()
                version_info['created_at'] = datetime.fromtimestamp(stat.st_ctime).isoformat()
                
                # Calculate directory size
                total_size = sum(
                    f.stat().st_size for f in version_dir.rglob('*') if f.is_file()
                )
                version_info['size_mb'] = round(total_size / (1024 * 1024), 2)
                
                # Load model config if available
                config_path = version_dir / 'model_config.json'
                if config_path.exists():
                    try:
                        with open(config_path, 'r') as f:
                            version_info['config'] = json.load(f)
                    except Exception:
                        pass
                
                versions.append(version_info)
        
        # Sort by creation date (newest first)
        versions.sort(key=lambda x: x['created_at'] or '', reverse=True)
        
        return jsonify({
            'versions': versions,
            'count': len(versions)
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"List model versions error: {str(e)}")
        return jsonify({'error': 'Failed to list model versions'}), 500


@models_bp.route('/model/load/<version>', methods=['POST'])
def load_model_version(version):
    """
    Load a specific model version.
    
    Args:
        version: Model version identifier
    
    Returns:
        JSON confirmation of model loading
    """
    try:
        checkpoints_path = current_app.config['CHECKPOINTS_PATH']
        version_path = checkpoints_path / version
        
        if not version_path.exists():
            return jsonify({'error': f'Model version {version} not found'}), 404
        
        qwen_generator = QwenGenerator()
        
        # Load the specified model version
        success = qwen_generator.load_model_version(version)
        
        if not success:
            return jsonify({'error': 'Failed to load model version'}), 500
        
        # Update active model configuration
        model_config_path = Path('./models/model_config.json')
        
        config_data = {
            'active_model': version,
            'last_updated': datetime.utcnow().isoformat(),
            'loaded_at': datetime.utcnow().isoformat()
        }
        
        # Load existing config and update
        if model_config_path.exists():
            with open(model_config_path, 'r') as f:
                existing_config = json.load(f)
                existing_config.update(config_data)
                config_data = existing_config
        
        # Save updated config
        model_config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(model_config_path, 'w') as f:
            json.dump(config_data, f, indent=2)
        
        return jsonify({
            'message': f'Model version {version} loaded successfully',
            'active_version': version,
            'loaded_at': config_data['loaded_at']
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Load model version error: {str(e)}")
        return jsonify({'error': 'Failed to load model version'}), 500


@models_bp.route('/model/metrics', methods=['GET'])
def get_model_metrics():
    """
    Get comprehensive model performance metrics.
    
    Query parameters:
        - version: Specific model version (optional, defaults to current)
        - days: Number of days to include in metrics (default: 30)
    
    Returns:
        JSON with detailed performance metrics
    """
    try:
        version = request.args.get('version')
        days = int(request.args.get('days', 30))
        
        if not version:
            qwen_generator = QwenGenerator()
            model_info = qwen_generator.get_model_info()
            version = model_info['version']
        
        logger = JsonlLogger()
        
        # Calculate cutoff date
        from datetime import timedelta
        cutoff_date = (datetime.utcnow() - timedelta(days=days)).isoformat()
        
        # Get preferences for this model version
        preferences = logger.read_episodes('preferences.jsonl', {'model_version': version})
        recent_preferences = [
            p for p in preferences 
            if p.get('timestamp', '') >= cutoff_date
        ]
        
        # Get A/B testing episodes for this model
        ab_episodes = logger.read_episodes('phase3_ab_testing.jsonl', {'model_version': version})
        recent_ab_episodes = [
            ep for ep in ab_episodes 
            if ep.get('timestamp', '') >= cutoff_date
        ]
        
        # Calculate metrics
        metrics = {
            'model_version': version,
            'period_days': days,
            'total_interactions': len(recent_ab_episodes),
            'total_preferences': len(recent_preferences),
            'preference_rate': len(recent_preferences) / max(1, len(recent_ab_episodes)),
            
            'preference_distribution': {
                'A': len([p for p in recent_preferences if p.get('user_preference') == 'A']),
                'B': len([p for p in recent_preferences if p.get('user_preference') == 'B'])
            },
            
            'confidence_metrics': _calculate_confidence_metrics(recent_preferences),
            'performance_trends': _calculate_performance_trends(recent_preferences),
            'summary_length_analysis': _calculate_summary_length_analysis(recent_ab_episodes),
            'generation_time_analysis': _calculate_generation_time_analysis(recent_ab_episodes),
            
            'training_metrics': _get_training_metrics_for_model(version),
            'comparison_with_previous': _compare_with_previous_version(version, days)
        }
        
        return jsonify(metrics), 200
        
    except Exception as e:
        current_app.logger.error(f"Get model metrics error: {str(e)}")
        return jsonify({'error': 'Failed to calculate model metrics'}), 500


@models_bp.route('/model/benchmark', methods=['POST'])
def benchmark_model():
    """
    Run benchmark tests on the current model.
    
    Expects JSON:
    {
        "test_queries": ["Query 1", "Query 2", ...],
        "doc_id": "optional_document_id"
    }
    
    Returns:
        JSON with benchmark results
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'JSON data required'}), 400
        
        test_queries = data.get('test_queries', [])
        if not test_queries:
            return jsonify({'error': 'test_queries is required'}), 400
        
        if len(test_queries) > 20:  # Limit for performance
            return jsonify({'error': 'Maximum 20 test queries allowed'}), 400
        
        doc_id = data.get('doc_id')
        
        qwen_generator = QwenGenerator()
        
        benchmark_results = {
            'benchmark_id': str(uuid.uuid4()),
            'timestamp': datetime.utcnow().isoformat(),
            'model_version': qwen_generator.get_model_info()['version'],
            'test_count': len(test_queries),
            'results': []
        }
        
        for i, query in enumerate(test_queries):
            try:
                start_time = datetime.utcnow()
                
                # Generate summaries for benchmarking
                result = qwen_generator.generate_dual_summaries(query, "")
                
                end_time = datetime.utcnow()
                generation_time = (end_time - start_time).total_seconds() * 1000
                
                benchmark_results['results'].append({
                    'query_index': i,
                    'query': query,
                    'summary_a': result['summary_a'],
                    'summary_b': result['summary_b'],
                    'generation_time_ms': generation_time,
                    'tokens_a': result.get('tokens_a', 0),
                    'tokens_b': result.get('tokens_b', 0),
                    'status': 'success'
                })
                
            except Exception as e:
                benchmark_results['results'].append({
                    'query_index': i,
                    'query': query,
                    'error': str(e),
                    'status': 'failed'
                })
        
        # Calculate aggregate metrics
        successful_results = [r for r in benchmark_results['results'] if r['status'] == 'success']
        
        if successful_results:
            avg_generation_time = sum(r['generation_time_ms'] for r in successful_results) / len(successful_results)
            avg_tokens_a = sum(r['tokens_a'] for r in successful_results) / len(successful_results)
            avg_tokens_b = sum(r['tokens_b'] for r in successful_results) / len(successful_results)
            
            benchmark_results['aggregate_metrics'] = {
                'success_rate': len(successful_results) / len(test_queries),
                'average_generation_time_ms': avg_generation_time,
                'average_tokens_a': avg_tokens_a,
                'average_tokens_b': avg_tokens_b
            }
        
        return jsonify(benchmark_results), 200
        
    except Exception as e:
        current_app.logger.error(f"Model benchmark error: {str(e)}")
        return jsonify({'error': 'Benchmark failed'}), 500


def _calculate_model_performance_metrics(version):
    """Calculate performance metrics for a specific model version."""
    # Implementation would calculate various performance metrics
    return {
        'accuracy_score': 0.85,  # Placeholder
        'response_time_avg': 1.2,  # Placeholder
        'user_satisfaction': 0.78  # Placeholder
    }


def _calculate_confidence_metrics(preferences):
    """Calculate confidence-related metrics from preferences."""
    if not preferences:
        return {'average': 0, 'min': 0, 'max': 0, 'std': 0}
    
    confidences = [p.get('confidence', 1.0) for p in preferences]
    
    import statistics
    
    return {
        'average': statistics.mean(confidences),
        'min': min(confidences),
        'max': max(confidences),
        'std': statistics.stdev(confidences) if len(confidences) > 1 else 0
    }


def _calculate_performance_trends(preferences):
    """Calculate performance trends over time."""
    # Placeholder implementation
    return {
        'trend_direction': 'improving',
        'trend_strength': 0.15
    }


def _calculate_summary_length_analysis(episodes):
    """Calculate summary length statistics."""
    if not episodes:
        return {'avg_length_a': 0, 'avg_length_b': 0}
    
    lengths_a = [len(ep.get('summary_a', '')) for ep in episodes]
    lengths_b = [len(ep.get('summary_b', '')) for ep in episodes]
    
    return {
        'avg_length_a': sum(lengths_a) / len(lengths_a) if lengths_a else 0,
        'avg_length_b': sum(lengths_b) / len(lengths_b) if lengths_b else 0
    }


def _calculate_generation_time_analysis(episodes):
    """Calculate generation time statistics."""
    if not episodes:
        return {'avg_time_ms': 0}
    
    times = [ep.get('generation_metadata', {}).get('generation_time_ms', 0) for ep in episodes]
    times = [t for t in times if t > 0]  # Filter out zeros
    
    return {
        'avg_time_ms': sum(times) / len(times) if times else 0
    }


def _get_training_metrics_for_model(version):
    """Get training metrics for a specific model version."""
    # Placeholder implementation
    return {
        'training_loss': 0.25,
        'validation_loss': 0.28,
        'training_epochs': 1
    }


def _compare_with_previous_version(version, days):
    """Compare current version with previous version."""
    # Placeholder implementation
    return {
        'preference_improvement': 0.05,
        'speed_improvement': 0.12
    }