"""
User preferences API endpoints.

Handles collection and management of user preferences for A/B testing and DPO training.
"""

import uuid
from datetime import datetime
from flask import Blueprint, request, jsonify, current_app

from app.services.jsonl_logger import JsonlLogger
from app.utils.validators import validate_preference_data

preferences_bp = Blueprint('preferences', __name__)


@preferences_bp.route('/preference', methods=['POST'])
def submit_preference():
    """
    Submit user preference for A/B testing.
    
    Expects JSON:
    {
        "episode_id": "episode_uuid",
        "preference": "A" or "B",
        "reasoning": "Optional explanation",
        "confidence": 0.0-1.0 (optional)
    }
    
    Returns:
        JSON confirmation of preference recording
    """
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'JSON data required'}), 400
        
        # Validate required fields
        episode_id = data.get('episode_id')
        preference = data.get('preference')
        
        if not episode_id:
            return jsonify({'error': 'episode_id is required'}), 400
        
        if preference not in ['A', 'B']:
            return jsonify({'error': 'preference must be "A" or "B"'}), 400
        
        reasoning = data.get('reasoning', '')
        confidence = data.get('confidence', 1.0)
        
        # Validate confidence score
        if not (0.0 <= confidence <= 1.0):
            return jsonify({'error': 'confidence must be between 0.0 and 1.0'}), 400
        
        logger = JsonlLogger()
        
        # Retrieve the original A/B testing episode
        ab_episode = logger.get_episode_by_id(episode_id, 'phase3_ab_testing.jsonl')
        
        if not ab_episode:
            return jsonify({'error': 'Episode not found'}), 404
        
        # Create preference record
        preference_data = {
            'preference_id': str(uuid.uuid4()),
            'episode_id': episode_id,
            'timestamp': datetime.utcnow().isoformat(),
            'user_preference': preference,
            'reasoning': reasoning,
            'confidence': confidence,
            'query': ab_episode.get('query', ''),
            'context': ab_episode.get('context', ''),
            'chosen_summary': ab_episode.get(f'summary_{preference.lower()}', ''),
            'rejected_summary': ab_episode.get(f'summary_{"b" if preference == "A" else "a"}', ''),
            'model_version': ab_episode.get('model_version', 'unknown')
        }
        
        # Log preference
        logger.log_episode(preference_data, 'preferences.jsonl')
        
        # Update the original A/B testing episode with preference
        updated_episode = ab_episode.copy()
        updated_episode['user_preference'] = preference
        updated_episode['preference_timestamp'] = datetime.utcnow().isoformat()
        updated_episode['reasoning'] = reasoning
        updated_episode['confidence'] = confidence
        
        logger.update_episode(episode_id, updated_episode, 'phase3_ab_testing.jsonl')
        
        return jsonify({
            'message': 'Preference recorded successfully',
            'preference_id': preference_data['preference_id'],
            'episode_id': episode_id,
            'preference': preference,
            'confidence': confidence
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Submit preference error: {str(e)}")
        return jsonify({'error': 'Failed to record preference'}), 500


@preferences_bp.route('/preferences', methods=['GET'])
def get_preferences():
    """
    Get user preferences with filtering and pagination.
    
    Query parameters:
        - model_version: Filter by model version (optional)
        - preference: Filter by preference (A or B) (optional)
        - limit: Number of entries to return (default: 50)
        - offset: Offset for pagination (default: 0)
        - include_content: Include full summary content (default: false)
    
    Returns:
        JSON with preferences data
    """
    try:
        model_version = request.args.get('model_version')
        preference_filter = request.args.get('preference')
        limit = min(int(request.args.get('limit', 50)), 200)  # Max 200
        offset = int(request.args.get('offset', 0))
        include_content = request.args.get('include_content', 'false').lower() == 'true'
        
        # Validate preference filter
        if preference_filter and preference_filter not in ['A', 'B']:
            return jsonify({'error': 'preference filter must be "A" or "B"'}), 400
        
        logger = JsonlLogger()
        
        # Build filters
        filters = {}
        if model_version:
            filters['model_version'] = model_version
        if preference_filter:
            filters['user_preference'] = preference_filter
        
        # Get preferences
        preferences = logger.read_episodes('preferences.jsonl', filters, limit, offset)
        
        # Remove content if not requested (for performance)
        if not include_content:
            for pref in preferences:
                pref.pop('chosen_summary', None)
                pref.pop('rejected_summary', None)
                pref.pop('context', None)
        
        # Calculate statistics
        total_preferences = len(logger.read_episodes('preferences.jsonl', filters))
        
        preference_stats = {
            'A': len([p for p in preferences if p.get('user_preference') == 'A']),
            'B': len([p for p in preferences if p.get('user_preference') == 'B'])
        }
        
        return jsonify({
            'preferences': preferences,
            'count': len(preferences),
            'total_available': total_preferences,
            'statistics': {
                'preference_distribution': preference_stats,
                'preference_rate_a': preference_stats['A'] / max(1, sum(preference_stats.values())),
                'preference_rate_b': preference_stats['B'] / max(1, sum(preference_stats.values()))
            },
            'filters_applied': filters
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get preferences error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve preferences'}), 500


@preferences_bp.route('/preferences/stats', methods=['GET'])
def get_preference_statistics():
    """
    Get aggregated preference statistics.
    
    Query parameters:
        - model_version: Filter by model version (optional)
        - days: Number of days to include (default: 30)
    
    Returns:
        JSON with detailed preference statistics
    """
    try:
        model_version = request.args.get('model_version')
        days = int(request.args.get('days', 30))
        
        logger = JsonlLogger()
        
        # Build filters
        filters = {}
        if model_version:
            filters['model_version'] = model_version
        
        # Get preferences for the specified period
        from datetime import timedelta
        cutoff_date = (datetime.utcnow() - timedelta(days=days)).isoformat()
        
        all_preferences = logger.read_episodes('preferences.jsonl', filters)
        recent_preferences = [
            p for p in all_preferences 
            if p.get('timestamp', '') >= cutoff_date
        ]
        
        # Calculate detailed statistics
        total_count = len(recent_preferences)
        
        if total_count == 0:
            return jsonify({
                'period_days': days,
                'total_preferences': 0,
                'statistics': {}
            }), 200
        
        preference_counts = {'A': 0, 'B': 0}
        confidence_scores = []
        model_versions = {}
        
        for pref in recent_preferences:
            user_pref = pref.get('user_preference', '')
            if user_pref in preference_counts:
                preference_counts[user_pref] += 1
            
            confidence = pref.get('confidence')
            if confidence is not None:
                confidence_scores.append(confidence)
            
            model_ver = pref.get('model_version', 'unknown')
            model_versions[model_ver] = model_versions.get(model_ver, 0) + 1
        
        # Calculate metrics
        avg_confidence = sum(confidence_scores) / len(confidence_scores) if confidence_scores else 0
        
        statistics = {
            'total_preferences': total_count,
            'preference_distribution': preference_counts,
            'preference_rates': {
                'A': preference_counts['A'] / total_count,
                'B': preference_counts['B'] / total_count
            },
            'confidence_metrics': {
                'average': avg_confidence,
                'min': min(confidence_scores) if confidence_scores else 0,
                'max': max(confidence_scores) if confidence_scores else 0
            },
            'model_version_distribution': model_versions,
            'daily_preferences': _calculate_daily_preferences(recent_preferences, days)
        }
        
        return jsonify({
            'period_days': days,
            'statistics': statistics,
            'filters_applied': filters
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get preference statistics error: {str(e)}")
        return jsonify({'error': 'Failed to calculate statistics'}), 500


@preferences_bp.route('/preferences/export', methods=['GET'])
def export_preferences():
    """
    Export preferences data for analysis.
    
    Query parameters:
        - format: Export format (json, csv) (default: json)
        - model_version: Filter by model version (optional)
        - include_content: Include full summary content (default: true)
    
    Returns:
        Preferences data in requested format
    """
    try:
        export_format = request.args.get('format', 'json').lower()
        model_version = request.args.get('model_version')
        include_content = request.args.get('include_content', 'true').lower() == 'true'
        
        if export_format not in ['json', 'csv']:
            return jsonify({'error': 'format must be "json" or "csv"'}), 400
        
        logger = JsonlLogger()
        
        # Build filters
        filters = {}
        if model_version:
            filters['model_version'] = model_version
        
        # Get all preferences
        preferences = logger.read_episodes('preferences.jsonl', filters)
        
        # Remove content if not requested
        if not include_content:
            for pref in preferences:
                pref.pop('chosen_summary', None)
                pref.pop('rejected_summary', None)
                pref.pop('context', None)
        
        if export_format == 'json':
            return jsonify({
                'export_timestamp': datetime.utcnow().isoformat(),
                'total_records': len(preferences),
                'filters_applied': filters,
                'data': preferences
            }), 200
        
        else:  # CSV format
            import pandas as pd
            import io
            
            df = pd.DataFrame(preferences)
            csv_buffer = io.StringIO()
            df.to_csv(csv_buffer, index=False)
            
            response = current_app.response_class(
                csv_buffer.getvalue(),
                mimetype='text/csv',
                headers={'Content-Disposition': 'attachment; filename=preferences_export.csv'}
            )
            
            return response
        
    except Exception as e:
        current_app.logger.error(f"Export preferences error: {str(e)}")
        return jsonify({'error': 'Failed to export preferences'}), 500


def _calculate_daily_preferences(preferences, days):
    """Calculate daily preference counts for the given period."""
    from collections import defaultdict
    
    daily_counts = defaultdict(lambda: {'A': 0, 'B': 0})
    
    for pref in preferences:
        timestamp = pref.get('timestamp', '')
        if timestamp:
            date = timestamp.split('T')[0]  # Extract date part
            preference = pref.get('user_preference', '')
            if preference in ['A', 'B']:
                daily_counts[date][preference] += 1
    
    # Convert to list format
    return [
        {
            'date': date,
            'preference_a': counts['A'],
            'preference_b': counts['B'],
            'total': counts['A'] + counts['B']
        }
        for date, counts in sorted(daily_counts.items())
    ]