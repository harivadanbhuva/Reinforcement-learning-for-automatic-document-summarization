"""
API Routes package for the RL Document Summarization system.

This package contains all the API endpoints organized by functionality:
- documents: Document upload and management
- summarization: Summary generation (RAG and Qwen)
- preferences: User preference collection and management
- training: DPO training triggers and status
- models: Model management and information
"""