"""
Model training API endpoints.

Handles DPO training triggers, status monitoring, and training job management.
"""

import uuid
from datetime import datetime
from flask import Blueprint, request, jsonify, current_app

from app.services.jsonl_logger import JsonlLogger
from tasks.training_tasks import train_dpo_model, check_training_requirements

training_bp = Blueprint('training', __name__)


@training_bp.route('/train/dpo', methods=['POST'])
def trigger_dpo_training():
    """
    Trigger DPO fine-tuning with collected preferences.
    
    Expects JSON (optional):
    {
        "force": false,
        "batch_size": 64,
        "learning_rate": 5e-6,
        "beta": 0.1,
        "max_epochs": 1
    }
    
    Returns:
        JSON with training job information
    """
    try:
        # Check if DPO training is enabled
        if not current_app.config['ENABLE_DPO_TRAINING']:
            return jsonify({'error': 'DPO training is disabled'}), 400
        
        data = request.get_json() or {}
        force = data.get('force', False)
        
        logger = JsonlLogger()
        
        # Check training requirements
        requirements_check = check_training_requirements.delay()
        requirements = requirements_check.get(timeout=10)
        
        if not requirements['can_train'] and not force:
            return jsonify({
                'error': 'Training requirements not met',
                'requirements': requirements,
                'suggestion': 'Collect more preferences or use force=true to override'
            }), 400
        
        # Get training configuration
        config = {
            'batch_size': data.get('batch_size', current_app.config['BATCH_SIZE']),
            'learning_rate': data.get('learning_rate', current_app.config['LEARNING_RATE']),
            'beta': data.get('beta', current_app.config['DPO_BETA']),
            'max_epochs': data.get('max_epochs', 1),
            'gradient_accumulation_steps': current_app.config['GRADIENT_ACCUMULATION_STEPS']
        }
        
        # Validate configuration
        if config['batch_size'] < 1 or config['batch_size'] > 256:
            return jsonify({'error': 'batch_size must be between 1 and 256'}), 400
        
        if config['learning_rate'] <= 0 or config['learning_rate'] > 1e-3:
            return jsonify({'error': 'learning_rate must be between 0 and 1e-3'}), 400
        
        if config['beta'] <= 0 or config['beta'] > 10:
            return jsonify({'error': 'beta must be between 0 and 10'}), 400
        
        # Start training task
        training_id = str(uuid.uuid4())
        task = train_dpo_model.delay(training_id, config)
        
        # Log training initiation
        training_episode = {
            'training_id': training_id,
            'task_id': task.id,
            'episode_id': f'train_{training_id}',
            'phase': 'dpo_training_initiated',
            'timestamp': datetime.utcnow().isoformat(),
            'config': config,
            'preferences_count': requirements['new_preferences'],
            'model_version_before': requirements['current_model_version'],
            'status': 'started',
            'forced': force
        }
        
        logger.log_episode(training_episode, 'phase4_training.jsonl')
        
        return jsonify({
            'training_id': training_id,
            'task_id': task.id,
            'status': 'started',
            'message': 'DPO training started successfully',
            'config': config,
            'estimated_duration_minutes': _estimate_training_duration(config),
            'requirements_check': requirements
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"DPO training trigger error: {str(e)}")
        return jsonify({'error': 'Failed to start DPO training'}), 500


@training_bp.route('/train/status/<training_id>', methods=['GET'])
def get_training_status(training_id):
    """
    Get the status of a DPO training job.
    
    Args:
        training_id: Training job identifier
    
    Returns:
        JSON with training status and progress information
    """
    try:
        logger = JsonlLogger()
        
        # Find training episode
        training_episodes = logger.read_episodes('phase4_training.jsonl', {'training_id': training_id})
        
        if not training_episodes:
            return jsonify({'error': 'Training job not found'}), 404
        
        # Get the latest episode for this training job
        latest_episode = max(training_episodes, key=lambda x: x.get('timestamp', ''))
        
        # Get task status from Celery if available
        task_id = latest_episode.get('task_id')
        task_status = None
        task_result = None
        
        if task_id:
            try:
                from celery.result import AsyncResult
                from tasks.training_tasks import celery_app
                
                task = AsyncResult(task_id, app=celery_app)
                task_status = task.status
                
                if task.ready():
                    if task.successful():
                        task_result = task.result
                    else:
                        task_result = {'error': str(task.info)}
                else:
                    # Get intermediate results if available
                    task_result = task.info if task.info else {}
                    
            except Exception as e:
                current_app.logger.warning(f"Could not get task status: {str(e)}")
        
        response_data = {
            'training_id': training_id,
            'status': latest_episode.get('status', 'unknown'),
            'phase': latest_episode.get('phase', 'unknown'),
            'started_at': latest_episode.get('timestamp'),
            'config': latest_episode.get('config', {}),
            'preferences_count': latest_episode.get('preferences_count', 0),
            'model_version_before': latest_episode.get('model_version_before'),
            'model_version_after': latest_episode.get('model_version_after'),
            'training_metrics': latest_episode.get('training_metrics', {}),
            'task_status': task_status,
            'progress': task_result if isinstance(task_result, dict) else {}
        }
        
        # Add completion information if training is done
        if latest_episode.get('status') in ['completed', 'failed']:
            response_data['completed_at'] = latest_episode.get('completion_timestamp')
            response_data['duration_seconds'] = latest_episode.get('training_duration_seconds')
            response_data['final_loss'] = latest_episode.get('final_loss')
        
        return jsonify(response_data), 200
        
    except Exception as e:
        current_app.logger.error(f"Get training status error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve training status'}), 500


@training_bp.route('/train/history', methods=['GET'])
def get_training_history():
    """
    Get training history with filtering and pagination.
    
    Query parameters:
        - status: Filter by status (started, completed, failed) (optional)
        - limit: Number of entries to return (default: 20)
        - offset: Offset for pagination (default: 0)
    
    Returns:
        JSON with training history
    """
    try:
        status_filter = request.args.get('status')
        limit = min(int(request.args.get('limit', 20)), 100)  # Max 100
        offset = int(request.args.get('offset', 0))
        
        logger = JsonlLogger()
        
        # Build filters
        filters = {}
        if status_filter:
            if status_filter not in ['started', 'completed', 'failed', 'running']:
                return jsonify({'error': 'Invalid status filter'}), 400
            filters['status'] = status_filter
        
        # Get training episodes
        training_episodes = logger.read_episodes('phase4_training.jsonl', filters, limit, offset)
        
        # Group episodes by training_id and get the latest status for each
        training_jobs = {}
        for episode in training_episodes:
            training_id = episode.get('training_id')
            if training_id:
                if training_id not in training_jobs or \
                   episode.get('timestamp', '') > training_jobs[training_id].get('timestamp', ''):
                    training_jobs[training_id] = episode
        
        # Convert to list and sort by timestamp
        history = list(training_jobs.values())
        history.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
        
        # Calculate statistics
        total_jobs = len(training_jobs)
        status_counts = {}
        for job in history:
            status = job.get('status', 'unknown')
            status_counts[status] = status_counts.get(status, 0) + 1
        
        return jsonify({
            'training_history': history,
            'count': len(history),
            'total_jobs': total_jobs,
            'statistics': {
                'status_distribution': status_counts,
                'success_rate': status_counts.get('completed', 0) / max(1, total_jobs),
                'failure_rate': status_counts.get('failed', 0) / max(1, total_jobs)
            },
            'filters_applied': filters
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Get training history error: {str(e)}")
        return jsonify({'error': 'Failed to retrieve training history'}), 500


@training_bp.route('/train/requirements', methods=['GET'])
def check_training_requirements_endpoint():
    """
    Check if training requirements are met.
    
    Returns:
        JSON with training requirements status
    """
    try:
        # Run requirements check
        requirements_check = check_training_requirements.delay()
        requirements = requirements_check.get(timeout=10)
        
        return jsonify(requirements), 200
        
    except Exception as e:
        current_app.logger.error(f"Check training requirements error: {str(e)}")
        return jsonify({'error': 'Failed to check training requirements'}), 500


@training_bp.route('/train/cancel/<training_id>', methods=['POST'])
def cancel_training(training_id):
    """
    Cancel a running training job.
    
    Args:
        training_id: Training job identifier
    
    Returns:
        JSON confirmation of cancellation
    """
    try:
        logger = JsonlLogger()
        
        # Find training episode
        training_episodes = logger.read_episodes('phase4_training.jsonl', {'training_id': training_id})
        
        if not training_episodes:
            return jsonify({'error': 'Training job not found'}), 404
        
        # Get the latest episode
        latest_episode = max(training_episodes, key=lambda x: x.get('timestamp', ''))
        
        if latest_episode.get('status') not in ['started', 'running']:
            return jsonify({'error': 'Training job cannot be cancelled (not running)'}), 400
        
        # Cancel Celery task if available
        task_id = latest_episode.get('task_id')
        if task_id:
            try:
                from celery.result import AsyncResult
                from tasks.training_tasks import celery_app
                
                task = AsyncResult(task_id, app=celery_app)
                task.revoke(terminate=True)
                
            except Exception as e:
                current_app.logger.warning(f"Could not cancel task: {str(e)}")
        
        # Log cancellation
        cancellation_episode = latest_episode.copy()
        cancellation_episode['episode_id'] = f'train_cancel_{training_id}'
        cancellation_episode['phase'] = 'dpo_training_cancelled'
        cancellation_episode['timestamp'] = datetime.utcnow().isoformat()
        cancellation_episode['status'] = 'cancelled'
        cancellation_episode['completion_timestamp'] = datetime.utcnow().isoformat()
        
        logger.log_episode(cancellation_episode, 'phase4_training.jsonl')
        
        return jsonify({
            'message': 'Training job cancelled successfully',
            'training_id': training_id,
            'status': 'cancelled'
        }), 200
        
    except Exception as e:
        current_app.logger.error(f"Cancel training error: {str(e)}")
        return jsonify({'error': 'Failed to cancel training'}), 500


def _estimate_training_duration(config):
    """Estimate training duration in minutes based on configuration."""
    base_minutes = 30  # Base time for small training
    
    # Adjust based on batch size and epochs
    batch_factor = config['batch_size'] / 64  # Normalize to default batch size
    epoch_factor = config['max_epochs']
    
    estimated_minutes = base_minutes * batch_factor * epoch_factor
    
    return max(5, int(estimated_minutes))  # Minimum 5 minutes