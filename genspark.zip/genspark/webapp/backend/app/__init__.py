"""
Flask Application Factory

This module creates and configures the Flask application with all necessary
components for the RL Document Summarization system.
"""

from flask import Flask
from flask_cors import CORS
from flask_caching import Cache
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from app.config import Config


def create_app(config_class=Config):
    """Create and configure Flask application."""
    app = Flask(__name__)
    app.config.from_object(config_class)
    
    # Initialize extensions
    CORS(app)
    cache = Cache(app)
    limiter = Limiter(
        app,
        key_func=get_remote_address,
        default_limits=["200 per day", "50 per hour"]
    )
    
    # Register blueprints
    from app.routes.documents import documents_bp
    from app.routes.summarization import summarization_bp
    from app.routes.preferences import preferences_bp
    from app.routes.training import training_bp
    from app.routes.models import models_bp
    
    app.register_blueprint(documents_bp, url_prefix='/api')
    app.register_blueprint(summarization_bp, url_prefix='/api')
    app.register_blueprint(preferences_bp, url_prefix='/api')
    app.register_blueprint(training_bp, url_prefix='/api')
    app.register_blueprint(models_bp, url_prefix='/api')
    
    # Health check endpoint
    @app.route('/health')
    def health_check():
        return {'status': 'healthy', 'service': 'rl-document-summarization-api'}
    
    return app