"""
Data models and schemas for the RL Document Summarization system.

This package contains Pydantic models and data schemas for:
- Document metadata and processing results
- Summary generation requests and responses
- User preferences and feedback
- Training episodes and configurations
"""