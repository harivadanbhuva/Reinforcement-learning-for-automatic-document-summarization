"""
Input validation utilities.

Provides validation functions for API inputs, file uploads, and user preferences.
"""

import re
from typing import Any, Dict, List, Optional, Tuple
from pathlib import Path


def validate_file_type(filename: str, allowed_extensions: List[str] = None) -> Tuple[bool, str]:
    """
    Validate file type based on extension.
    
    Args:
        filename: Name of the file
        allowed_extensions: List of allowed extensions (default: ['pdf', 'txt', 'docx'])
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not filename:
        return False, "Filename cannot be empty"
    
    if not allowed_extensions:
        allowed_extensions = ['pdf', 'txt', 'docx', 'doc']
    
    # Extract extension
    if '.' not in filename:
        return False, "File must have an extension"
    
    extension = filename.rsplit('.', 1)[1].lower()
    
    if extension not in allowed_extensions:
        return False, f"File type '.{extension}' not allowed. Supported types: {', '.join(allowed_extensions)}"
    
    return True, ""


def validate_file_size(file_size: int, max_size_mb: int = 50) -> Tuple[bool, str]:
    """
    Validate file size.
    
    Args:
        file_size: Size of file in bytes
        max_size_mb: Maximum allowed size in MB
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    max_size_bytes = max_size_mb * 1024 * 1024
    
    if file_size > max_size_bytes:
        return False, f"File size ({file_size / (1024*1024):.1f}MB) exceeds maximum allowed size ({max_size_mb}MB)"
    
    if file_size <= 0:
        return False, "File appears to be empty"
    
    return True, ""


def validate_query(query: str, min_length: int = 3, max_length: int = 500) -> Tuple[bool, str]:
    """
    Validate user query/question.
    
    Args:
        query: User query string
        min_length: Minimum query length
        max_length: Maximum query length
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not query or not isinstance(query, str):
        return False, "Query must be a non-empty string"
    
    query = query.strip()
    
    if len(query) < min_length:
        return False, f"Query must be at least {min_length} characters long"
    
    if len(query) > max_length:
        return False, f"Query must be no more than {max_length} characters long"
    
    # Check for potentially malicious content
    suspicious_patterns = [
        r'<script',
        r'javascript:',
        r'data:text/html',
        r'<iframe',
        r'<object',
        r'<embed'
    ]
    
    for pattern in suspicious_patterns:
        if re.search(pattern, query, re.IGNORECASE):
            return False, "Query contains potentially unsafe content"
    
    return True, ""


def validate_preference_data(preference_data: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Validate user preference submission data.
    
    Args:
        preference_data: Dictionary containing preference data
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    required_fields = ['episode_id', 'preference']
    
    for field in required_fields:
        if field not in preference_data:
            return False, f"Missing required field: {field}"
    
    # Validate episode ID
    episode_id = preference_data['episode_id']
    if not isinstance(episode_id, str) or not episode_id.strip():
        return False, "episode_id must be a non-empty string"
    
    # Validate preference choice
    preference = preference_data['preference']
    if preference not in ['A', 'B']:
        return False, "preference must be either 'A' or 'B'"
    
    # Validate optional fields
    if 'confidence' in preference_data:
        confidence = preference_data['confidence']
        if not isinstance(confidence, (int, float)) or not (0.0 <= confidence <= 1.0):
            return False, "confidence must be a number between 0.0 and 1.0"
    
    if 'reasoning' in preference_data:
        reasoning = preference_data['reasoning']
        if reasoning and (not isinstance(reasoning, str) or len(reasoning) > 1000):
            return False, "reasoning must be a string with maximum 1000 characters"
    
    return True, ""


def validate_training_config(config: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Validate DPO training configuration.
    
    Args:
        config: Training configuration dictionary
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    # Validate batch size
    if 'batch_size' in config:
        batch_size = config['batch_size']
        if not isinstance(batch_size, int) or batch_size < 1 or batch_size > 256:
            return False, "batch_size must be an integer between 1 and 256"
    
    # Validate learning rate
    if 'learning_rate' in config:
        learning_rate = config['learning_rate']
        if not isinstance(learning_rate, (int, float)) or learning_rate <= 0 or learning_rate > 1e-2:
            return False, "learning_rate must be a positive number not exceeding 0.01"
    
    # Validate beta parameter
    if 'beta' in config:
        beta = config['beta']
        if not isinstance(beta, (int, float)) or beta <= 0 or beta > 10:
            return False, "beta must be a positive number not exceeding 10"
    
    # Validate max epochs
    if 'max_epochs' in config:
        max_epochs = config['max_epochs']
        if not isinstance(max_epochs, int) or max_epochs < 1 or max_epochs > 10:
            return False, "max_epochs must be an integer between 1 and 10"
    
    return True, ""


def validate_document_id(doc_id: str) -> Tuple[bool, str]:
    """
    Validate document identifier.
    
    Args:
        doc_id: Document ID string
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not doc_id or not isinstance(doc_id, str):
        return False, "Document ID must be a non-empty string"
    
    doc_id = doc_id.strip()
    
    # Check length
    if len(doc_id) < 8 or len(doc_id) > 100:
        return False, "Document ID must be between 8 and 100 characters"
    
    # Check format (should be alphanumeric with hyphens and underscores)
    if not re.match(r'^[a-zA-Z0-9\-_]+$', doc_id):
        return False, "Document ID can only contain letters, numbers, hyphens, and underscores"
    
    return True, ""


def validate_search_params(params: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Validate search parameters.
    
    Args:
        params: Search parameters dictionary
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    # Validate top_k
    if 'top_k' in params:
        top_k = params['top_k']
        if not isinstance(top_k, int) or top_k < 1 or top_k > 50:
            return False, "top_k must be an integer between 1 and 50"
    
    # Validate min_score
    if 'min_score' in params:
        min_score = params['min_score']
        if not isinstance(min_score, (int, float)) or min_score < 0 or min_score > 1:
            return False, "min_score must be a number between 0 and 1"
    
    # Validate document filter
    if 'doc_id' in params:
        doc_id = params['doc_id']
        if doc_id is not None:
            is_valid, error = validate_document_id(doc_id)
            if not is_valid:
                return False, f"Invalid doc_id: {error}"
    
    return True, ""


def sanitize_filename(filename: str) -> str:
    """
    Sanitize filename for safe storage.
    
    Args:
        filename: Original filename
    
    Returns:
        Sanitized filename
    """
    if not filename:
        return "unnamed_file"
    
    # Remove path components
    filename = Path(filename).name
    
    # Replace problematic characters
    sanitized = re.sub(r'[<>:"/\\|?*]', '_', filename)
    
    # Remove control characters
    sanitized = ''.join(char for char in sanitized if ord(char) >= 32)
    
    # Limit length
    if len(sanitized) > 255:
        name, ext = sanitized.rsplit('.', 1) if '.' in sanitized else (sanitized, '')
        max_name_length = 250 - len(ext) - 1 if ext else 250
        sanitized = name[:max_name_length] + ('.' + ext if ext else '')
    
    # Ensure it's not empty
    if not sanitized or sanitized == '.':
        sanitized = "unnamed_file"
    
    return sanitized


def validate_pagination(offset: int = 0, limit: int = 20, max_limit: int = 100) -> Tuple[bool, str, int, int]:
    """
    Validate and normalize pagination parameters.
    
    Args:
        offset: Offset value
        limit: Limit value
        max_limit: Maximum allowed limit
    
    Returns:
        Tuple of (is_valid, error_message, normalized_offset, normalized_limit)
    """
    # Validate offset
    if not isinstance(offset, int) or offset < 0:
        return False, "offset must be a non-negative integer", 0, limit
    
    # Validate limit
    if not isinstance(limit, int) or limit < 1:
        return False, "limit must be a positive integer", offset, 20
    
    # Apply max limit
    if limit > max_limit:
        limit = max_limit
    
    return True, "", offset, limit


def validate_model_version(version: str) -> Tuple[bool, str]:
    """
    Validate model version string.
    
    Args:
        version: Model version identifier
    
    Returns:
        Tuple of (is_valid, error_message)
    """
    if not version or not isinstance(version, str):
        return False, "Model version must be a non-empty string"
    
    version = version.strip()
    
    # Check length
    if len(version) < 3 or len(version) > 50:
        return False, "Model version must be between 3 and 50 characters"
    
    # Check format (alphanumeric with dots, hyphens, and underscores)
    if not re.match(r'^[a-zA-Z0-9\.\-_]+$', version):
        return False, "Model version can only contain letters, numbers, dots, hyphens, and underscores"
    
    # Shouldn't start or end with special characters
    if version[0] in '.-_' or version[-1] in '.-_':
        return False, "Model version cannot start or end with special characters"
    
    return True, ""