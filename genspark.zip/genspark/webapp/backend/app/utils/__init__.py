"""
Utility functions and helpers for the RL Document Summarization system.

This package contains various utility functions for:
- Input validation
- File operations
- Text processing
- Caching utilities
"""