"""
RAG (Retrieval-Augmented Generation) pipeline service.

Implements the core RAG functionality using Groq API for generation,
FAISS for retrieval, and agents for external knowledge augmentation.
"""

import time
from typing import Dict, List, Any, Optional
from datetime import datetime

import requests
from flask import current_app

from app.services.faiss_manager import FaissManager
from app.services.agent_service import AgentService


class RagPipeline:
    """RAG pipeline for document summarization."""
    
    def __init__(self):
        """Initialize the RAG pipeline."""
        self.groq_api_key = current_app.config['GROQ_API_KEY']
        self.groq_model = "gpt-oss-120b"  # Groq's model
        self.faiss_manager = FaissManager()
        
        # Configuration
        self.max_context_length = current_app.config['MAX_CONTEXT_LENGTH']
        self.max_summary_length = current_app.config['MAX_SUMMARY_LENGTH']
        
        # Mock mode for testing
        self.mock_mode = current_app.config.get('MOCK_GROQ_API', False)
    
    def _call_groq_api(self, prompt: str, max_tokens: int = None) -> Dict[str, Any]:
        """
        Call Groq API for text generation.
        
        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            
        Returns:
            API response with generated text and metadata
        """
        if self.mock_mode:
            # Return mock response for testing
            return {
                'text': f"Mock summary for prompt: {prompt[:50]}...",
                'tokens_used': len(prompt.split()) + 20,
                'model': self.groq_model,
                'generation_time_ms': 500
            }
        
        if not self.groq_api_key:
            raise ValueError("Groq API key not configured")
        
        url = "https://api.groq.com/openai/v1/chat/completions"
        
        headers = {
            "Authorization": f"Bearer {self.groq_api_key}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": self.groq_model,
            "messages": [
                {
                    "role": "system",
                    "content": "You are an expert document summarizer. Provide clear, concise, and accurate summaries."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            "max_tokens": max_tokens or self.max_summary_length,
            "temperature": 0.1,  # Low temperature for consistent summaries
            "top_p": 0.9
        }
        
        start_time = time.time()
        
        try:
            response = requests.post(url, json=payload, headers=headers, timeout=60)
            response.raise_for_status()
            
            result = response.json()
            generation_time_ms = (time.time() - start_time) * 1000
            
            if 'choices' not in result or not result['choices']:
                raise ValueError("No choices in Groq API response")
            
            generated_text = result['choices'][0]['message']['content'].strip()
            
            return {
                'text': generated_text,
                'tokens_used': result.get('usage', {}).get('total_tokens', 0),
                'model': self.groq_model,
                'generation_time_ms': generation_time_ms
            }
            
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Groq API request failed: {str(e)}")
        except (KeyError, ValueError) as e:
            raise RuntimeError(f"Invalid Groq API response: {str(e)}")
    
    def retrieve_context(self, query: str, doc_id: str = None, top_k: int = 5) -> Dict[str, Any]:
        """
        Retrieve relevant context for a query using FAISS.
        
        Args:
            query: Search query
            doc_id: Optional document filter
            top_k: Number of chunks to retrieve
            
        Returns:
            Retrieved context with metadata
        """
        try:
            # Search FAISS for relevant chunks
            results = self.faiss_manager.search(
                query=query,
                top_k=top_k,
                doc_id=doc_id,
                min_score=0.1
            )
            
            if not results:
                return {
                    'context': "",
                    'chunks': [],
                    'total_chunks': 0,
                    'avg_score': 0.0,
                    'sources': []
                }
            
            # Combine chunk texts with score weighting
            context_parts = []
            total_score = 0
            sources = set()
            
            for result in results:
                chunk_text = result['text']
                score = result['score']
                doc_id = result['doc_id']
                
                # Add chunk with score indicator
                context_parts.append(f"[Score: {score:.2f}] {chunk_text}")
                total_score += score
                sources.add(doc_id)
            
            # Combine all context
            full_context = "\n\n---\n\n".join(context_parts)
            
            # Truncate if too long
            if len(full_context) > self.max_context_length:
                full_context = full_context[:self.max_context_length] + "...[truncated]"
            
            avg_score = total_score / len(results)
            
            return {
                'context': full_context,
                'chunks': results,
                'total_chunks': len(results),
                'avg_score': avg_score,
                'sources': list(sources),
                'retrieval_query': query
            }
            
        except Exception as e:
            current_app.logger.error(f"Context retrieval failed: {str(e)}")
            return {
                'context': "",
                'chunks': [],
                'total_chunks': 0,
                'avg_score': 0.0,
                'sources': [],
                'error': str(e)
            }
    
    def generate_extractive_summary(self, query: str, doc_id: str = None) -> Dict[str, Any]:
        """
        Generate extractive summary by selecting key sentences from documents.
        
        Args:
            query: User query/question
            doc_id: Optional document filter
            
        Returns:
            Extractive summary with metadata
        """
        try:
            # Retrieve relevant context
            context_result = self.retrieve_context(query, doc_id, top_k=8)
            
            if not context_result['context']:
                return {
                    'summary': "No relevant content found for this query.",
                    'context': "",
                    'sources': {},
                    'generation_time_ms': 0,
                    'model': 'none'
                }
            
            # Create extractive summarization prompt
            extractive_prompt = f"""
You are an expert at extractive summarization. Your task is to create a summary by selecting and organizing the most important sentences from the provided context.

Instructions:
1. Extract key sentences that directly answer or relate to the user's query
2. Preserve the original wording from the source text
3. Organize the extracted sentences in a logical flow
4. Ensure the summary is coherent and informative
5. Do not add information not present in the context

User Query: {query}

Context:
{context_result['context']}

Create an extractive summary by selecting and organizing key sentences from the context above:
"""
            
            # Generate summary using Groq
            generation_result = self._call_groq_api(
                extractive_prompt,
                max_tokens=min(self.max_summary_length, 300)
            )
            
            return {
                'summary': generation_result['text'],
                'context': context_result['context'],
                'sources': {
                    'embedded_docs': context_result['sources'],
                    'chunks_used': context_result['total_chunks'],
                    'avg_relevance_score': context_result['avg_score']
                },
                'generation_time_ms': generation_result['generation_time_ms'],
                'tokens_used': generation_result['tokens_used'],
                'model': generation_result['model'],
                'mode': 'extractive'
            }
            
        except Exception as e:
            current_app.logger.error(f"Extractive summary generation failed: {str(e)}")
            return {
                'summary': f"Failed to generate extractive summary: {str(e)}",
                'context': "",
                'sources': {},
                'generation_time_ms': 0,
                'model': 'error',
                'error': str(e)
            }
    
    def generate_abstractive_summary(self, query: str, doc_id: str = None, 
                                   agent_service: AgentService = None) -> Dict[str, Any]:
        """
        Generate abstractive summary using external knowledge from agents.
        
        Args:
            query: User query/question
            doc_id: Optional document filter
            agent_service: Service for external knowledge retrieval
            
        Returns:
            Abstractive summary with metadata
        """
        try:
            # Retrieve context from embedded documents
            context_result = self.retrieve_context(query, doc_id, top_k=5)
            
            # Get external knowledge if agents are enabled
            external_sources = {}
            external_context = ""
            
            if agent_service and current_app.config['ENABLE_AGENTS']:
                try:
                    # Get external knowledge
                    external_knowledge = agent_service.search_all_sources(query)
                    
                    if external_knowledge.get('duckduckgo_results'):
                        ddg_context = "\n".join([
                            f"- {result.get('title', '')}: {result.get('snippet', '')}"
                            for result in external_knowledge['duckduckgo_results'][:3]
                        ])
                        external_context += f"\nWeb Search Results:\n{ddg_context}"
                        external_sources['duckduckgo'] = external_knowledge['duckduckgo_results']
                    
                    if external_knowledge.get('wikipedia_results'):
                        wiki_context = "\n".join([
                            f"- {result.get('title', '')}: {result.get('summary', '')}"
                            for result in external_knowledge['wikipedia_results'][:2]
                        ])
                        external_context += f"\n\nWikipedia Information:\n{wiki_context}"
                        external_sources['wikipedia'] = external_knowledge['wikipedia_results']
                        
                except Exception as e:
                    current_app.logger.warning(f"External knowledge retrieval failed: {e}")
            
            # Create abstractive summarization prompt
            abstractive_prompt = f"""
You are an expert at abstractive summarization. Your task is to create a comprehensive summary by synthesizing information from multiple sources and rephrasing it in your own words.

Instructions:
1. Synthesize information from embedded documents and external sources
2. Create new sentences that capture the essence of the information
3. Provide insights and connections between different pieces of information
4. Ensure the summary is coherent, informative, and well-structured
5. You may rephrase and restructure information to improve clarity

User Query: {query}

Embedded Document Context:
{context_result.get('context', 'No embedded document context available')}

External Knowledge Context:
{external_context if external_context else 'No external context available'}

Create a comprehensive abstractive summary that synthesizes information from all sources:
"""
            
            # Generate summary using Groq
            generation_result = self._call_groq_api(
                abstractive_prompt,
                max_tokens=min(self.max_summary_length, 400)
            )
            
            # Combine sources
            all_sources = {
                'embedded_docs': context_result['sources'],
                'chunks_used': context_result['total_chunks'],
                'avg_relevance_score': context_result.get('avg_score', 0.0)
            }
            all_sources.update(external_sources)
            
            return {
                'summary': generation_result['text'],
                'context': context_result.get('context', ''),
                'external_context': external_context,
                'sources': all_sources,
                'generation_time_ms': generation_result['generation_time_ms'],
                'tokens_used': generation_result['tokens_used'],
                'model': generation_result['model'],
                'mode': 'abstractive'
            }
            
        except Exception as e:
            current_app.logger.error(f"Abstractive summary generation failed: {str(e)}")
            return {
                'summary': f"Failed to generate abstractive summary: {str(e)}",
                'context': "",
                'sources': {},
                'generation_time_ms': 0,
                'model': 'error',
                'error': str(e)
            }
    
    def compare_summaries(self, query: str, summary_a: str, summary_b: str) -> Dict[str, Any]:
        """
        Compare two summaries and provide analysis.
        
        Args:
            query: Original query
            summary_a: First summary
            summary_b: Second summary
            
        Returns:
            Comparison analysis
        """
        comparison_prompt = f"""
Compare these two summaries for the query: "{query}"

Summary A (Extractive):
{summary_a}

Summary B (Abstractive):
{summary_b}

Provide a brief analysis comparing:
1. Accuracy and factual correctness
2. Completeness of information
3. Clarity and readability
4. Relevance to the query

Analysis:
"""
        
        try:
            result = self._call_groq_api(comparison_prompt, max_tokens=200)
            return {
                'comparison': result['text'],
                'generation_time_ms': result['generation_time_ms']
            }
        except Exception as e:
            return {
                'comparison': f"Comparison failed: {str(e)}",
                'generation_time_ms': 0
            }
    
    def validate_groq_connection(self) -> Dict[str, Any]:
        """
        Validate connection to Groq API.
        
        Returns:
            Connection status and capabilities
        """
        if self.mock_mode:
            return {
                'connected': True,
                'mock_mode': True,
                'model': self.groq_model,
                'test_generation': True
            }
        
        status = {
            'connected': False,
            'model': self.groq_model,
            'error': None,
            'test_generation': False
        }
        
        try:
            # Test with a simple prompt
            test_result = self._call_groq_api("Generate a one-sentence test response.", max_tokens=50)
            
            status['connected'] = True
            status['test_generation'] = True
            status['test_response'] = test_result['text']
            status['test_tokens'] = test_result['tokens_used']
            
        except Exception as e:
            status['error'] = str(e)
        
        return status