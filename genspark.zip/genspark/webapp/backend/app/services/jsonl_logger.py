"""
JSONL logging service for episode and conversation tracking.

Handles logging of all system interactions, preferences, and training episodes
in JSONL format for analysis and model improvement.
"""

import json
import uuid
import fcntl
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

from flask import current_app


class JsonlLogger:
    """Service for logging episodes and events in JSONL format."""
    
    def __init__(self):
        """Initialize the JSONL logger."""
        self.data_path = current_app.config['JSONL_DATA_PATH']
        self.preferences_path = current_app.config['PREFERENCES_PATH']
        
        # Ensure directories exist
        self.data_path.mkdir(parents=True, exist_ok=True)
        self.preferences_path.mkdir(parents=True, exist_ok=True)
        
        # File mappings
        self.episode_files = {
            'phase2_rag.jsonl': self.data_path / 'phase2_rag.jsonl',
            'phase3_ab_testing.jsonl': self.data_path / 'phase3_ab_testing.jsonl',
            'phase4_training.jsonl': self.data_path / 'phase4_training.jsonl',
            'preferences.jsonl': self.preferences_path / 'preferences.jsonl'
        }
    
    def _write_jsonl_line(self, file_path: Path, data: Dict[str, Any]) -> bool:
        """
        Write a single JSONL line to file with file locking.
        
        Args:
            file_path: Path to the JSONL file
            data: Data dictionary to write
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Ensure the data has required fields
            if 'timestamp' not in data:
                data['timestamp'] = datetime.utcnow().isoformat()
            
            if 'episode_id' not in data:
                data['episode_id'] = str(uuid.uuid4())
            
            # Convert to JSON string
            json_line = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
            
            # Write with file locking to prevent corruption
            with open(file_path, 'a', encoding='utf-8') as f:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                try:
                    f.write(json_line + '\n')
                    f.flush()
                finally:
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            
            return True
            
        except Exception as e:
            current_app.logger.error(f"Failed to write JSONL line to {file_path}: {e}")
            return False
    
    def _read_jsonl_file(self, file_path: Path, 
                        filters: Dict[str, Any] = None, 
                        limit: int = None, 
                        offset: int = 0) -> List[Dict[str, Any]]:
        """
        Read JSONL file with optional filtering and pagination.
        
        Args:
            file_path: Path to the JSONL file
            filters: Dictionary of field filters
            limit: Maximum number of records to return
            offset: Number of records to skip
            
        Returns:
            List of matching records
        """
        if not file_path.exists():
            return []
        
        try:
            records = []
            
            with open(file_path, 'r', encoding='utf-8') as f:
                for line_num, line in enumerate(f, 1):
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        record = json.loads(line)
                        
                        # Apply filters
                        if filters:
                            if not self._matches_filters(record, filters):
                                continue
                        
                        records.append(record)
                        
                    except json.JSONDecodeError as e:
                        current_app.logger.warning(f"Invalid JSON on line {line_num} in {file_path}: {e}")
                        continue
            
            # Apply pagination
            if offset > 0:
                records = records[offset:]
            
            if limit is not None:
                records = records[:limit]
            
            return records
            
        except Exception as e:
            current_app.logger.error(f"Failed to read JSONL file {file_path}: {e}")
            return []
    
    def _matches_filters(self, record: Dict[str, Any], filters: Dict[str, Any]) -> bool:
        """
        Check if a record matches the given filters.
        
        Args:
            record: Record dictionary
            filters: Filter dictionary
            
        Returns:
            True if record matches all filters
        """
        for key, value in filters.items():
            if key not in record:
                return False
            
            record_value = record[key]
            
            # Handle different filter types
            if isinstance(value, str):
                if record_value != value:
                    return False
            elif isinstance(value, (int, float)):
                if record_value != value:
                    return False
            elif isinstance(value, list):
                if record_value not in value:
                    return False
            else:
                if record_value != value:
                    return False
        
        return True
    
    def log_episode(self, episode_data: Dict[str, Any], filename: str) -> bool:
        """
        Log an episode to the specified JSONL file.
        
        Args:
            episode_data: Episode data dictionary
            filename: Name of the JSONL file (e.g., 'phase2_rag.jsonl')
            
        Returns:
            True if logged successfully
        """
        if filename not in self.episode_files:
            current_app.logger.error(f"Unknown episode file: {filename}")
            return False
        
        file_path = self.episode_files[filename]
        
        # Add metadata
        episode_data['logged_at'] = datetime.utcnow().isoformat()
        
        # Log the episode
        success = self._write_jsonl_line(file_path, episode_data)
        
        if success:
            current_app.logger.info(f"Logged episode to {filename}: {episode_data.get('episode_id', 'unknown')}")
        
        return success
    
    def read_episodes(self, filename: str, 
                     filters: Dict[str, Any] = None, 
                     limit: int = None, 
                     offset: int = 0) -> List[Dict[str, Any]]:
        """
        Read episodes from the specified JSONL file.
        
        Args:
            filename: Name of the JSONL file
            filters: Optional filters to apply
            limit: Maximum number of records to return
            offset: Number of records to skip
            
        Returns:
            List of episode records
        """
        if filename not in self.episode_files:
            current_app.logger.error(f"Unknown episode file: {filename}")
            return []
        
        file_path = self.episode_files[filename]
        return self._read_jsonl_file(file_path, filters, limit, offset)
    
    def get_episode_by_id(self, episode_id: str, filename: str) -> Optional[Dict[str, Any]]:
        """
        Get a specific episode by its ID.
        
        Args:
            episode_id: Episode identifier
            filename: Name of the JSONL file
            
        Returns:
            Episode record or None if not found
        """
        episodes = self.read_episodes(filename, filters={'episode_id': episode_id}, limit=1)
        return episodes[0] if episodes else None
    
    def update_episode(self, episode_id: str, updated_data: Dict[str, Any], filename: str) -> bool:
        """
        Update an existing episode in place.
        
        Note: This is inefficient for large files as it rewrites the entire file.
        For production, consider using a database for frequent updates.
        
        Args:
            episode_id: Episode identifier
            updated_data: Updated episode data
            filename: Name of the JSONL file
            
        Returns:
            True if updated successfully
        """
        if filename not in self.episode_files:
            return False
        
        file_path = self.episode_files[filename]
        
        if not file_path.exists():
            return False
        
        try:
            # Read all episodes
            all_episodes = []
            updated = False
            
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        episode = json.loads(line)
                        
                        if episode.get('episode_id') == episode_id:
                            # Update this episode
                            episode.update(updated_data)
                            episode['updated_at'] = datetime.utcnow().isoformat()
                            updated = True
                        
                        all_episodes.append(episode)
                        
                    except json.JSONDecodeError:
                        continue
            
            if not updated:
                return False
            
            # Rewrite the file
            with open(file_path, 'w', encoding='utf-8') as f:
                for episode in all_episodes:
                    json_line = json.dumps(episode, ensure_ascii=False, separators=(',', ':'))
                    f.write(json_line + '\n')
            
            current_app.logger.info(f"Updated episode {episode_id} in {filename}")
            return True
            
        except Exception as e:
            current_app.logger.error(f"Failed to update episode {episode_id}: {e}")
            return False
    
    def get_episode_statistics(self, filename: str) -> Dict[str, Any]:
        """
        Get statistics for episodes in a file.
        
        Args:
            filename: Name of the JSONL file
            
        Returns:
            Statistics dictionary
        """
        episodes = self.read_episodes(filename)
        
        if not episodes:
            return {
                'total_episodes': 0,
                'date_range': None,
                'phases': {},
                'models': {},
                'file_size_mb': 0
            }
        
        # Basic statistics
        stats = {
            'total_episodes': len(episodes),
            'phases': {},
            'models': {},
            'preferences': {},
            'date_range': {
                'earliest': None,
                'latest': None
            }
        }
        
        # Analyze episodes
        timestamps = []
        
        for episode in episodes:
            # Collect timestamps
            timestamp = episode.get('timestamp')
            if timestamp:
                timestamps.append(timestamp)
            
            # Count phases
            phase = episode.get('phase', 'unknown')
            stats['phases'][phase] = stats['phases'].get(phase, 0) + 1
            
            # Count models
            model = episode.get('model_version', episode.get('model_used', 'unknown'))
            stats['models'][model] = stats['models'].get(model, 0) + 1
            
            # Count preferences (for A/B testing files)
            if 'user_preference' in episode:
                pref = episode['user_preference']
                stats['preferences'][pref] = stats['preferences'].get(pref, 0) + 1
        
        # Date range
        if timestamps:
            timestamps.sort()
            stats['date_range']['earliest'] = timestamps[0]
            stats['date_range']['latest'] = timestamps[-1]
        
        # File size
        file_path = self.episode_files.get(filename)
        if file_path and file_path.exists():
            stats['file_size_mb'] = file_path.stat().st_size / (1024 * 1024)
        
        return stats
    
    def export_episodes(self, filename: str, 
                       filters: Dict[str, Any] = None,
                       format: str = 'jsonl') -> str:
        """
        Export episodes in the specified format.
        
        Args:
            filename: Name of the JSONL file
            filters: Optional filters to apply
            format: Export format ('jsonl', 'json', 'csv')
            
        Returns:
            Exported data as string
        """
        episodes = self.read_episodes(filename, filters)
        
        if format == 'jsonl':
            lines = []
            for episode in episodes:
                lines.append(json.dumps(episode, ensure_ascii=False))
            return '\n'.join(lines)
        
        elif format == 'json':
            return json.dumps(episodes, ensure_ascii=False, indent=2)
        
        elif format == 'csv':
            if not episodes:
                return ""
            
            import pandas as pd
            import io
            
            # Flatten nested dictionaries for CSV
            flattened_episodes = []
            
            for episode in episodes:
                flat_episode = {}
                
                for key, value in episode.items():
                    if isinstance(value, dict):
                        for subkey, subvalue in value.items():
                            flat_episode[f"{key}_{subkey}"] = subvalue
                    elif isinstance(value, list):
                        flat_episode[key] = json.dumps(value)
                    else:
                        flat_episode[key] = value
                
                flattened_episodes.append(flat_episode)
            
            df = pd.DataFrame(flattened_episodes)
            csv_buffer = io.StringIO()
            df.to_csv(csv_buffer, index=False)
            return csv_buffer.getvalue()
        
        else:
            raise ValueError(f"Unsupported export format: {format}")
    
    def cleanup_old_episodes(self, filename: str, days_to_keep: int = 90) -> int:
        """
        Clean up old episodes beyond the retention period.
        
        Args:
            filename: Name of the JSONL file
            days_to_keep: Number of days to retain
            
        Returns:
            Number of episodes removed
        """
        from datetime import timedelta
        
        cutoff_date = (datetime.utcnow() - timedelta(days=days_to_keep)).isoformat()
        
        if filename not in self.episode_files:
            return 0
        
        file_path = self.episode_files[filename]
        
        if not file_path.exists():
            return 0
        
        try:
            kept_episodes = []
            removed_count = 0
            
            with open(file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    
                    try:
                        episode = json.loads(line)
                        timestamp = episode.get('timestamp', '')
                        
                        if timestamp >= cutoff_date:
                            kept_episodes.append(episode)
                        else:
                            removed_count += 1
                            
                    except json.JSONDecodeError:
                        continue
            
            # Rewrite file with kept episodes
            if removed_count > 0:
                with open(file_path, 'w', encoding='utf-8') as f:
                    for episode in kept_episodes:
                        json_line = json.dumps(episode, ensure_ascii=False, separators=(',', ':'))
                        f.write(json_line + '\n')
                
                current_app.logger.info(f"Cleaned up {removed_count} old episodes from {filename}")
            
            return removed_count
            
        except Exception as e:
            current_app.logger.error(f"Failed to cleanup episodes in {filename}: {e}")
            return 0