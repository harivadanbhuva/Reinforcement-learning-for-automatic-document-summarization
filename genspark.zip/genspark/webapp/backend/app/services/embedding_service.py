"""
Embedding service for generating and managing document embeddings.

Uses Ollama for local embedding generation with caching and batch processing.
"""

import json
import time
import hashlib
from typing import List, Dict, Any, Optional
from pathlib import Path

import requests
import numpy as np
from flask import current_app


class EmbeddingService:
    """Service for generating embeddings using Ollama."""
    
    def __init__(self):
        """Initialize the embedding service."""
        self.ollama_host = current_app.config['OLLAMA_HOST']
        self.embedding_model = "nomic-embed-text"  # Default Ollama embedding model
        self.batch_size = current_app.config['EMBEDDING_BATCH_SIZE']
        self.cache_enabled = current_app.config['ENABLE_CACHING']
        
        # Cache directory for embeddings
        self.cache_dir = Path('./cache/embeddings')
        if self.cache_enabled:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_cache_key(self, text: str, model: str = None) -> str:
        """Generate cache key for text and model combination."""
        if not model:
            model = self.embedding_model
        
        # Create hash of text and model
        content = f"{text}|{model}"
        return hashlib.md5(content.encode()).hexdigest()
    
    def _load_from_cache(self, cache_key: str) -> Optional[List[float]]:
        """Load embedding from cache if available."""
        if not self.cache_enabled:
            return None
        
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        try:
            if cache_file.exists():
                with open(cache_file, 'r') as f:
                    data = json.load(f)
                    return data['embedding']
        except Exception as e:
            current_app.logger.warning(f"Failed to load embedding from cache: {e}")
        
        return None
    
    def _save_to_cache(self, cache_key: str, embedding: List[float]) -> None:
        """Save embedding to cache."""
        if not self.cache_enabled:
            return
        
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        try:
            cache_data = {
                'embedding': embedding,
                'model': self.embedding_model,
                'timestamp': time.time()
            }
            
            with open(cache_file, 'w') as f:
                json.dump(cache_data, f)
                
        except Exception as e:
            current_app.logger.warning(f"Failed to save embedding to cache: {e}")
    
    def _call_ollama_api(self, text: str, model: str = None) -> List[float]:
        """Call Ollama API to generate embedding."""
        if not model:
            model = self.embedding_model
        
        # Check if this is a mock environment
        if current_app.config.get('MOCK_OLLAMA'):
            # Return a mock embedding for testing
            return [0.1] * 768  # Standard embedding dimension
        
        url = f"{self.ollama_host}/api/embeddings"
        
        payload = {
            "model": model,
            "prompt": text
        }
        
        try:
            response = requests.post(
                url,
                json=payload,
                timeout=60,
                headers={'Content-Type': 'application/json'}
            )
            
            response.raise_for_status()
            result = response.json()
            
            if 'embedding' not in result:
                raise ValueError(f"No embedding in response: {result}")
            
            return result['embedding']
            
        except requests.exceptions.RequestException as e:
            raise RuntimeError(f"Ollama API request failed: {str(e)}")
        except (KeyError, ValueError) as e:
            raise RuntimeError(f"Invalid Ollama API response: {str(e)}")
    
    def generate_embedding(self, text: str, model: str = None) -> List[float]:
        """
        Generate embedding for a single text.
        
        Args:
            text: Text to embed
            model: Model name (optional)
            
        Returns:
            Embedding vector as list of floats
        """
        if not text or not text.strip():
            raise ValueError("Text cannot be empty")
        
        text = text.strip()
        
        # Try cache first
        cache_key = self._get_cache_key(text, model)
        cached_embedding = self._load_from_cache(cache_key)
        
        if cached_embedding:
            current_app.logger.debug(f"Using cached embedding for text: {text[:50]}...")
            return cached_embedding
        
        # Generate new embedding
        current_app.logger.info(f"Generating embedding for text: {text[:50]}...")
        
        try:
            embedding = self._call_ollama_api(text, model)
            
            # Save to cache
            self._save_to_cache(cache_key, embedding)
            
            return embedding
            
        except Exception as e:
            current_app.logger.error(f"Failed to generate embedding: {str(e)}")
            raise
    
    def generate_embeddings_batch(self, texts: List[str], model: str = None) -> List[List[float]]:
        """
        Generate embeddings for multiple texts with batching.
        
        Args:
            texts: List of texts to embed
            model: Model name (optional)
            
        Returns:
            List of embedding vectors
        """
        if not texts:
            return []
        
        embeddings = []
        
        # Process in batches for efficiency
        for i in range(0, len(texts), self.batch_size):
            batch_texts = texts[i:i + self.batch_size]
            batch_embeddings = []
            
            for text in batch_texts:
                try:
                    embedding = self.generate_embedding(text, model)
                    batch_embeddings.append(embedding)
                except Exception as e:
                    current_app.logger.error(f"Failed to embed text in batch: {str(e)}")
                    # Use zero vector as fallback
                    batch_embeddings.append([0.0] * 768)
            
            embeddings.extend(batch_embeddings)
            
            # Small delay between batches to avoid overwhelming Ollama
            if i + self.batch_size < len(texts):
                time.sleep(0.1)
        
        return embeddings
    
    def embed_document_chunks(self, chunks: List[Dict[str, Any]], doc_id: str) -> List[Dict[str, Any]]:
        """
        Generate embeddings for document chunks.
        
        Args:
            chunks: List of chunk dictionaries from DocumentProcessor
            doc_id: Document identifier
            
        Returns:
            Chunks with embeddings added
        """
        if not chunks:
            return []
        
        current_app.logger.info(f"Embedding {len(chunks)} chunks for document {doc_id}")
        
        # Extract texts for batch embedding
        texts = [chunk['text'] for chunk in chunks]
        
        # Generate embeddings
        embeddings = self.generate_embeddings_batch(texts)
        
        # Add embeddings to chunks
        embedded_chunks = []
        for i, chunk in enumerate(chunks):
            embedded_chunk = chunk.copy()
            embedded_chunk['embedding'] = embeddings[i]
            embedded_chunk['doc_id'] = doc_id
            embedded_chunk['embedding_model'] = self.embedding_model
            embedded_chunk['embedding_dim'] = len(embeddings[i])
            embedded_chunk['embedded_at'] = time.time()
            
            embedded_chunks.append(embedded_chunk)
        
        return embedded_chunks
    
    def embed_query(self, query: str) -> List[float]:
        """
        Generate embedding for a search query.
        
        Args:
            query: Search query text
            
        Returns:
            Query embedding vector
        """
        if not query or not query.strip():
            raise ValueError("Query cannot be empty")
        
        return self.generate_embedding(query.strip())
    
    def cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """
        Calculate cosine similarity between two vectors.
        
        Args:
            vec1: First vector
            vec2: Second vector
            
        Returns:
            Cosine similarity score (0-1)
        """
        if len(vec1) != len(vec2):
            raise ValueError("Vectors must have the same dimension")
        
        # Convert to numpy arrays for efficient computation
        a = np.array(vec1)
        b = np.array(vec2)
        
        # Calculate cosine similarity
        dot_product = np.dot(a, b)
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        
        if norm_a == 0 or norm_b == 0:
            return 0.0
        
        similarity = dot_product / (norm_a * norm_b)
        
        # Clamp to [0, 1] range and handle numerical issues
        return max(0.0, min(1.0, float(similarity)))
    
    def find_similar_chunks(self, query_embedding: List[float], 
                           chunk_embeddings: List[Dict[str, Any]], 
                           top_k: int = 5, 
                           min_similarity: float = 0.1) -> List[Dict[str, Any]]:
        """
        Find chunks most similar to query embedding.
        
        Args:
            query_embedding: Query embedding vector
            chunk_embeddings: List of chunk dictionaries with embeddings
            top_k: Number of top results to return
            min_similarity: Minimum similarity threshold
            
        Returns:
            Top-k similar chunks with similarity scores
        """
        if not chunk_embeddings:
            return []
        
        # Calculate similarities
        similarities = []
        
        for chunk in chunk_embeddings:
            try:
                chunk_embedding = chunk.get('embedding')
                if not chunk_embedding:
                    continue
                
                similarity = self.cosine_similarity(query_embedding, chunk_embedding)
                
                if similarity >= min_similarity:
                    result_chunk = chunk.copy()
                    result_chunk['similarity_score'] = similarity
                    similarities.append(result_chunk)
                    
            except Exception as e:
                current_app.logger.warning(f"Failed to calculate similarity for chunk: {e}")
                continue
        
        # Sort by similarity (highest first) and return top-k
        similarities.sort(key=lambda x: x['similarity_score'], reverse=True)
        return similarities[:top_k]
    
    def get_embedding_statistics(self) -> Dict[str, Any]:
        """
        Get embedding service statistics.
        
        Returns:
            Statistics about embeddings and cache
        """
        stats = {
            'model': self.embedding_model,
            'ollama_host': self.ollama_host,
            'batch_size': self.batch_size,
            'cache_enabled': self.cache_enabled,
            'cache_size': 0
        }
        
        # Count cached embeddings
        if self.cache_enabled and self.cache_dir.exists():
            cache_files = list(self.cache_dir.glob("*.json"))
            stats['cache_size'] = len(cache_files)
        
        return stats
    
    def clear_cache(self) -> int:
        """
        Clear embedding cache.
        
        Returns:
            Number of cache files removed
        """
        if not self.cache_enabled or not self.cache_dir.exists():
            return 0
        
        removed_count = 0
        
        try:
            for cache_file in self.cache_dir.glob("*.json"):
                cache_file.unlink()
                removed_count += 1
                
        except Exception as e:
            current_app.logger.error(f"Failed to clear embedding cache: {e}")
        
        return removed_count
    
    def validate_ollama_connection(self) -> Dict[str, Any]:
        """
        Validate connection to Ollama service.
        
        Returns:
            Connection status and model availability
        """
        status = {
            'connected': False,
            'models_available': [],
            'embedding_model_available': False,
            'error': None
        }
        
        try:
            # Check if Ollama is running
            response = requests.get(f"{self.ollama_host}/api/tags", timeout=10)
            response.raise_for_status()
            
            models_info = response.json()
            available_models = [model['name'] for model in models_info.get('models', [])]
            
            status['connected'] = True
            status['models_available'] = available_models
            status['embedding_model_available'] = self.embedding_model in available_models
            
            # Test embedding generation
            if status['embedding_model_available']:
                try:
                    test_embedding = self._call_ollama_api("test")
                    status['test_embedding_success'] = True
                    status['embedding_dimension'] = len(test_embedding)
                except Exception as e:
                    status['test_embedding_success'] = False
                    status['test_embedding_error'] = str(e)
            
        except requests.exceptions.RequestException as e:
            status['error'] = f"Connection failed: {str(e)}"
        except Exception as e:
            status['error'] = f"Unexpected error: {str(e)}"
        
        return status