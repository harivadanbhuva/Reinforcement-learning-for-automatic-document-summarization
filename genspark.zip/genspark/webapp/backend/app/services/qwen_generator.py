"""
Qwen model generator service.

Handles fine-tuned Qwen2.5-7B-Instruct model loading, inference,
and dual summary generation for A/B testing.
"""

import json
import time
import torch
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime

from transformers import (
    AutoTokenizer, 
    AutoModelForCausalLM, 
    GenerationConfig,
    pipeline
)
from flask import current_app


class QwenGenerator:
    """Service for Qwen model inference and management."""
    
    def __init__(self):
        """Initialize the Qwen generator service."""
        self.model_base_name = current_app.config['MODEL_BASE_NAME']
        self.checkpoints_path = current_app.config['CHECKPOINTS_PATH']
        self.active_model_version = current_app.config['ACTIVE_MODEL_VERSION']
        self.max_summary_length = current_app.config['MAX_SUMMARY_LENGTH']
        
        # Model components
        self.tokenizer = None
        self.model = None
        self.generation_config = None
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # Current model info
        self.current_model_info = {
            'version': None,
            'loaded_at': None,
            'model_path': None,
            'parameters': 0
        }
        
        # Load the active model
        self._load_active_model()
    
    def _load_active_model(self) -> bool:
        """Load the currently active model."""
        try:
            # Check if we have a checkpoint for the active version
            model_path = self.checkpoints_path / self.active_model_version
            
            if model_path.exists():
                return self.load_model_version(self.active_model_version)
            else:
                # Fall back to base model
                current_app.logger.warning(
                    f"Active model version {self.active_model_version} not found, "
                    f"loading base model"
                )
                return self._load_base_model()
                
        except Exception as e:
            current_app.logger.error(f"Failed to load active model: {e}")
            return False
    
    def _load_base_model(self) -> bool:
        """Load the base Qwen model from Hugging Face."""
        try:
            current_app.logger.info(f"Loading base Qwen model: {self.model_base_name}")
            
            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(
                self.model_base_name,
                trust_remote_code=True
            )
            
            # Load model
            self.model = AutoModelForCausalLM.from_pretrained(
                self.model_base_name,
                device_map="auto" if self.device == "cuda" else None,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                trust_remote_code=True
            )
            
            # Set up generation config
            self.generation_config = GenerationConfig(
                max_new_tokens=self.max_summary_length,
                do_sample=True,
                temperature=0.3,
                top_p=0.9,
                repetition_penalty=1.1,
                pad_token_id=self.tokenizer.eos_token_id
            )
            
            # Update model info
            self.current_model_info = {
                'version': 'base',
                'loaded_at': datetime.utcnow().isoformat(),
                'model_path': self.model_base_name,
                'parameters': sum(p.numel() for p in self.model.parameters())
            }
            
            current_app.logger.info(f"Successfully loaded base Qwen model on {self.device}")
            return True
            
        except Exception as e:
            current_app.logger.error(f"Failed to load base model: {e}")
            return False
    
    def load_model_version(self, version: str) -> bool:
        """
        Load a specific fine-tuned model version.
        
        Args:
            version: Model version identifier
            
        Returns:
            True if loaded successfully
        """
        model_path = self.checkpoints_path / version
        
        if not model_path.exists():
            current_app.logger.error(f"Model version {version} not found at {model_path}")
            return False
        
        try:
            current_app.logger.info(f"Loading Qwen model version: {version}")
            
            # Unload current model to free memory
            self._unload_model()
            
            # Load tokenizer
            tokenizer_path = model_path
            if not (model_path / "tokenizer.json").exists():
                # Fall back to base model tokenizer
                tokenizer_path = self.model_base_name
            
            self.tokenizer = AutoTokenizer.from_pretrained(
                tokenizer_path,
                trust_remote_code=True
            )
            
            # Load fine-tuned model
            self.model = AutoModelForCausalLM.from_pretrained(
                model_path,
                device_map="auto" if self.device == "cuda" else None,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                trust_remote_code=True
            )
            
            # Set up generation config
            self.generation_config = GenerationConfig(
                max_new_tokens=self.max_summary_length,
                do_sample=True,
                temperature=0.3,
                top_p=0.9,
                repetition_penalty=1.1,
                pad_token_id=self.tokenizer.eos_token_id
            )
            
            # Update model info
            self.current_model_info = {
                'version': version,
                'loaded_at': datetime.utcnow().isoformat(),
                'model_path': str(model_path),
                'parameters': sum(p.numel() for p in self.model.parameters())
            }
            
            # Update active model version
            self.active_model_version = version
            
            current_app.logger.info(f"Successfully loaded model version {version}")
            return True
            
        except Exception as e:
            current_app.logger.error(f"Failed to load model version {version}: {e}")
            # Try to reload base model as fallback
            self._load_base_model()
            return False
    
    def _unload_model(self) -> None:
        """Unload current model to free memory."""
        if self.model is not None:
            del self.model
            self.model = None
        
        if self.tokenizer is not None:
            del self.tokenizer
            self.tokenizer = None
        
        # Clear CUDA cache if available
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    
    def _generate_text(self, prompt: str, max_tokens: int = None) -> Dict[str, Any]:
        """
        Generate text using the loaded model.
        
        Args:
            prompt: Input prompt
            max_tokens: Maximum tokens to generate
            
        Returns:
            Generation result with metadata
        """
        if self.model is None or self.tokenizer is None:
            raise RuntimeError("No model loaded")
        
        try:
            start_time = time.time()
            
            # Tokenize input
            inputs = self.tokenizer(prompt, return_tensors="pt")
            
            if self.device == "cuda":
                inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            # Update generation config if max_tokens specified
            gen_config = self.generation_config
            if max_tokens:
                gen_config = GenerationConfig(
                    max_new_tokens=max_tokens,
                    do_sample=gen_config.do_sample,
                    temperature=gen_config.temperature,
                    top_p=gen_config.top_p,
                    repetition_penalty=gen_config.repetition_penalty,
                    pad_token_id=gen_config.pad_token_id
                )
            
            # Generate
            with torch.no_grad():
                outputs = self.model.generate(
                    **inputs,
                    generation_config=gen_config,
                    pad_token_id=self.tokenizer.eos_token_id
                )
            
            # Decode generated text (excluding input)
            input_length = inputs['input_ids'].shape[1]
            generated_tokens = outputs[0][input_length:]
            generated_text = self.tokenizer.decode(generated_tokens, skip_special_tokens=True)
            
            generation_time_ms = (time.time() - start_time) * 1000
            
            return {
                'text': generated_text.strip(),
                'tokens_generated': len(generated_tokens),
                'generation_time_ms': generation_time_ms,
                'model_version': self.current_model_info['version']
            }
            
        except Exception as e:
            current_app.logger.error(f"Text generation failed: {e}")
            raise RuntimeError(f"Generation failed: {str(e)}")
    
    def generate_extractive_summary(self, query: str, context: str) -> Dict[str, Any]:
        """
        Generate extractive-style summary (Summary A).
        
        Args:
            query: User query
            context: Retrieved context
            
        Returns:
            Extractive summary with metadata
        """
        extractive_prompt = f"""You are an expert summarizer specializing in extractive summarization. Your task is to create a summary by selecting and organizing the most relevant sentences from the provided context.

Instructions:
1. Extract key sentences that directly relate to the query
2. Maintain the original wording from the source text
3. Organize extracted sentences in a logical, coherent flow
4. Focus on factual accuracy and relevance
5. Do not add information not present in the context

Query: {query}

Context:
{context}

Extractive Summary:"""
        
        try:
            result = self._generate_text(extractive_prompt, max_tokens=200)
            result['summary_type'] = 'extractive'
            return result
            
        except Exception as e:
            return {
                'text': f"Failed to generate extractive summary: {str(e)}",
                'tokens_generated': 0,
                'generation_time_ms': 0,
                'model_version': self.current_model_info.get('version', 'unknown'),
                'summary_type': 'extractive',
                'error': str(e)
            }
    
    def generate_abstractive_summary(self, query: str, context: str) -> Dict[str, Any]:
        """
        Generate abstractive-style summary (Summary B).
        
        Args:
            query: User query
            context: Retrieved context
            
        Returns:
            Abstractive summary with metadata
        """
        abstractive_prompt = f"""You are an expert summarizer specializing in abstractive summarization. Your task is to create a comprehensive summary by synthesizing information and expressing it in your own words.

Instructions:
1. Analyze and understand the key information in the context
2. Synthesize information to create new, coherent sentences
3. Provide insights and connections between ideas
4. Ensure the summary is informative and well-structured
5. You may rephrase and restructure content for clarity

Query: {query}

Context:
{context}

Abstractive Summary:"""
        
        try:
            result = self._generate_text(abstractive_prompt, max_tokens=200)
            result['summary_type'] = 'abstractive'
            return result
            
        except Exception as e:
            return {
                'text': f"Failed to generate abstractive summary: {str(e)}",
                'tokens_generated': 0,
                'generation_time_ms': 0,
                'model_version': self.current_model_info.get('version', 'unknown'),
                'summary_type': 'abstractive',
                'error': str(e)
            }
    
    def generate_dual_summaries(self, query: str, context: str) -> Dict[str, Any]:
        """
        Generate both extractive and abstractive summaries for A/B testing.
        
        Args:
            query: User query
            context: Retrieved context
            
        Returns:
            Both summaries with metadata
        """
        start_time = time.time()
        
        # Generate both summaries
        extractive_result = self.generate_extractive_summary(query, context)
        abstractive_result = self.generate_abstractive_summary(query, context)
        
        total_time_ms = (time.time() - start_time) * 1000
        
        return {
            'summary_a': extractive_result['text'],
            'summary_b': abstractive_result['text'],
            'tokens_a': extractive_result['tokens_generated'],
            'tokens_b': abstractive_result['tokens_generated'],
            'generation_time_ms': total_time_ms,
            'model_version': self.current_model_info['version'],
            'extractive_metadata': extractive_result,
            'abstractive_metadata': abstractive_result
        }
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get current model information."""
        info = self.current_model_info.copy()
        
        info.update({
            'device': self.device,
            'cuda_available': torch.cuda.is_available(),
            'model_loaded': self.model is not None,
            'tokenizer_loaded': self.tokenizer is not None
        })
        
        # Add memory info if CUDA
        if torch.cuda.is_available() and self.device == "cuda":
            info['gpu_memory_allocated'] = torch.cuda.memory_allocated()
            info['gpu_memory_reserved'] = torch.cuda.memory_reserved()
        
        return info
    
    def validate_model_performance(self, test_queries: List[str] = None) -> Dict[str, Any]:
        """
        Validate model performance with test queries.
        
        Args:
            test_queries: List of test queries (optional)
            
        Returns:
            Performance validation results
        """
        if not test_queries:
            test_queries = [
                "What are the main benefits of renewable energy?",
                "Explain the concept of machine learning.",
                "How does climate change affect the environment?"
            ]
        
        results = {
            'model_version': self.current_model_info['version'],
            'test_timestamp': datetime.utcnow().isoformat(),
            'total_tests': len(test_queries),
            'successful_tests': 0,
            'failed_tests': 0,
            'average_generation_time_ms': 0,
            'test_results': []
        }
        
        total_time = 0
        
        for i, query in enumerate(test_queries):
            try:
                test_context = f"This is a test context for the query: {query}"
                
                start_time = time.time()
                dual_result = self.generate_dual_summaries(query, test_context)
                generation_time = (time.time() - start_time) * 1000
                
                test_result = {
                    'query_index': i,
                    'query': query,
                    'summary_a_length': len(dual_result['summary_a']),
                    'summary_b_length': len(dual_result['summary_b']),
                    'generation_time_ms': generation_time,
                    'status': 'success'
                }
                
                total_time += generation_time
                results['successful_tests'] += 1
                
            except Exception as e:
                test_result = {
                    'query_index': i,
                    'query': query,
                    'error': str(e),
                    'status': 'failed'
                }
                
                results['failed_tests'] += 1
            
            results['test_results'].append(test_result)
        
        # Calculate averages
        if results['successful_tests'] > 0:
            results['average_generation_time_ms'] = total_time / results['successful_tests']
        
        results['success_rate'] = results['successful_tests'] / results['total_tests']
        
        return results
    
    def get_available_model_versions(self) -> List[Dict[str, Any]]:
        """Get list of available model versions."""
        versions = []
        
        if self.checkpoints_path.exists():
            for version_dir in self.checkpoints_path.iterdir():
                if version_dir.is_dir():
                    # Check if it's a valid model directory
                    config_file = version_dir / "config.json"
                    
                    version_info = {
                        'version': version_dir.name,
                        'path': str(version_dir),
                        'is_active': version_dir.name == self.active_model_version,
                        'valid': config_file.exists()
                    }
                    
                    # Get additional metadata if available
                    if config_file.exists():
                        try:
                            with open(config_file, 'r') as f:
                                config = json.load(f)
                                version_info['model_type'] = config.get('model_type', 'unknown')
                                version_info['vocab_size'] = config.get('vocab_size', 0)
                        except Exception:
                            pass
                    
                    # Get directory size
                    try:
                        total_size = sum(
                            f.stat().st_size for f in version_dir.rglob('*') if f.is_file()
                        )
                        version_info['size_mb'] = total_size / (1024 * 1024)
                    except Exception:
                        version_info['size_mb'] = 0
                    
                    versions.append(version_info)
        
        # Sort by version name
        versions.sort(key=lambda x: x['version'])
        return versions