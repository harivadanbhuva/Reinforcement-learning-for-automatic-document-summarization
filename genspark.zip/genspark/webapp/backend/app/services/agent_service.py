"""
Agent service for external knowledge retrieval.

Implements search agents for DuckDuckGo and Wikipedia to augment
document context with external knowledge for abstractive summarization.
"""

import time
from typing import Dict, List, Any, Optional

import requests
from duckduckgo_search import DDGS
import wikipedia
from flask import current_app


class AgentService:
    """Service for managing search agents and external knowledge retrieval."""
    
    def __init__(self):
        """Initialize the agent service."""
        self.duckduckgo_enabled = current_app.config['ENABLE_AGENTS']
        self.wikipedia_enabled = current_app.config['ENABLE_AGENTS']
        
        # Rate limiting
        self.request_delay = 1.0  # Seconds between requests
        self.last_request_time = 0
        
        # Configuration
        self.max_results_per_source = 5
        self.max_snippet_length = 300
        self.timeout = 10
    
    def _rate_limit(self):
        """Apply rate limiting between requests."""
        current_time = time.time()
        time_since_last = current_time - self.last_request_time
        
        if time_since_last < self.request_delay:
            sleep_time = self.request_delay - time_since_last
            time.sleep(sleep_time)
        
        self.last_request_time = time.time()
    
    def search_duckduckgo(self, query: str, max_results: int = None) -> Dict[str, Any]:
        """
        Search DuckDuckGo for web results.
        
        Args:
            query: Search query
            max_results: Maximum number of results (default from config)
            
        Returns:
            Search results with metadata
        """
        if not self.duckduckgo_enabled:
            return {'results': [], 'source': 'duckduckgo', 'error': 'DuckDuckGo search disabled'}
        
        if not query or not query.strip():
            return {'results': [], 'source': 'duckduckgo', 'error': 'Empty query'}
        
        max_results = max_results or self.max_results_per_source
        
        try:
            self._rate_limit()
            
            current_app.logger.info(f"Searching DuckDuckGo for: {query}")
            
            # Use duckduckgo-search library
            with DDGS() as ddgs:
                results = []
                
                # Search for web results
                search_results = ddgs.text(
                    query,
                    region='wt-wt',  # Global
                    safesearch='moderate',
                    timelimit='y',  # Past year
                    max_results=max_results
                )
                
                for result in search_results:
                    try:
                        # Clean and truncate snippet
                        snippet = result.get('body', '')
                        if len(snippet) > self.max_snippet_length:
                            snippet = snippet[:self.max_snippet_length] + "..."
                        
                        processed_result = {
                            'title': result.get('title', ''),
                            'url': result.get('href', ''),
                            'snippet': snippet,
                            'source': 'duckduckgo'
                        }
                        
                        results.append(processed_result)
                        
                    except Exception as e:
                        current_app.logger.warning(f"Error processing DuckDuckGo result: {e}")
                        continue
            
            current_app.logger.info(f"DuckDuckGo returned {len(results)} results")
            
            return {
                'results': results,
                'source': 'duckduckgo',
                'query': query,
                'total_results': len(results),
                'search_time': time.time()
            }
            
        except Exception as e:
            current_app.logger.error(f"DuckDuckGo search failed: {str(e)}")
            return {
                'results': [],
                'source': 'duckduckgo',
                'query': query,
                'error': str(e)
            }
    
    def search_wikipedia(self, query: str, max_results: int = None) -> Dict[str, Any]:
        """
        Search Wikipedia for relevant articles.
        
        Args:
            query: Search query
            max_results: Maximum number of results (default from config)
            
        Returns:
            Wikipedia search results with summaries
        """
        if not self.wikipedia_enabled:
            return {'results': [], 'source': 'wikipedia', 'error': 'Wikipedia search disabled'}
        
        if not query or not query.strip():
            return {'results': [], 'source': 'wikipedia', 'error': 'Empty query'}
        
        max_results = max_results or self.max_results_per_source
        
        try:
            self._rate_limit()
            
            current_app.logger.info(f"Searching Wikipedia for: {query}")
            
            # Set language and user agent
            wikipedia.set_lang("en")
            wikipedia.set_user_agent("RL-Document-Summarization/1.0")
            
            # Search for articles
            search_results = wikipedia.search(query, results=max_results * 2)
            
            results = []
            
            for title in search_results[:max_results]:
                try:
                    # Get page summary
                    page_summary = wikipedia.summary(
                        title,
                        sentences=3,  # Limit to 3 sentences
                        auto_suggest=True
                    )
                    
                    # Get page URL
                    try:
                        page = wikipedia.page(title, auto_suggest=True)
                        page_url = page.url
                    except Exception:
                        page_url = f"https://en.wikipedia.org/wiki/{title.replace(' ', '_')}"
                    
                    # Truncate summary if needed
                    if len(page_summary) > self.max_snippet_length:
                        page_summary = page_summary[:self.max_snippet_length] + "..."
                    
                    result = {
                        'title': title,
                        'url': page_url,
                        'summary': page_summary,
                        'source': 'wikipedia'
                    }
                    
                    results.append(result)
                    
                except wikipedia.exceptions.DisambiguationError as e:
                    # Try the first suggestion
                    try:
                        if e.options:
                            first_option = e.options[0]
                            page_summary = wikipedia.summary(first_option, sentences=3)
                            
                            if len(page_summary) > self.max_snippet_length:
                                page_summary = page_summary[:self.max_snippet_length] + "..."
                            
                            result = {
                                'title': first_option,
                                'url': f"https://en.wikipedia.org/wiki/{first_option.replace(' ', '_')}",
                                'summary': page_summary,
                                'source': 'wikipedia'
                            }
                            
                            results.append(result)
                    except Exception:
                        continue
                        
                except wikipedia.exceptions.PageError:
                    # Page not found, skip
                    continue
                    
                except Exception as e:
                    current_app.logger.warning(f"Error processing Wikipedia result for '{title}': {e}")
                    continue
            
            current_app.logger.info(f"Wikipedia returned {len(results)} results")
            
            return {
                'results': results,
                'source': 'wikipedia',
                'query': query,
                'total_results': len(results),
                'search_time': time.time()
            }
            
        except Exception as e:
            current_app.logger.error(f"Wikipedia search failed: {str(e)}")
            return {
                'results': [],
                'source': 'wikipedia',
                'query': query,
                'error': str(e)
            }
    
    def search_all_sources(self, query: str) -> Dict[str, Any]:
        """
        Search all available sources and combine results.
        
        Args:
            query: Search query
            
        Returns:
            Combined results from all sources
        """
        all_results = {
            'query': query,
            'search_timestamp': time.time(),
            'sources_searched': [],
            'total_results': 0
        }
        
        try:
            # Search DuckDuckGo
            if self.duckduckgo_enabled:
                ddg_results = self.search_duckduckgo(query)
                all_results['duckduckgo_results'] = ddg_results.get('results', [])
                all_results['sources_searched'].append('duckduckgo')
                
                if 'error' in ddg_results:
                    all_results['duckduckgo_error'] = ddg_results['error']
            
            # Search Wikipedia
            if self.wikipedia_enabled:
                wiki_results = self.search_wikipedia(query)
                all_results['wikipedia_results'] = wiki_results.get('results', [])
                all_results['sources_searched'].append('wikipedia')
                
                if 'error' in wiki_results:
                    all_results['wikipedia_error'] = wiki_results['error']
            
            # Calculate total results
            total = 0
            if 'duckduckgo_results' in all_results:
                total += len(all_results['duckduckgo_results'])
            if 'wikipedia_results' in all_results:
                total += len(all_results['wikipedia_results'])
            
            all_results['total_results'] = total
            
            current_app.logger.info(
                f"Agent search completed: {total} total results from {len(all_results['sources_searched'])} sources"
            )
            
            return all_results
            
        except Exception as e:
            current_app.logger.error(f"Agent search failed: {str(e)}")
            all_results['error'] = str(e)
            return all_results
    
    def extract_key_information(self, query: str, search_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Extract key information from search results relevant to the query.
        
        Args:
            query: Original search query
            search_results: Results from search_all_sources
            
        Returns:
            Extracted and filtered information
        """
        extracted_info = {
            'query': query,
            'key_facts': [],
            'relevant_urls': [],
            'summary_points': []
        }
        
        try:
            # Process DuckDuckGo results
            ddg_results = search_results.get('duckduckgo_results', [])
            for result in ddg_results[:3]:  # Top 3 results
                if result.get('snippet'):
                    extracted_info['key_facts'].append({
                        'source': 'web',
                        'title': result.get('title', ''),
                        'content': result['snippet'],
                        'url': result.get('url', '')
                    })
                    
                    if result.get('url'):
                        extracted_info['relevant_urls'].append(result['url'])
            
            # Process Wikipedia results
            wiki_results = search_results.get('wikipedia_results', [])
            for result in wiki_results[:2]:  # Top 2 results
                if result.get('summary'):
                    extracted_info['key_facts'].append({
                        'source': 'wikipedia',
                        'title': result.get('title', ''),
                        'content': result['summary'],
                        'url': result.get('url', '')
                    })
                    
                    if result.get('url'):
                        extracted_info['relevant_urls'].append(result['url'])
            
            # Create summary points
            for fact in extracted_info['key_facts']:
                # Extract first sentence or main point
                content = fact['content']
                first_sentence = content.split('.')[0] + '.'
                
                if len(first_sentence) > 20:  # Ensure it's substantial
                    extracted_info['summary_points'].append({
                        'point': first_sentence,
                        'source': fact['source'],
                        'title': fact['title']
                    })
            
            return extracted_info
            
        except Exception as e:
            current_app.logger.error(f"Information extraction failed: {str(e)}")
            extracted_info['error'] = str(e)
            return extracted_info
    
    def validate_search_capabilities(self) -> Dict[str, Any]:
        """
        Validate search agent capabilities and connectivity.
        
        Returns:
            Status of each search agent
        """
        status = {
            'agents_enabled': current_app.config['ENABLE_AGENTS'],
            'duckduckgo': {
                'available': False,
                'error': None
            },
            'wikipedia': {
                'available': False,
                'error': None
            }
        }
        
        # Test DuckDuckGo
        if self.duckduckgo_enabled:
            try:
                test_results = self.search_duckduckgo("test query", max_results=1)
                if 'error' not in test_results:
                    status['duckduckgo']['available'] = True
                else:
                    status['duckduckgo']['error'] = test_results['error']
            except Exception as e:
                status['duckduckgo']['error'] = str(e)
        else:
            status['duckduckgo']['error'] = 'Disabled in configuration'
        
        # Test Wikipedia
        if self.wikipedia_enabled:
            try:
                test_results = self.search_wikipedia("test", max_results=1)
                if 'error' not in test_results:
                    status['wikipedia']['available'] = True
                else:
                    status['wikipedia']['error'] = test_results['error']
            except Exception as e:
                status['wikipedia']['error'] = str(e)
        else:
            status['wikipedia']['error'] = 'Disabled in configuration'
        
        return status