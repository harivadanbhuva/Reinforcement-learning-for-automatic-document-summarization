"""
Document processing service.

Handles document parsing, text extraction, cleaning, chunking, and management.
Supports PDF, TXT, DOCX formats and prepares documents for embedding.
"""

import os
import json
import uuid
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional, Any

import PyPDF2
from docx import Document
import magic

from flask import current_app


class DocumentProcessor:
    """Service for processing and managing documents."""
    
    def __init__(self):
        """Initialize the document processor."""
        self.documents_path = current_app.config['DOCUMENTS_PATH']
        self.raw_path = self.documents_path / 'raw'
        self.processed_path = self.documents_path / 'processed'
        
        # Ensure directories exist
        self.raw_path.mkdir(parents=True, exist_ok=True)
        self.processed_path.mkdir(parents=True, exist_ok=True)
    
    def extract_text_from_file(self, file_path: str, file_type: str = None) -> str:
        """
        Extract text content from various file formats.
        
        Args:
            file_path: Path to the file
            file_type: File type hint (pdf, txt, docx)
            
        Returns:
            Extracted text content
        """
        file_path = Path(file_path)
        
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Detect file type if not provided
        if not file_type:
            file_type = self._detect_file_type(file_path)
        
        try:
            if file_type == 'pdf':
                return self._extract_from_pdf(file_path)
            elif file_type in ['docx', 'doc']:
                return self._extract_from_docx(file_path)
            elif file_type == 'txt':
                return self._extract_from_txt(file_path)
            else:
                raise ValueError(f"Unsupported file type: {file_type}")
                
        except Exception as e:
            raise RuntimeError(f"Failed to extract text from {file_path}: {str(e)}")
    
    def _detect_file_type(self, file_path: Path) -> str:
        """Detect file type using python-magic and file extension."""
        try:
            mime_type = magic.from_file(str(file_path), mime=True)
            
            if mime_type == 'application/pdf':
                return 'pdf'
            elif mime_type in ['application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                              'application/msword']:
                return 'docx'
            elif mime_type.startswith('text/'):
                return 'txt'
            else:
                # Fall back to file extension
                extension = file_path.suffix.lower()
                if extension == '.pdf':
                    return 'pdf'
                elif extension in ['.docx', '.doc']:
                    return 'docx'
                elif extension in ['.txt', '.md']:
                    return 'txt'
                else:
                    raise ValueError(f"Unknown file type: {extension}")
                    
        except Exception as e:
            current_app.logger.warning(f"File type detection failed: {e}")
            # Fall back to extension
            extension = file_path.suffix.lower().lstrip('.')
            return extension
    
    def _extract_from_pdf(self, file_path: Path) -> str:
        """Extract text from PDF file."""
        text = []
        
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            
            for page_num, page in enumerate(pdf_reader.pages):
                try:
                    page_text = page.extract_text()
                    if page_text.strip():
                        text.append(f"[Page {page_num + 1}]\n{page_text}")
                except Exception as e:
                    current_app.logger.warning(f"Failed to extract page {page_num + 1}: {e}")
                    continue
        
        return '\n\n'.join(text)
    
    def _extract_from_docx(self, file_path: Path) -> str:
        """Extract text from DOCX file."""
        try:
            doc = Document(file_path)
            text = []
            
            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    text.append(paragraph.text)
            
            return '\n\n'.join(text)
            
        except Exception as e:
            raise RuntimeError(f"Failed to read DOCX file: {e}")
    
    def _extract_from_txt(self, file_path: Path) -> str:
        """Extract text from TXT file."""
        try:
            # Try different encodings
            encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
            
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as file:
                        return file.read()
                except UnicodeDecodeError:
                    continue
            
            # If all encodings fail, read as binary and decode with errors='ignore'
            with open(file_path, 'rb') as file:
                return file.read().decode('utf-8', errors='ignore')
                
        except Exception as e:
            raise RuntimeError(f"Failed to read text file: {e}")
    
    def clean_text(self, text: str) -> str:
        """
        Clean and normalize extracted text.
        
        Args:
            text: Raw extracted text
            
        Returns:
            Cleaned text
        """
        if not text:
            return ""
        
        # Remove excessive whitespace
        import re
        
        # Replace multiple newlines with double newlines
        text = re.sub(r'\n{3,}', '\n\n', text)
        
        # Replace multiple spaces with single space
        text = re.sub(r' {2,}', ' ', text)
        
        # Remove trailing/leading whitespace from lines
        lines = [line.strip() for line in text.split('\n')]
        text = '\n'.join(lines)
        
        # Remove empty lines at the beginning and end
        text = text.strip()
        
        # Fix common encoding issues
        replacements = {
            '"': '"', '"': '"',  # Smart quotes
            ''': "'", ''': "'",  # Smart apostrophes
            '–': '-', '—': '--',  # En dash, Em dash
            '…': '...',  # Ellipsis
            '\u00a0': ' ',  # Non-breaking space
            '\r\n': '\n',  # Windows line endings
            '\r': '\n'  # Mac line endings
        }
        
        for old, new in replacements.items():
            text = text.replace(old, new)
        
        return text
    
    def chunk_text(self, text: str, chunk_size: int = 1000, overlap: int = 200) -> List[Dict[str, Any]]:
        """
        Split text into overlapping chunks for embedding.
        
        Args:
            text: Clean text to chunk
            chunk_size: Maximum characters per chunk
            overlap: Number of characters to overlap between chunks
            
        Returns:
            List of chunk dictionaries with metadata
        """
        if not text:
            return []
        
        chunks = []
        start = 0
        chunk_id = 0
        
        # Split by paragraphs first
        paragraphs = text.split('\n\n')
        
        current_chunk = ""
        current_paragraphs = []
        
        for para_idx, paragraph in enumerate(paragraphs):
            paragraph = paragraph.strip()
            if not paragraph:
                continue
            
            # If adding this paragraph exceeds chunk size, finalize current chunk
            if current_chunk and len(current_chunk) + len(paragraph) + 2 > chunk_size:
                if current_chunk:  # Only add if we have content
                    chunks.append({
                        'chunk_id': chunk_id,
                        'text': current_chunk.strip(),
                        'start_paragraph': current_paragraphs[0] if current_paragraphs else para_idx,
                        'end_paragraph': current_paragraphs[-1] if current_paragraphs else para_idx,
                        'word_count': len(current_chunk.split()),
                        'char_count': len(current_chunk)
                    })
                    chunk_id += 1
                
                # Handle overlap by including some paragraphs from the previous chunk
                if overlap > 0 and current_paragraphs:
                    overlap_text = ""
                    overlap_paras = []
                    
                    # Work backwards to include paragraphs for overlap
                    for i in range(len(current_paragraphs) - 1, -1, -1):
                        para_text = paragraphs[current_paragraphs[i]]
                        if len(overlap_text) + len(para_text) <= overlap:
                            overlap_text = para_text + '\n\n' + overlap_text
                            overlap_paras.insert(0, current_paragraphs[i])
                        else:
                            break
                    
                    current_chunk = overlap_text.strip()
                    current_paragraphs = overlap_paras
                else:
                    current_chunk = ""
                    current_paragraphs = []
            
            # Add current paragraph
            if current_chunk:
                current_chunk += '\n\n' + paragraph
            else:
                current_chunk = paragraph
            current_paragraphs.append(para_idx)
        
        # Add the final chunk
        if current_chunk.strip():
            chunks.append({
                'chunk_id': chunk_id,
                'text': current_chunk.strip(),
                'start_paragraph': current_paragraphs[0] if current_paragraphs else len(paragraphs) - 1,
                'end_paragraph': current_paragraphs[-1] if current_paragraphs else len(paragraphs) - 1,
                'word_count': len(current_chunk.split()),
                'char_count': len(current_chunk)
            })
        
        return chunks
    
    def process_document(self, doc_id: str, file_path: str, filename: str) -> Dict[str, Any]:
        """
        Complete document processing pipeline.
        
        Args:
            doc_id: Unique document identifier
            file_path: Path to the raw document file
            filename: Original filename
            
        Returns:
            Processing results with metadata
        """
        try:
            # Extract text
            raw_text = self.extract_text_from_file(file_path)
            
            if not raw_text.strip():
                raise ValueError("Document contains no extractable text")
            
            # Clean text
            cleaned_text = self.clean_text(raw_text)
            
            # Create chunks
            chunks = self.chunk_text(cleaned_text)
            
            # Save processed document
            processed_file = self.processed_path / f"{doc_id}.txt"
            with open(processed_file, 'w', encoding='utf-8') as f:
                f.write(cleaned_text)
            
            # Save chunks as JSON
            chunks_file = self.processed_path / f"{doc_id}_chunks.json"
            with open(chunks_file, 'w', encoding='utf-8') as f:
                json.dump(chunks, f, indent=2, ensure_ascii=False)
            
            # Create metadata
            metadata = {
                'doc_id': doc_id,
                'filename': filename,
                'processed_at': datetime.utcnow().isoformat(),
                'raw_file_path': file_path,
                'processed_file_path': str(processed_file),
                'chunks_file_path': str(chunks_file),
                'statistics': {
                    'raw_text_length': len(raw_text),
                    'cleaned_text_length': len(cleaned_text),
                    'chunk_count': len(chunks),
                    'word_count': len(cleaned_text.split()),
                    'character_count': len(cleaned_text)
                },
                'file_info': {
                    'original_name': filename,
                    'file_type': self._detect_file_type(Path(file_path)),
                    'file_size': os.path.getsize(file_path)
                }
            }
            
            # Save metadata
            metadata_file = self.processed_path / f"{doc_id}_metadata.json"
            with open(metadata_file, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2, ensure_ascii=False)
            
            return metadata
            
        except Exception as e:
            raise RuntimeError(f"Document processing failed: {str(e)}")
    
    def get_document_info(self, doc_id: str) -> Optional[Dict[str, Any]]:
        """Get document information by ID."""
        metadata_file = self.processed_path / f"{doc_id}_metadata.json"
        
        if not metadata_file.exists():
            return None
        
        try:
            with open(metadata_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            current_app.logger.error(f"Failed to read document metadata: {e}")
            return None
    
    def get_document_content(self, doc_id: str) -> Optional[str]:
        """Get processed document content by ID."""
        processed_file = self.processed_path / f"{doc_id}.txt"
        
        if not processed_file.exists():
            return None
        
        try:
            with open(processed_file, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            current_app.logger.error(f"Failed to read document content: {e}")
            return None
    
    def get_document_chunks(self, doc_id: str) -> Optional[List[Dict[str, Any]]]:
        """Get document chunks by ID."""
        chunks_file = self.processed_path / f"{doc_id}_chunks.json"
        
        if not chunks_file.exists():
            return None
        
        try:
            with open(chunks_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            current_app.logger.error(f"Failed to read document chunks: {e}")
            return None
    
    def list_documents(self) -> List[Dict[str, Any]]:
        """List all processed documents."""
        documents = []
        
        for metadata_file in self.processed_path.glob("*_metadata.json"):
            try:
                with open(metadata_file, 'r', encoding='utf-8') as f:
                    metadata = json.load(f)
                    documents.append({
                        'doc_id': metadata['doc_id'],
                        'filename': metadata['filename'],
                        'processed_at': metadata['processed_at'],
                        'word_count': metadata['statistics']['word_count'],
                        'chunk_count': metadata['statistics']['chunk_count']
                    })
            except Exception as e:
                current_app.logger.warning(f"Failed to read metadata from {metadata_file}: {e}")
                continue
        
        # Sort by processed date (newest first)
        documents.sort(key=lambda x: x['processed_at'], reverse=True)
        return documents
    
    def delete_document(self, doc_id: str) -> bool:
        """Delete a document and all its associated files."""
        try:
            deleted_files = 0
            
            # List of files to delete
            files_to_delete = [
                self.processed_path / f"{doc_id}.txt",
                self.processed_path / f"{doc_id}_chunks.json",
                self.processed_path / f"{doc_id}_metadata.json"
            ]
            
            # Also find and delete the raw file
            for raw_file in self.raw_path.glob(f"{doc_id}_*"):
                files_to_delete.append(raw_file)
            
            # Delete files
            for file_path in files_to_delete:
                if file_path.exists():
                    file_path.unlink()
                    deleted_files += 1
            
            return deleted_files > 0
            
        except Exception as e:
            current_app.logger.error(f"Failed to delete document {doc_id}: {e}")
            return False