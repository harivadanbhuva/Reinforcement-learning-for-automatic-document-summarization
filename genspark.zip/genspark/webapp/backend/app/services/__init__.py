"""
Core services for the RL Document Summarization system.

This package contains all the business logic services:
- document_processor: Document parsing, cleaning, and chunking
- embedding_service: Ollama embedding generation and management
- faiss_manager: FAISS vector database operations
- rag_pipeline: Groq API RAG implementation
- agent_service: DuckDuckGo and Wikipedia search agents
- qwen_generator: Fine-tuned Qwen model inference
- dpo_trainer: Direct Preference Optimization training
- jsonl_logger: Episode and preference logging
"""