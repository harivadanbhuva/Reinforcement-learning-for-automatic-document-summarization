"""
FAISS vector database manager.

Manages FAISS index for efficient similarity search of document embeddings.
Handles index creation, updates, search operations, and persistence.
"""

import json
import pickle
import time
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple

import faiss
import numpy as np
from flask import current_app

from app.services.embedding_service import EmbeddingService


class FaissManager:
    """Manager for FAISS vector database operations."""
    
    def __init__(self):
        """Initialize the FAISS manager."""
        self.index_path = current_app.config['FAISS_INDEX_PATH']
        self.index_file = self.index_path / 'index.faiss'
        self.metadata_file = self.index_path / 'metadata.pkl'
        self.config_file = self.index_path / 'config.json'
        
        # Ensure index directory exists
        self.index_path.mkdir(parents=True, exist_ok=True)
        
        # Initialize services
        self.embedding_service = EmbeddingService()
        
        # Index configuration
        self.embedding_dim = 768  # Default Ollama embedding dimension
        self.index_type = "Flat"  # Can be "Flat", "IVF", "HNSW", etc.
        
        # In-memory storage
        self._index = None
        self._metadata = {}  # chunk_id -> metadata mapping
        self._doc_chunks = {}  # doc_id -> [chunk_ids] mapping
        
        # Load existing index
        self._load_index()
    
    def _create_new_index(self) -> faiss.Index:
        """Create a new FAISS index."""
        if self.index_type == "Flat":
            # Simple flat index for exact search (good for small datasets)
            return faiss.IndexFlatIP(self.embedding_dim)  # Inner Product (cosine similarity)
        
        elif self.index_type == "IVF":
            # Inverted File Index for faster approximate search
            nlist = 100  # Number of clusters
            quantizer = faiss.IndexFlatIP(self.embedding_dim)
            index = faiss.IndexIVFFlat(quantizer, self.embedding_dim, nlist)
            return index
        
        elif self.index_type == "HNSW":
            # Hierarchical Navigable Small World for very fast approximate search
            M = 32  # Number of connections
            index = faiss.IndexHNSWFlat(self.embedding_dim, M)
            index.hnsw.efConstruction = 40
            index.hnsw.efSearch = 16
            return index
        
        else:
            raise ValueError(f"Unsupported index type: {self.index_type}")
    
    def _load_index(self) -> None:
        """Load existing FAISS index from disk."""
        try:
            if self.index_file.exists() and self.metadata_file.exists():
                # Load FAISS index
                self._index = faiss.read_index(str(self.index_file))
                
                # Load metadata
                with open(self.metadata_file, 'rb') as f:
                    data = pickle.load(f)
                    self._metadata = data.get('metadata', {})
                    self._doc_chunks = data.get('doc_chunks', {})
                
                # Load configuration
                if self.config_file.exists():
                    with open(self.config_file, 'r') as f:
                        config = json.load(f)
                        self.embedding_dim = config.get('embedding_dim', self.embedding_dim)
                        self.index_type = config.get('index_type', self.index_type)
                
                current_app.logger.info(f"Loaded FAISS index with {self._index.ntotal} vectors")
            else:
                # Create new index
                self._index = self._create_new_index()
                self._metadata = {}
                self._doc_chunks = {}
                current_app.logger.info("Created new FAISS index")
                
        except Exception as e:
            current_app.logger.error(f"Failed to load FAISS index: {e}")
            # Create new index as fallback
            self._index = self._create_new_index()
            self._metadata = {}
            self._doc_chunks = {}
    
    def _save_index(self) -> None:
        """Save FAISS index to disk."""
        try:
            # Save FAISS index
            faiss.write_index(self._index, str(self.index_file))
            
            # Save metadata
            with open(self.metadata_file, 'wb') as f:
                pickle.dump({
                    'metadata': self._metadata,
                    'doc_chunks': self._doc_chunks,
                    'saved_at': time.time()
                }, f)
            
            # Save configuration
            config_data = {
                'embedding_dim': self.embedding_dim,
                'index_type': self.index_type,
                'total_vectors': self._index.ntotal,
                'last_updated': time.time()
            }
            
            with open(self.config_file, 'w') as f:
                json.dump(config_data, f, indent=2)
                
        except Exception as e:
            current_app.logger.error(f"Failed to save FAISS index: {e}")
            raise
    
    def add_document_chunks(self, chunks: List[Dict[str, Any]], doc_id: str) -> int:
        """
        Add document chunks to the FAISS index.
        
        Args:
            chunks: List of chunk dictionaries with embeddings
            doc_id: Document identifier
            
        Returns:
            Number of chunks successfully added
        """
        if not chunks:
            return 0
        
        try:
            embeddings = []
            chunk_metadata = []
            
            # Extract embeddings and metadata
            for chunk in chunks:
                embedding = chunk.get('embedding')
                if not embedding:
                    current_app.logger.warning(f"Chunk missing embedding: {chunk.get('chunk_id')}")
                    continue
                
                # Normalize embedding for cosine similarity
                embedding_array = np.array(embedding, dtype=np.float32)
                embedding_norm = embedding_array / np.linalg.norm(embedding_array)
                
                embeddings.append(embedding_norm)
                
                # Store metadata
                chunk_id = f"{doc_id}_{chunk['chunk_id']}"
                chunk_meta = {
                    'chunk_id': chunk_id,
                    'doc_id': doc_id,
                    'text': chunk['text'],
                    'word_count': chunk.get('word_count', 0),
                    'char_count': chunk.get('char_count', 0),
                    'start_paragraph': chunk.get('start_paragraph', 0),
                    'end_paragraph': chunk.get('end_paragraph', 0),
                    'added_at': time.time()
                }
                
                chunk_metadata.append((chunk_id, chunk_meta))
            
            if not embeddings:
                current_app.logger.warning(f"No valid embeddings found for document {doc_id}")
                return 0
            
            # Convert to numpy array
            embeddings_matrix = np.vstack(embeddings)
            
            # Add to FAISS index
            start_index = self._index.ntotal
            self._index.add(embeddings_matrix)
            
            # Update metadata
            for i, (chunk_id, chunk_meta) in enumerate(chunk_metadata):
                chunk_meta['faiss_index'] = start_index + i
                self._metadata[chunk_id] = chunk_meta
            
            # Update document-chunk mapping
            if doc_id not in self._doc_chunks:
                self._doc_chunks[doc_id] = []
            
            chunk_ids = [chunk_id for chunk_id, _ in chunk_metadata]
            self._doc_chunks[doc_id].extend(chunk_ids)
            
            # Train index if needed (for certain index types)
            if hasattr(self._index, 'is_trained') and not self._index.is_trained:
                if self._index.ntotal >= 100:  # Minimum training samples
                    self._index.train(embeddings_matrix)
                    current_app.logger.info("Trained FAISS index")
            
            # Save to disk
            self._save_index()
            
            current_app.logger.info(
                f"Added {len(embeddings)} chunks from document {doc_id} to FAISS index"
            )
            
            return len(embeddings)
            
        except Exception as e:
            current_app.logger.error(f"Failed to add document chunks to FAISS: {e}")
            raise
    
    def search(self, query: str, top_k: int = 5, doc_id: str = None, min_score: float = 0.1) -> List[Dict[str, Any]]:
        """
        Search for similar chunks using text query.
        
        Args:
            query: Search query text
            top_k: Number of top results to return
            doc_id: Optional document filter
            min_score: Minimum similarity score threshold
            
        Returns:
            List of matching chunks with scores
        """
        if not query or not query.strip():
            return []
        
        if self._index.ntotal == 0:
            current_app.logger.warning("FAISS index is empty")
            return []
        
        try:
            # Generate query embedding
            query_embedding = self.embedding_service.embed_query(query)
            
            # Normalize for cosine similarity
            query_array = np.array(query_embedding, dtype=np.float32)
            query_norm = query_array / np.linalg.norm(query_array)
            
            # Search in FAISS
            search_k = min(top_k * 2, self._index.ntotal)  # Get more results for filtering
            scores, indices = self._index.search(query_norm.reshape(1, -1), search_k)
            
            # Process results
            results = []
            
            for score, idx in zip(scores[0], indices[0]):
                if idx == -1:  # Invalid index
                    continue
                
                # Find chunk metadata by FAISS index
                chunk_meta = None
                for chunk_id, meta in self._metadata.items():
                    if meta.get('faiss_index') == idx:
                        chunk_meta = meta
                        break
                
                if not chunk_meta:
                    continue
                
                # Apply document filter
                if doc_id and chunk_meta['doc_id'] != doc_id:
                    continue
                
                # Apply score threshold
                if score < min_score:
                    continue
                
                result = {
                    'chunk_id': chunk_meta['chunk_id'],
                    'doc_id': chunk_meta['doc_id'],
                    'text': chunk_meta['text'],
                    'score': float(score),
                    'word_count': chunk_meta.get('word_count', 0),
                    'char_count': chunk_meta.get('char_count', 0),
                    'start_paragraph': chunk_meta.get('start_paragraph', 0),
                    'end_paragraph': chunk_meta.get('end_paragraph', 0)
                }
                
                results.append(result)
                
                if len(results) >= top_k:
                    break
            
            current_app.logger.info(f"FAISS search returned {len(results)} results for query: {query[:50]}...")
            return results
            
        except Exception as e:
            current_app.logger.error(f"FAISS search failed: {e}")
            return []
    
    def search_by_embedding(self, embedding: List[float], top_k: int = 5, doc_id: str = None) -> List[Dict[str, Any]]:
        """
        Search for similar chunks using embedding vector.
        
        Args:
            embedding: Query embedding vector
            top_k: Number of top results to return
            doc_id: Optional document filter
            
        Returns:
            List of matching chunks with scores
        """
        if not embedding or self._index.ntotal == 0:
            return []
        
        try:
            # Normalize embedding
            embedding_array = np.array(embedding, dtype=np.float32)
            embedding_norm = embedding_array / np.linalg.norm(embedding_array)
            
            # Search in FAISS
            scores, indices = self._index.search(embedding_norm.reshape(1, -1), top_k)
            
            # Process results (similar to search method)
            results = []
            
            for score, idx in zip(scores[0], indices[0]):
                if idx == -1:
                    continue
                
                # Find chunk metadata
                chunk_meta = None
                for chunk_id, meta in self._metadata.items():
                    if meta.get('faiss_index') == idx:
                        chunk_meta = meta
                        break
                
                if not chunk_meta:
                    continue
                
                # Apply document filter
                if doc_id and chunk_meta['doc_id'] != doc_id:
                    continue
                
                result = {
                    'chunk_id': chunk_meta['chunk_id'],
                    'doc_id': chunk_meta['doc_id'],
                    'text': chunk_meta['text'],
                    'score': float(score),
                    'word_count': chunk_meta.get('word_count', 0),
                    'char_count': chunk_meta.get('char_count', 0)
                }
                
                results.append(result)
            
            return results
            
        except Exception as e:
            current_app.logger.error(f"FAISS embedding search failed: {e}")
            return []
    
    def remove_document(self, doc_id: str) -> int:
        """
        Remove all chunks for a document from the index.
        
        Args:
            doc_id: Document identifier
            
        Returns:
            Number of chunks removed
        """
        if doc_id not in self._doc_chunks:
            return 0
        
        try:
            chunk_ids = self._doc_chunks[doc_id]
            
            # Remove metadata
            for chunk_id in chunk_ids:
                if chunk_id in self._metadata:
                    del self._metadata[chunk_id]
            
            # Remove from document mapping
            del self._doc_chunks[doc_id]
            
            # Note: FAISS doesn't support efficient removal of individual vectors
            # For now, we just remove from metadata. For a full removal, 
            # the index would need to be rebuilt.
            
            # Save updated metadata
            self._save_index()
            
            current_app.logger.info(f"Removed {len(chunk_ids)} chunks for document {doc_id}")
            return len(chunk_ids)
            
        except Exception as e:
            current_app.logger.error(f"Failed to remove document from FAISS: {e}")
            return 0
    
    def rebuild_index(self) -> bool:
        """
        Rebuild the FAISS index from scratch.
        This is needed when documents are removed or index parameters change.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            current_app.logger.info("Starting FAISS index rebuild...")
            
            # Collect all valid embeddings and metadata
            valid_chunks = []
            
            for doc_id, chunk_ids in self._doc_chunks.items():
                for chunk_id in chunk_ids:
                    if chunk_id in self._metadata:
                        valid_chunks.append((chunk_id, self._metadata[chunk_id]))
            
            if not valid_chunks:
                # Create empty index
                self._index = self._create_new_index()
                self._metadata = {}
                self._doc_chunks = {}
                self._save_index()
                return True
            
            # Create new index
            new_index = self._create_new_index()
            new_metadata = {}
            
            # Re-embed all chunks (this would be expensive in practice)
            # For now, we'll assume embeddings are stored elsewhere or can be retrieved
            
            # This is a simplified version - in practice, you'd need to:
            # 1. Re-retrieve embeddings for all valid chunks
            # 2. Add them to the new index
            # 3. Update metadata with new indices
            
            current_app.logger.warning("Index rebuild not fully implemented - requires re-embedding")
            return False
            
        except Exception as e:
            current_app.logger.error(f"Failed to rebuild FAISS index: {e}")
            return False
    
    def get_index_info(self) -> Dict[str, Any]:
        """
        Get information about the FAISS index.
        
        Returns:
            Index statistics and configuration
        """
        info = {
            'total_vectors': self._index.ntotal if self._index else 0,
            'embedding_dimension': self.embedding_dim,
            'index_type': self.index_type,
            'total_documents': len(self._doc_chunks),
            'total_chunks': len(self._metadata),
            'index_trained': getattr(self._index, 'is_trained', True) if self._index else False,
            'index_file_exists': self.index_file.exists(),
            'metadata_file_exists': self.metadata_file.exists()
        }
        
        # Add file sizes
        try:
            if self.index_file.exists():
                info['index_file_size_mb'] = self.index_file.stat().st_size / (1024 * 1024)
            
            if self.metadata_file.exists():
                info['metadata_file_size_mb'] = self.metadata_file.stat().st_size / (1024 * 1024)
        except Exception:
            pass
        
        return info