"""
Direct Preference Optimization (DPO) trainer service.

Implements DPO fine-tuning for the Qwen model based on user preferences
collected through A/B testing. Updates model parameters to align with
human feedback without requiring a separate reward model.
"""

import json
import time
import torch
import numpy as np
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime

import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from transformers import (
    AutoTokenizer,
    AutoModelForCausalLM,
    TrainingArguments,
    Trainer,
    DataCollatorForLanguageModeling
)
from flask import current_app

from app.services.jsonl_logger import JsonlLogger


class DPODataset(Dataset):
    """Dataset class for DPO training."""
    
    def __init__(self, preferences: List[Dict[str, Any]], tokenizer, max_length: int = 1024):
        """
        Initialize DPO dataset.
        
        Args:
            preferences: List of preference dictionaries
            tokenizer: Model tokenizer
            max_length: Maximum sequence length
        """
        self.preferences = preferences
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.preferences)
    
    def __getitem__(self, idx):
        """Get a preference pair sample."""
        pref = self.preferences[idx]
        
        # Extract data
        query = pref.get('query', '')
        context = pref.get('context', '')
        chosen_summary = pref.get('chosen_summary', '')
        rejected_summary = pref.get('rejected_summary', '')
        
        # Create prompts
        base_prompt = f"Context: {context}\n\nQuery: {query}\n\nSummary:"
        
        chosen_text = base_prompt + " " + chosen_summary
        rejected_text = base_prompt + " " + rejected_summary
        
        # Tokenize
        chosen_tokens = self.tokenizer(
            chosen_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        rejected_tokens = self.tokenizer(
            rejected_text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        # Calculate prompt length for masking
        prompt_tokens = self.tokenizer(
            base_prompt,
            add_special_tokens=False,
            return_tensors='pt'
        )
        prompt_length = prompt_tokens['input_ids'].shape[1]
        
        return {
            'chosen_input_ids': chosen_tokens['input_ids'].squeeze(),
            'chosen_attention_mask': chosen_tokens['attention_mask'].squeeze(),
            'rejected_input_ids': rejected_tokens['input_ids'].squeeze(),
            'rejected_attention_mask': rejected_tokens['attention_mask'].squeeze(),
            'prompt_length': prompt_length
        }


class DPOTrainer:
    """Direct Preference Optimization trainer."""
    
    def __init__(self):
        """Initialize the DPO trainer."""
        self.checkpoints_path = current_app.config['CHECKPOINTS_PATH']
        self.model_base_name = current_app.config['MODEL_BASE_NAME']
        self.logger = JsonlLogger()
        
        # Training configuration
        self.batch_size = current_app.config['BATCH_SIZE']
        self.learning_rate = current_app.config['LEARNING_RATE']
        self.dpo_beta = current_app.config['DPO_BETA']
        
        # Device setup
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        
        # Model components
        self.model = None
        self.tokenizer = None
        self.ref_model = None  # Reference model for DPO
    
    def load_model_for_training(self, model_version: str) -> bool:
        """
        Load model and reference model for DPO training.
        
        Args:
            model_version: Version of model to load
            
        Returns:
            True if loaded successfully
        """
        try:
            model_path = self.checkpoints_path / model_version
            
            if not model_path.exists():
                current_app.logger.error(f"Model version {model_version} not found")
                return False
            
            current_app.logger.info(f"Loading model {model_version} for DPO training")
            
            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(
                model_path,
                trust_remote_code=True
            )
            
            if self.tokenizer.pad_token is None:
                self.tokenizer.pad_token = self.tokenizer.eos_token
            
            # Load main model (will be updated)
            self.model = AutoModelForCausalLM.from_pretrained(
                model_path,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                device_map="auto" if self.device == "cuda" else None,
                trust_remote_code=True
            )
            
            # Load reference model (frozen copy)
            self.ref_model = AutoModelForCausalLM.from_pretrained(
                model_path,
                torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                device_map="auto" if self.device == "cuda" else None,
                trust_remote_code=True
            )
            
            # Freeze reference model
            for param in self.ref_model.parameters():
                param.requires_grad = False
            
            self.ref_model.eval()
            
            current_app.logger.info("Successfully loaded models for DPO training")
            return True
            
        except Exception as e:
            current_app.logger.error(f"Failed to load model for training: {e}")
            return False
    
    def prepare_training_data(self, min_preferences: int = 50) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
        """
        Prepare training data from collected preferences.
        
        Args:
            min_preferences: Minimum number of preferences required
            
        Returns:
            Tuple of (preferences_list, data_statistics)
        """
        try:
            # Read all preferences
            all_preferences = self.logger.read_episodes('preferences.jsonl')
            
            if len(all_preferences) < min_preferences:
                return [], {
                    'total_preferences': len(all_preferences),
                    'usable_preferences': 0,
                    'error': f'Need at least {min_preferences} preferences, found {len(all_preferences)}'
                }
            
            # Filter valid preferences
            valid_preferences = []
            
            for pref in all_preferences:
                # Check required fields
                required_fields = ['query', 'context', 'chosen_summary', 'rejected_summary']
                if all(field in pref and pref[field] for field in required_fields):
                    valid_preferences.append(pref)
            
            current_app.logger.info(f"Prepared {len(valid_preferences)} valid preferences for training")
            
            # Calculate statistics
            stats = {
                'total_preferences': len(all_preferences),
                'usable_preferences': len(valid_preferences),
                'preference_distribution': {},
                'model_versions': {},
                'avg_context_length': 0,
                'avg_summary_length': 0
            }
            
            if valid_preferences:
                # Calculate distributions
                for pref in valid_preferences:
                    user_pref = pref.get('user_preference', 'unknown')
                    stats['preference_distribution'][user_pref] = stats['preference_distribution'].get(user_pref, 0) + 1
                    
                    model_ver = pref.get('model_version', 'unknown')
                    stats['model_versions'][model_ver] = stats['model_versions'].get(model_ver, 0) + 1
                
                # Calculate averages
                total_context_len = sum(len(pref.get('context', '')) for pref in valid_preferences)
                total_summary_len = sum(
                    len(pref.get('chosen_summary', '')) + len(pref.get('rejected_summary', ''))
                    for pref in valid_preferences
                )
                
                stats['avg_context_length'] = total_context_len / len(valid_preferences)
                stats['avg_summary_length'] = total_summary_len / (len(valid_preferences) * 2)
            
            return valid_preferences, stats
            
        except Exception as e:
            current_app.logger.error(f"Failed to prepare training data: {e}")
            return [], {'error': str(e)}
    
    def compute_dpo_loss(self, model_outputs, ref_outputs, beta: float = 0.1) -> torch.Tensor:
        """
        Compute DPO loss using the Bradley-Terry model.
        
        Args:
            model_outputs: Dictionary with chosen and rejected logits from policy model
            ref_outputs: Dictionary with chosen and rejected logits from reference model  
            beta: Temperature parameter controlling strength of preference
            
        Returns:
            DPO loss tensor
        """
        # Extract logits
        policy_chosen_logits = model_outputs['chosen_logits']
        policy_rejected_logits = model_outputs['rejected_logits']
        ref_chosen_logits = ref_outputs['chosen_logits']
        ref_rejected_logits = ref_outputs['rejected_logits']
        
        # Compute log probabilities (simplified - in practice would need proper masking)
        policy_chosen_logprobs = F.log_softmax(policy_chosen_logits, dim=-1).mean()
        policy_rejected_logprobs = F.log_softmax(policy_rejected_logits, dim=-1).mean()
        ref_chosen_logprobs = F.log_softmax(ref_chosen_logits, dim=-1).mean()
        ref_rejected_logprobs = F.log_softmax(ref_rejected_logits, dim=-1).mean()
        
        # Compute DPO objective
        policy_ratio_chosen = policy_chosen_logprobs - ref_chosen_logprobs
        policy_ratio_rejected = policy_rejected_logprobs - ref_rejected_logprobs
        
        logits = beta * (policy_ratio_chosen - policy_ratio_rejected)
        
        # DPO loss (negative log-likelihood of Bradley-Terry model)
        loss = -F.logsigmoid(logits).mean()
        
        return loss
    
    def train_dpo_step(self, batch: Dict[str, torch.Tensor]) -> Dict[str, float]:
        """
        Perform one DPO training step.
        
        Args:
            batch: Batch of training data
            
        Returns:
            Loss and metrics
        """
        # Forward pass on chosen examples
        chosen_outputs = self.model(
            input_ids=batch['chosen_input_ids'],
            attention_mask=batch['chosen_attention_mask'],
            return_dict=True
        )
        
        # Forward pass on rejected examples
        rejected_outputs = self.model(
            input_ids=batch['rejected_input_ids'],
            attention_mask=batch['rejected_attention_mask'],
            return_dict=True
        )
        
        # Reference model forward pass (no grad)
        with torch.no_grad():
            ref_chosen_outputs = self.ref_model(
                input_ids=batch['chosen_input_ids'],
                attention_mask=batch['chosen_attention_mask'],
                return_dict=True
            )
            
            ref_rejected_outputs = self.ref_model(
                input_ids=batch['rejected_input_ids'],
                attention_mask=batch['rejected_attention_mask'],
                return_dict=True
            )
        
        # Prepare outputs for loss computation
        model_outputs = {
            'chosen_logits': chosen_outputs.logits,
            'rejected_logits': rejected_outputs.logits
        }
        
        ref_outputs = {
            'chosen_logits': ref_chosen_outputs.logits,
            'rejected_logits': ref_rejected_outputs.logits
        }
        
        # Compute DPO loss
        loss = self.compute_dpo_loss(model_outputs, ref_outputs, self.dpo_beta)
        
        return {
            'loss': loss.item(),
            'chosen_logprobs': F.log_softmax(chosen_outputs.logits, dim=-1).mean().item(),
            'rejected_logprobs': F.log_softmax(rejected_outputs.logits, dim=-1).mean().item()
        }
    
    def train_dpo_model(self, training_id: str, config: Dict[str, Any]) -> Dict[str, Any]:
        """
        Train the model using DPO.
        
        Args:
            training_id: Unique training identifier
            config: Training configuration
            
        Returns:
            Training results
        """
        start_time = time.time()
        
        try:
            current_app.logger.info(f"Starting DPO training {training_id}")
            
            # Prepare training data
            preferences, data_stats = self.prepare_training_data()
            
            if not preferences:
                return {
                    'status': 'failed',
                    'error': 'No valid training data',
                    'data_stats': data_stats
                }
            
            # Load model for training
            current_model_version = config.get('current_model_version', 'qwen-sft-base')
            
            if not self.load_model_for_training(current_model_version):
                return {
                    'status': 'failed',
                    'error': 'Failed to load model for training'
                }
            
            # Create dataset and dataloader
            dataset = DPODataset(preferences, self.tokenizer)
            dataloader = DataLoader(
                dataset,
                batch_size=config.get('batch_size', self.batch_size),
                shuffle=True
            )
            
            # Setup optimizer
            optimizer = torch.optim.AdamW(
                self.model.parameters(),
                lr=config.get('learning_rate', self.learning_rate)
            )
            
            # Training loop
            self.model.train()
            total_loss = 0.0
            num_batches = 0
            training_metrics = []
            
            for epoch in range(config.get('max_epochs', 1)):
                epoch_loss = 0.0
                epoch_batches = 0
                
                for batch_idx, batch in enumerate(dataloader):
                    # Move to device
                    if self.device == "cuda":
                        batch = {k: v.to(self.device) if isinstance(v, torch.Tensor) else v 
                                for k, v in batch.items()}
                    
                    # Training step
                    optimizer.zero_grad()
                    
                    step_metrics = self.train_dpo_step(batch)
                    loss = torch.tensor(step_metrics['loss'], requires_grad=True)
                    
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1.0)
                    optimizer.step()
                    
                    # Update metrics
                    epoch_loss += step_metrics['loss']
                    total_loss += step_metrics['loss']
                    epoch_batches += 1
                    num_batches += 1
                    
                    training_metrics.append({
                        'epoch': epoch,
                        'batch': batch_idx,
                        'loss': step_metrics['loss'],
                        'chosen_logprobs': step_metrics['chosen_logprobs'],
                        'rejected_logprobs': step_metrics['rejected_logprobs']
                    })
                    
                    # Log progress
                    if batch_idx % 10 == 0:
                        current_app.logger.info(
                            f"Epoch {epoch}, Batch {batch_idx}/{len(dataloader)}, "
                            f"Loss: {step_metrics['loss']:.4f}"
                        )
                
                avg_epoch_loss = epoch_loss / epoch_batches if epoch_batches > 0 else 0.0
                current_app.logger.info(f"Epoch {epoch} completed, Average Loss: {avg_epoch_loss:.4f}")
            
            # Calculate final metrics
            avg_loss = total_loss / num_batches if num_batches > 0 else 0.0
            training_duration = time.time() - start_time
            
            # Save updated model
            new_version = self._save_trained_model(current_model_version, training_id)
            
            result = {
                'status': 'completed',
                'training_id': training_id,
                'model_version_before': current_model_version,
                'model_version_after': new_version,
                'training_duration_seconds': training_duration,
                'final_loss': avg_loss,
                'total_batches': num_batches,
                'preferences_used': len(preferences),
                'training_metrics': training_metrics[-10:],  # Last 10 metrics
                'data_statistics': data_stats,
                'config_used': config
            }
            
            current_app.logger.info(f"DPO training {training_id} completed successfully")
            return result
            
        except Exception as e:
            current_app.logger.error(f"DPO training {training_id} failed: {e}")
            return {
                'status': 'failed',
                'training_id': training_id,
                'error': str(e),
                'training_duration_seconds': time.time() - start_time
            }
    
    def _save_trained_model(self, base_version: str, training_id: str) -> str:
        """
        Save the trained model as a new checkpoint.
        
        Args:
            base_version: Base model version
            training_id: Training session ID
            
        Returns:
            New model version identifier
        """
        try:
            # Generate new version name
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            new_version = f"{base_version}_dpo_{timestamp}"
            
            new_model_path = self.checkpoints_path / new_version
            new_model_path.mkdir(parents=True, exist_ok=True)
            
            # Save model and tokenizer
            self.model.save_pretrained(new_model_path)
            self.tokenizer.save_pretrained(new_model_path)
            
            # Save training metadata
            metadata = {
                'base_version': base_version,
                'training_id': training_id,
                'training_method': 'DPO',
                'trained_at': datetime.utcnow().isoformat(),
                'beta': self.dpo_beta,
                'learning_rate': self.learning_rate,
                'batch_size': self.batch_size
            }
            
            with open(new_model_path / 'training_metadata.json', 'w') as f:
                json.dump(metadata, f, indent=2)
            
            current_app.logger.info(f"Saved trained model as version: {new_version}")
            return new_version
            
        except Exception as e:
            current_app.logger.error(f"Failed to save trained model: {e}")
            return base_version  # Return original version on failure
    
    def cleanup_models(self) -> None:
        """Clean up loaded models to free memory."""
        if self.model is not None:
            del self.model
            self.model = None
        
        if self.ref_model is not None:
            del self.ref_model
            self.ref_model = None
        
        if self.tokenizer is not None:
            del self.tokenizer
            self.tokenizer = None
        
        # Clear CUDA cache
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        current_app.logger.info("Cleaned up DPO training models")