"""
Celery application configuration.

Sets up Celery for background task processing with Redis as broker.
"""

from celery import Celery
from app.config import Config

# Create Celery instance
celery_app = Celery('rl_document_summarization')

# Configure Celery
celery_app.conf.update(
    broker_url=Config.CELERY_BROKER_URL,
    result_backend=Config.CELERY_RESULT_BACKEND,
    task_serializer='json',
    accept_content=['json'],
    result_serializer='json',
    timezone='UTC',
    enable_utc=True,
    
    # Task routing
    task_routes={
        'tasks.embedding_tasks.*': {'queue': 'embedding'},
        'tasks.training_tasks.*': {'queue': 'training'},
        'tasks.maintenance_tasks.*': {'queue': 'maintenance'},
    },
    
    # Task execution
    task_always_eager=False,
    task_store_eager_result=True,
    
    # Result expiration
    result_expires=3600,  # 1 hour
    
    # Worker configuration
    worker_prefetch_multiplier=1,
    worker_max_tasks_per_child=1000,
    
    # Task time limits
    task_soft_time_limit=3600,  # 1 hour soft limit
    task_time_limit=7200,       # 2 hour hard limit
)

# Auto-discover tasks
celery_app.autodiscover_tasks([
    'tasks.embedding_tasks',
    'tasks.training_tasks', 
    'tasks.maintenance_tasks'
])