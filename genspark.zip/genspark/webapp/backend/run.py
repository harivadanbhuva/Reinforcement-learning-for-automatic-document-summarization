"""
Flask application entry point.

Starts the RL Document Summarization API server.
"""

import os
from app import create_app
from app.config import config

# Determine configuration
config_name = os.environ.get('FLASK_ENV', 'development')
app = create_app(config[config_name])

if __name__ == '__main__':
    # Ensure necessary directories exist
    app.config['ensure_directories']()
    
    # Run the application
    app.run(
        host=app.config['FLASK_HOST'],
        port=app.config['FLASK_PORT'],
        debug=app.config['FLASK_DEBUG']
    )