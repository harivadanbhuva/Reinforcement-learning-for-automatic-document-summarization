"""
Main Streamlit application for RL Document Summarization.

This is the entry point for the Streamlit frontend that provides
an interactive interface for document upload, querying, A/B testing,
and analytics for the reinforcement learning document summarization system.
"""

import streamlit as st
from config import Config

# Configure Streamlit page
st.set_page_config(
    page_title=Config.PAGE_TITLE,
    page_icon=Config.PAGE_ICON,
    layout=Config.LAYOUT,
    initial_sidebar_state="expanded"
)

# Import utilities after setting page config
from utils.session_manager import SessionManager
from utils.api_client import APIClient

def main():
    """Main application function."""
    
    # Initialize session manager
    session_manager = SessionManager()
    session_manager.initialize_session()
    
    # Initialize API client
    api_client = APIClient()
    
    # Store API client in session state
    st.session_state['api_client'] = api_client
    
    # Main header
    st.markdown("""
    # 🧠 RL Document Summarization System
    
    **Intelligent document summarization with reinforcement learning from human feedback**
    
    This system combines extractive and abstractive summarization using:
    - 🔍 **RAG Pipeline**: Groq API + FAISS for fast, accurate retrieval
    - 🤖 **Fine-tuned Qwen**: Personalized summarization via DPO training
    - 🌐 **Smart Agents**: DuckDuckGo + Wikipedia for external knowledge
    - 📊 **A/B Testing**: Continuous model improvement through user preferences
    """)
    
    # System status check
    with st.sidebar:
        st.markdown("### 🔧 System Status")
        
        with st.spinner("Checking system status..."):
            try:
                health_status = api_client.get_health_status()
                
                if health_status and health_status.get('status') == 'healthy':
                    st.success("✅ System Online")
                else:
                    st.warning("⚠️ System Issues Detected")
                    
            except Exception as e:
                st.error("❌ Cannot connect to backend")
                if Config.DEBUG_MODE:
                    st.error(f"Error: {str(e)}")
        
        # Navigation helper
        st.markdown("""
        ### 📋 Quick Start Guide
        
        1. **📄 Upload** your documents
        2. **🔍 Query** for summaries  
        3. **🎯 A/B Test** preferences
        4. **📊 Monitor** training progress
        """)
        
        # Current session info
        if st.session_state.get('current_document'):
            st.markdown("### 📄 Current Document")
            doc_info = st.session_state['current_document']
            st.info(f"**{doc_info.get('filename', 'Unknown')}**")
            st.caption(f"Processed: {doc_info.get('processed_at', 'Unknown')}")
    
    # Welcome message for new users
    if not st.session_state.get('has_uploaded_document', False):
        st.info("""
        👋 **Welcome!** To get started:
        
        1. Navigate to **📄 Upload Documents** to add your first document
        2. Use **🔍 Query & Summarize** to ask questions about your documents
        3. Try **🎯 A/B Testing** to help improve the model with your preferences
        """)
    
    # Quick stats if available
    if st.session_state.get('user_stats'):
        stats = st.session_state['user_stats']
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Documents", stats.get('documents_uploaded', 0))
        
        with col2:
            st.metric("Queries", stats.get('queries_made', 0))
        
        with col3:
            st.metric("Preferences", stats.get('preferences_given', 0))
        
        with col4:
            st.metric("Model Version", stats.get('active_model', 'Unknown'))
    
    # Feature overview
    st.markdown("---")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        ### 🚀 Key Features
        
        - **Multi-format Support**: PDF, TXT, DOCX documents
        - **Dual Summarization**: Extractive + Abstractive modes  
        - **External Knowledge**: Web search integration
        - **Preference Learning**: A/B testing for model improvement
        - **Real-time Training**: DPO fine-tuning based on feedback
        - **Analytics Dashboard**: Performance tracking and insights
        """)
    
    with col2:
        st.markdown("""
        ### 📖 How It Works
        
        1. **Document Processing**: Upload and embed documents using Ollama
        2. **RAG Summarization**: Query documents with Groq-powered retrieval
        3. **A/B Testing**: Compare extractive vs abstractive summaries
        4. **Preference Collection**: Choose your preferred summary style
        5. **Model Training**: System learns from your preferences via DPO
        6. **Continuous Improvement**: Model gets better with more feedback
        """)
    
    # Recent activity (if any)
    if st.session_state.get('recent_activity'):
        st.markdown("### 📋 Recent Activity")
        
        activity = st.session_state['recent_activity']
        
        for item in activity[-5:]:  # Show last 5 activities
            activity_time = item.get('timestamp', 'Unknown time')
            activity_type = item.get('type', 'Unknown')
            activity_desc = item.get('description', 'No description')
            
            st.caption(f"**{activity_time}** - {activity_type}: {activity_desc}")


if __name__ == "__main__":
    main()