"""
Analytics and Training Dashboard

Shows system performance, training progress, and analytics.
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
from utils.api_client import APIClient
from utils.session_manager import SessionManager

st.set_page_config(
    page_title="Analytics - RL Document Summarization",
    page_icon="📊",
    layout="wide"
)

def main():
    """Main analytics page function."""
    
    # Initialize services
    session_manager = SessionManager()
    session_manager.initialize_session()
    api_client = st.session_state.get('api_client', APIClient())
    
    st.title("📊 Analytics & Training Dashboard")
    st.markdown("Monitor system performance, model training, and user analytics.")
    
    # Tabs for different analytics sections
    tab1, tab2, tab3, tab4 = st.tabs(["📈 Overview", "🎓 Training", "🎯 Preferences", "🔧 System"])
    
    with tab1:
        show_overview_analytics(api_client, session_manager)
    
    with tab2:
        show_training_analytics(api_client, session_manager)
    
    with tab3:
        show_preference_analytics(api_client, session_manager)
    
    with tab4:
        show_system_analytics(api_client)


def show_overview_analytics(api_client: APIClient, session_manager: SessionManager):
    """Show overview analytics."""
    
    st.subheader("📈 System Overview")
    
    # Key metrics
    col1, col2, col3, col4 = st.columns(4)
    
    # Get session stats
    session_info = session_manager.get_session_info()
    
    with col1:
        st.metric(
            "Documents Processed",
            session_info.get('documents_uploaded', 0),
            help="Documents uploaded in this session"
        )
    
    with col2:
        st.metric(
            "Queries Made",
            session_info.get('queries_made', 0),
            help="Total queries processed"
        )
    
    with col3:
        st.metric(
            "Preferences Given",
            session_info.get('preferences_given', 0),
            help="A/B testing preferences submitted"
        )
    
    with col4:
        has_training = session_info.get('has_active_training', False)
        st.metric(
            "Training Status",
            "Active" if has_training else "Idle",
            help="Current model training status"
        )
    
    st.markdown("---")
    
    # Model information
    st.subheader("🤖 Current Model")
    
    with st.spinner("📡 Getting model information..."):
        model_info = api_client.get_model_info()
        
        if model_info:
            col1, col2 = st.columns(2)
            
            with col1:
                st.info(f"""
                **Model Version:** {model_info['model_info'].get('version', 'Unknown')}
                
                **Loaded At:** {model_info['model_info'].get('loaded_at', 'Unknown')}
                
                **Device:** {model_info['model_info'].get('device', 'Unknown')}
                
                **Parameters:** {model_info['model_info'].get('parameters', 0):,}
                """)
            
            with col2:
                preference_stats = model_info.get('preference_statistics', {})
                
                if preference_stats.get('total_preferences', 0) > 0:
                    # Preference distribution chart
                    fig = go.Figure(data=[
                        go.Pie(
                            labels=['Summary A (Extractive)', 'Summary B (Abstractive)'],
                            values=[preference_stats.get('preference_a', 0), 
                                   preference_stats.get('preference_b', 0)],
                            hole=0.4
                        )
                    ])
                    fig.update_layout(
                        title="Model Preference Distribution",
                        height=300
                    )
                    st.plotly_chart(fig, use_container_width=True)
                else:
                    st.info("📊 No preference data available yet.")
    
    # Performance metrics
    st.markdown("---")
    st.subheader("⚡ Performance Metrics")
    
    with st.spinner("📊 Loading performance data..."):
        metrics = api_client.get_model_metrics(days=7)
        
        if metrics and metrics.get('total_interactions', 0) > 0:
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric(
                    "7-Day Interactions",
                    metrics.get('total_interactions', 0)
                )
            
            with col2:
                st.metric(
                    "Preference Rate",
                    f"{metrics.get('preference_rate', 0):.1%}"
                )
            
            with col3:
                confidence = metrics.get('confidence_metrics', {})
                st.metric(
                    "Avg Confidence",
                    f"{confidence.get('average', 0):.2f}"
                )
        else:
            st.info("📊 Gathering performance data... Use the system to generate metrics!")


def show_training_analytics(api_client: APIClient, session_manager: SessionManager):
    """Show training analytics and controls."""
    
    st.subheader("🎓 Model Training")
    
    # Training requirements check
    with st.spinner("🔍 Checking training requirements..."):
        requirements = api_client.check_training_requirements()
        
        if requirements:
            can_train = requirements.get('can_train', False)
            
            # Requirements status
            st.markdown("### 📋 Training Requirements")
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                total_prefs = requirements.get('total_preferences', 0)
                min_total = requirements.get('requirements', {}).get('min_total_preferences', 50)
                st.metric(
                    "Total Preferences",
                    f"{total_prefs}/{min_total}",
                    delta=total_prefs - min_total if total_prefs >= min_total else None
                )
            
            with col2:
                new_prefs = requirements.get('new_preferences', 0)
                min_new = requirements.get('requirements', {}).get('min_new_preferences', 20)
                st.metric(
                    "New Preferences",
                    f"{new_prefs}/{min_new}",
                    delta=new_prefs - min_new if new_prefs >= min_new else None
                )
            
            with col3:
                st.metric(
                    "Training Ready",
                    "✅ Yes" if can_train else "❌ No"
                )
            
            # Training recommendation
            recommendation = requirements.get('recommendation', '')
            if recommendation:
                if can_train:
                    st.success(f"🎯 {recommendation}")
                else:
                    st.warning(f"⚠️ {recommendation}")
            
            # Training controls
            st.markdown("---")
            st.markdown("### 🚀 Training Controls")
            
            if can_train:
                col1, col2 = st.columns([2, 1])
                
                with col1:
                    with st.expander("⚙️ Advanced Training Settings"):
                        batch_size = st.number_input("Batch Size", min_value=8, max_value=64, value=32)
                        learning_rate = st.number_input("Learning Rate", min_value=1e-6, max_value=1e-3, value=5e-6, format="%.0e")
                        beta = st.number_input("DPO Beta", min_value=0.01, max_value=1.0, value=0.1)
                        force_training = st.checkbox("Force training (ignore requirements)", value=False)
                
                with col2:
                    st.markdown("<br><br>", unsafe_allow_html=True)
                    
                    if st.button("🎓 Start DPO Training", type="primary", use_container_width=True):
                        start_training(api_client, session_manager, {
                            'batch_size': batch_size,
                            'learning_rate': learning_rate,
                            'beta': beta,
                            'force': force_training
                        })
            else:
                st.info("🔄 Collect more preferences through A/B testing to enable training.")
                if st.button("🎯 Go to A/B Testing"):
                    st.switch_page("pages/3_🎯_AB_Testing.py")
    
    # Training history
    st.markdown("---")
    st.markdown("### 📚 Training History")
    
    with st.spinner("📖 Loading training history..."):
        history = api_client.get_training_history(limit=10)
        
        if history and history.get('training_history'):
            for i, training in enumerate(history['training_history']):
                with st.expander(f"Training Session {i+1}: {training.get('status', 'Unknown').title()}"):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.write(f"**Training ID:** {training.get('training_id', 'Unknown')}")
                        st.write(f"**Started:** {training.get('timestamp', 'Unknown')}")
                        st.write(f"**Status:** {training.get('status', 'Unknown')}")
                    
                    with col2:
                        st.write(f"**Model Before:** {training.get('model_version_before', 'Unknown')}")
                        st.write(f"**Model After:** {training.get('model_version_after', 'N/A')}")
                        
                        if training.get('training_metrics'):
                            metrics = training['training_metrics']
                            st.write(f"**Final Loss:** {metrics.get('final_loss', 'N/A')}")
        else:
            st.info("📭 No training sessions yet.")
    
    # Active training monitoring
    active_training = st.session_state.get('active_training')
    if active_training:
        st.markdown("---")
        st.markdown("### 🔄 Active Training")
        
        training_id = active_training.get('training_id')
        
        if training_id:
            # Auto-refresh training status
            if st.button("🔄 Refresh Status"):
                st.experimental_rerun()
            
            # Get training status
            status = api_client.get_training_status(training_id)
            
            if status:
                col1, col2 = st.columns(2)
                
                with col1:
                    st.write(f"**Training ID:** {training_id}")
                    st.write(f"**Status:** {status.get('status', 'Unknown')}")
                    st.write(f"**Started:** {status.get('started_at', 'Unknown')}")
                
                with col2:
                    progress = status.get('progress', {})
                    if isinstance(progress, dict) and 'progress' in progress:
                        st.progress(progress['progress'] / 100)
                        st.write(f"**Stage:** {progress.get('status', 'Unknown')}")
                
                # Training metrics
                if status.get('training_metrics'):
                    metrics = status['training_metrics']
                    st.write("**Training Metrics:**")
                    st.json(metrics)


def start_training(api_client: APIClient, session_manager: SessionManager, config: dict):
    """Start DPO training."""
    
    with st.spinner("🚀 Starting DPO training..."):
        result = api_client.trigger_dpo_training(config)
        
        if result:
            st.success("✅ Training started successfully!")
            
            # Store training info in session
            session_manager.start_training({
                'training_id': result['training_id'],
                'started_at': result.get('started_at'),
                'config': config
            })
            
            # Show training details
            st.info(f"""
            🎓 **Training Session Started**
            
            - **Training ID:** {result['training_id']}
            - **Estimated Duration:** {result.get('estimated_duration_minutes', 'Unknown')} minutes
            - **Task ID:** {result.get('task_id', 'Unknown')}
            """)
            
            st.experimental_rerun()
        else:
            st.error("❌ Failed to start training. Please try again.")


def show_preference_analytics(api_client: APIClient, session_manager: SessionManager):
    """Show preference analytics."""
    
    st.subheader("🎯 Preference Analytics")
    
    # Get preference statistics
    with st.spinner("📊 Loading preference data..."):
        pref_stats = api_client.get_preference_statistics(days=30)
        
        if pref_stats and pref_stats.get('statistics', {}).get('total_preferences', 0) > 0:
            stats = pref_stats['statistics']
            
            # Overview metrics
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                st.metric("Total Preferences", stats['total_preferences'])
            
            with col2:
                rates = stats.get('preference_rates', {})
                st.metric("Summary A Rate", f"{rates.get('A', 0):.1%}")
            
            with col3:
                st.metric("Summary B Rate", f"{rates.get('B', 0):.1%}")
            
            with col4:
                confidence = stats.get('confidence_metrics', {})
                st.metric("Avg Confidence", f"{confidence.get('average', 0):.2f}")
            
            # Preference distribution chart
            if stats.get('preference_distribution'):
                dist = stats['preference_distribution']
                
                fig = go.Figure(data=[
                    go.Bar(
                        x=['Summary A (Extractive)', 'Summary B (Abstractive)'],
                        y=[dist.get('A', 0), dist.get('B', 0)],
                        marker_color=['lightblue', 'lightgreen']
                    )
                ])
                fig.update_layout(
                    title="Preference Distribution (Last 30 Days)",
                    xaxis_title="Summary Type",
                    yaxis_title="Number of Preferences"
                )
                
                st.plotly_chart(fig, use_container_width=True)
            
            # Daily preferences chart
            if stats.get('daily_preferences'):
                daily_data = stats['daily_preferences']
                
                dates = [d['date'] for d in daily_data]
                pref_a = [d['preference_a'] for d in daily_data]
                pref_b = [d['preference_b'] for d in daily_data]
                
                fig = go.Figure()
                fig.add_trace(go.Scatter(x=dates, y=pref_a, mode='lines+markers', name='Summary A'))
                fig.add_trace(go.Scatter(x=dates, y=pref_b, mode='lines+markers', name='Summary B'))
                
                fig.update_layout(
                    title="Daily Preferences Trend",
                    xaxis_title="Date",
                    yaxis_title="Number of Preferences"
                )
                
                st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("📊 No preference data available yet. Start A/B testing to generate analytics!")


def show_system_analytics(api_client: APIClient):
    """Show system health and performance."""
    
    st.subheader("🔧 System Health")
    
    # System status
    with st.spinner("🏥 Checking system health..."):
        health = api_client.get_health_status()
        
        if health:
            if health.get('status') == 'healthy':
                st.success("✅ System is healthy and operational")
            else:
                st.warning("⚠️ System has some issues")
        else:
            st.error("❌ Cannot connect to backend system")
    
    # Model versions
    st.markdown("### 🤖 Available Model Versions")
    
    with st.spinner("📋 Loading model versions..."):
        versions = api_client.list_model_versions()
        
        if versions and versions.get('versions'):
            for version in versions['versions']:
                with st.expander(f"Model: {version['version']} {'(Active)' if version.get('is_active') else ''}"):
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        st.write(f"**Path:** {version['path']}")
                        st.write(f"**Valid:** {'✅' if version.get('valid') else '❌'}")
                    
                    with col2:
                        st.write(f"**Size:** {version.get('size_mb', 0):.1f} MB")
                        
                        if not version.get('is_active'):
                            if st.button(f"Load {version['version']}", key=f"load_{version['version']}"):
                                with st.spinner("🔄 Loading model..."):
                                    result = api_client.load_model_version(version['version'])
                                    if result:
                                        st.success(f"✅ Loaded model {version['version']}")
                                        st.experimental_rerun()
                                    else:
                                        st.error("❌ Failed to load model")
        else:
            st.info("📭 No model versions available")


if __name__ == "__main__":
    main()