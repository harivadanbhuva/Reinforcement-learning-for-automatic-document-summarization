"""
Query and Summarization Page

Allows users to query documents and get RAG-based summaries
using both extractive and abstractive approaches.
"""

import streamlit as st
from utils.api_client import APIClient
from utils.session_manager import SessionManager
from config import Config

st.set_page_config(
    page_title="Query & Summarize - RL Document Summarization",
    page_icon="🔍",
    layout="wide"
)

def main():
    """Main query page function."""
    
    # Initialize services
    session_manager = SessionManager()
    session_manager.initialize_session()
    api_client = st.session_state.get('api_client', APIClient())
    
    st.title("🔍 Query & Summarize")
    st.markdown("Ask questions about your documents and get intelligent summaries.")
    
    # Check if document is selected
    current_doc = st.session_state.get('current_document')
    
    if not current_doc:
        st.warning("📭 No document selected. Please upload and select a document first.")
        if st.button("📄 Go to Upload Page"):
            st.switch_page("pages/1_📄_Upload_Documents.py")
        return
    
    # Current document info
    with st.container():
        st.info(f"📄 **Current Document:** {current_doc['filename']}")
    
    # Query input section
    st.subheader("💭 Ask a Question")
    
    col1, col2 = st.columns([4, 1])
    
    with col1:
        query = st.text_area(
            "Enter your question:",
            placeholder="What are the main benefits of renewable energy?",
            height=100
        )
    
    with col2:
        st.markdown("<br>", unsafe_allow_html=True)  # Spacing
        
        summarization_mode = st.selectbox(
            "Mode:",
            ["extractive", "abstractive"],
            help="Extractive: Selects key sentences. Abstractive: Generates new text with external knowledge."
        )
        
        generate_button = st.button("🎯 Generate Summary", disabled=not query.strip())
    
    # Generate summary
    if generate_button and query.strip():
        doc_id = current_doc.get('doc_id')
        
        with st.spinner(f"🔄 Generating {summarization_mode} summary..."):
            # Generate RAG summary
            summary_result = api_client.generate_rag_summary(
                query=query,
                doc_id=doc_id,
                mode=summarization_mode
            )
            
            if summary_result:
                session_manager.add_query(query, summary_result)
                
                # Display summary
                st.subheader(f"📝 {summarization_mode.title()} Summary")
                
                # Summary content
                summary_text = summary_result.get('summary', '')
                st.markdown(f"**Answer:** {summary_text}")
                
                # Metadata
                with st.expander("📊 Summary Details"):
                    metadata = summary_result.get('metadata', {})
                    
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.metric("Summary Length", len(summary_text))
                        st.metric("Context Length", metadata.get('context_length', 0))
                    
                    with col2:
                        generation_time = metadata.get('generation_time_ms', 0)
                        st.metric("Generation Time", f"{generation_time:.0f}ms")
                        st.metric("Query Length", len(query))
                    
                    with col3:
                        if 'sources' in summary_result:
                            sources = summary_result['sources']
                            st.metric("Documents Used", len(sources.get('embedded_docs', [])))
                            st.metric("Chunks Used", sources.get('chunks_used', 0))
                
                # Sources information
                if 'sources' in summary_result:
                    sources = summary_result['sources']
                    
                    with st.expander("🔗 Sources"):
                        if sources.get('embedded_docs'):
                            st.write("**Embedded Documents:**")
                            for doc in sources['embedded_docs']:
                                st.write(f"- {doc}")
                        
                        if sources.get('duckduckgo'):
                            st.write("**Web Search Results:**")
                            for result in sources['duckduckgo'][:3]:
                                st.write(f"- [{result.get('title', 'Unknown')}]({result.get('url', '#')})")
                        
                        if sources.get('wikipedia'):
                            st.write("**Wikipedia Articles:**")
                            for result in sources['wikipedia'][:3]:
                                st.write(f"- [{result.get('title', 'Unknown')}]({result.get('url', '#')})")
                
                # Action buttons
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    if st.button("🎯 Try A/B Testing"):
                        # Store for A/B testing
                        st.session_state['pending_ab_test'] = {
                            'query': query,
                            'context': summary_result.get('context', ''),
                            'doc_id': doc_id
                        }
                        st.switch_page("pages/3_🎯_AB_Testing.py")
                
                with col2:
                    other_mode = "abstractive" if summarization_mode == "extractive" else "extractive"
                    if st.button(f"🔄 Try {other_mode.title()}"):
                        st.experimental_set_query_params(mode=other_mode, query=query)
                        st.experimental_rerun()
                
                with col3:
                    if st.button("💾 Save to History"):
                        st.success("✅ Saved to query history!")
            
            else:
                st.error("❌ Failed to generate summary. Please try again.")
    
    # Quick query suggestions
    st.markdown("---")
    st.subheader("💡 Quick Query Suggestions")
    
    suggestions = [
        "What are the main points discussed?",
        "Summarize the key findings",
        "What are the conclusions?",
        "List the important recommendations",
        "What evidence is provided?"
    ]
    
    cols = st.columns(len(suggestions))
    
    for i, suggestion in enumerate(suggestions):
        with cols[i]:
            if st.button(suggestion, key=f"suggest_{i}"):
                st.experimental_set_query_params(query=suggestion)
                st.experimental_rerun()
    
    # Query history
    st.markdown("---")
    st.subheader("📚 Query History")
    
    query_history = st.session_state.get('query_history', [])
    
    if query_history:
        # Show recent queries
        for i, entry in enumerate(reversed(query_history[-10:])):  # Last 10 queries
            with st.expander(f"🕒 {entry['query'][:50]}{'...' if len(entry['query']) > 50 else ''}"):
                st.write(f"**Query:** {entry['query']}")
                
                if entry.get('summary_data'):
                    summary_data = entry['summary_data']
                    st.write(f"**Summary:** {summary_data.get('summary', 'No summary available')}")
                    st.caption(f"Mode: {summary_data.get('mode', 'Unknown')} | Time: {entry.get('timestamp', 'Unknown')}")
                
                if st.button("🔄 Repeat Query", key=f"repeat_{i}"):
                    st.experimental_set_query_params(query=entry['query'])
                    st.experimental_rerun()
    else:
        st.info("📭 No queries yet. Ask your first question above!")
    
    # Document search
    st.markdown("---")
    st.subheader("🔎 Document Search")
    
    search_query = st.text_input("Search across all documents:", placeholder="Enter search terms...")
    
    if search_query:
        with st.spinner("🔍 Searching documents..."):
            search_results = api_client.search_documents(search_query, top_k=10)
            
            if search_results and search_results.get('results'):
                st.write(f"Found {len(search_results['results'])} relevant chunks:")
                
                for i, result in enumerate(search_results['results'][:5]):  # Show top 5
                    with st.container():
                        st.write(f"**{i+1}. Score: {result.get('score', 0):.3f}**")
                        st.write(result.get('text', '')[:200] + '...')
                        st.caption(f"Document: {result.get('doc_id', 'Unknown')} | Words: {result.get('word_count', 0)}")
                        st.divider()
            else:
                st.info("🔍 No relevant content found.")


if __name__ == "__main__":
    main()