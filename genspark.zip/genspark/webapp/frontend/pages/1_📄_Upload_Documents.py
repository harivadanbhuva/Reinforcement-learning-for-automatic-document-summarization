"""
Document Upload Page

Allows users to upload documents (PDF, TXT, DOCX) for processing and embedding.
"""

import streamlit as st
from utils.api_client import APIClient
from utils.session_manager import SessionManager
from config import Config

st.set_page_config(
    page_title="Upload Documents - RL Document Summarization",
    page_icon="📄",
    layout="wide"
)

def main():
    """Main upload page function."""
    
    # Initialize services
    session_manager = SessionManager()
    session_manager.initialize_session()
    api_client = st.session_state.get('api_client', APIClient())
    
    st.title("📄 Document Upload")
    st.markdown("Upload your documents to start using the RL Document Summarization system.")
    
    # File upload section
    with st.container():
        st.subheader("📎 Upload New Document")
        
        uploaded_file = st.file_uploader(
            "Choose a file",
            type=Config.ALLOWED_FILE_TYPES,
            help=f"Supported formats: {', '.join(Config.ALLOWED_FILE_TYPES).upper()}"
        )
        
        col1, col2 = st.columns([3, 1])
        
        with col1:
            if uploaded_file is not None:
                st.info(f"📁 **{uploaded_file.name}** ({uploaded_file.size / 1024:.1f} KB)")
        
        with col2:
            upload_button = st.button("🚀 Upload & Process", disabled=uploaded_file is None)
        
        if upload_button and uploaded_file is not None:
            # Validate file size
            if uploaded_file.size > Config.MAX_UPLOAD_SIZE_MB * 1024 * 1024:
                st.error(f"File too large! Maximum size: {Config.MAX_UPLOAD_SIZE_MB}MB")
                return
            
            with st.spinner("🔄 Uploading and processing document..."):
                # Upload document
                upload_result = api_client.upload_document(uploaded_file)
                
                if upload_result:
                    st.success("✅ Document uploaded successfully!")
                    
                    # Add to session
                    session_manager.add_uploaded_document({
                        'doc_id': upload_result['doc_id'],
                        'filename': upload_result['filename'],
                        'task_id': upload_result.get('task_id'),
                        'status': upload_result.get('status', 'processing')
                    })
                    
                    # Show processing status
                    st.info("⏳ Document is being processed in the background. You can start querying once processing is complete.")
                    
                    # Display upload details
                    with st.expander("📋 Upload Details"):
                        st.write(f"**Document ID:** {upload_result['doc_id']}")
                        st.write(f"**Filename:** {upload_result['filename']}")
                        st.write(f"**Status:** {upload_result.get('status', 'processing')}")
                        if upload_result.get('task_id'):
                            st.write(f"**Task ID:** {upload_result['task_id']}")
                else:
                    st.error("❌ Upload failed. Please try again.")
    
    st.markdown("---")
    
    # Document library
    st.subheader("📚 Document Library")
    
    # Refresh button
    if st.button("🔄 Refresh List"):
        st.experimental_rerun()
    
    # Get document list
    docs_response = api_client.list_documents()
    
    if docs_response and docs_response.get('documents'):
        documents = docs_response['documents']
        
        st.write(f"**{len(documents)} document(s) in library**")
        
        for doc in documents:
            with st.container():
                col1, col2, col3, col4 = st.columns([3, 2, 2, 1])
                
                with col1:
                    st.write(f"📄 **{doc['filename']}**")
                    st.caption(f"ID: {doc['doc_id']}")
                
                with col2:
                    st.write(f"📊 {doc.get('word_count', 0):,} words")
                    st.caption(f"{doc.get('chunk_count', 0)} chunks")
                
                with col3:
                    processed_at = doc.get('processed_at', 'Unknown')
                    if processed_at != 'Unknown':
                        try:
                            from datetime import datetime
                            dt = datetime.fromisoformat(processed_at.replace('Z', '+00:00'))
                            processed_at = dt.strftime('%Y-%m-%d %H:%M')
                        except:
                            pass
                    st.write(f"🕒 {processed_at}")
                
                with col4:
                    if st.button("📖", key=f"select_{doc['doc_id']}", help="Select this document"):
                        session_manager.set_current_document(doc)
                        st.success(f"Selected: {doc['filename']}")
                        st.experimental_rerun()
                
                st.divider()
        
    else:
        st.info("📭 No documents uploaded yet. Upload your first document above!")
    
    # Current document info
    if st.session_state.get('current_document'):
        st.markdown("---")
        st.subheader("📋 Current Document")
        
        current_doc = st.session_state['current_document']
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.info(f"""
            **📄 {current_doc['filename']}**
            
            - **Document ID:** {current_doc['doc_id']}
            - **Word Count:** {current_doc.get('word_count', 'Unknown')}
            - **Chunks:** {current_doc.get('chunk_count', 'Unknown')}
            """)
        
        with col2:
            if st.button("🔍 Start Querying"):
                st.switch_page("pages/2_🔍_Query_Summarize.py")
            
            if st.button("❌ Clear Selection"):
                st.session_state['current_document'] = None
                st.experimental_rerun()


if __name__ == "__main__":
    main()