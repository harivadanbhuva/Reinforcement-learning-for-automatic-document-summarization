"""
A/B Testing Page

Allows users to compare extractive vs abstractive summaries
and provide preferences for model training.
"""

import streamlit as st
from utils.api_client import APIClient
from utils.session_manager import SessionManager

st.set_page_config(
    page_title="A/B Testing - RL Document Summarization",
    page_icon="🎯",
    layout="wide"
)

def main():
    """Main A/B testing page function."""
    
    # Initialize services
    session_manager = SessionManager()
    session_manager.initialize_session()
    api_client = st.session_state.get('api_client', APIClient())
    
    st.title("🎯 A/B Testing: Choose Your Preferred Summary")
    st.markdown("Help improve the AI model by comparing different summary styles and choosing your preference.")
    
    # Check for pending A/B test or current episode
    pending_test = st.session_state.get('pending_ab_test')
    current_episode = st.session_state.get('ab_testing_episode')
    
    if not pending_test and not current_episode:
        st.warning("📭 No A/B test session available.")
        st.markdown("To start A/B testing:")
        st.markdown("1. Go to **Query & Summarize** page")
        st.markdown("2. Generate a summary") 
        st.markdown("3. Click **Try A/B Testing**")
        
        if st.button("🔍 Go to Query Page"):
            st.switch_page("pages/2_🔍_Query_Summarize.py")
        return
    
    # Start new A/B test if pending
    if pending_test and not current_episode:
        st.info("🎯 Starting A/B testing session...")
        
        with st.spinner("🔄 Generating dual summaries with fine-tuned model..."):
            # Generate dual summaries using Qwen
            ab_result = api_client.generate_qwen_summaries(
                query=pending_test['query'],
                context=pending_test.get('context', ''),
                doc_id=pending_test.get('doc_id')
            )
            
            if ab_result:
                # Store episode data
                episode_data = {
                    'episode_id': ab_result['episode_id'],
                    'query': pending_test['query'],
                    'summary_a': ab_result['summary_a'],
                    'summary_b': ab_result['summary_b'],
                    'model_version': ab_result.get('model_version', 'unknown'),
                    'metadata': ab_result.get('metadata', {})
                }
                
                session_manager.set_ab_testing_episode(episode_data)
                
                # Clear pending test
                if 'pending_ab_test' in st.session_state:
                    del st.session_state['pending_ab_test']
                
                st.success("✅ Dual summaries generated! Choose your preference below.")
                st.experimental_rerun()
            else:
                st.error("❌ Failed to generate dual summaries. Please try again.")
                return
    
    # Display A/B test if episode exists
    if st.session_state.get('ab_testing_episode'):
        episode = st.session_state['ab_testing_episode']
        
        # Query information
        st.subheader("❓ Original Query")
        st.info(f"**Query:** {episode['query']}")
        
        st.markdown("---")
        st.subheader("📊 Compare Summaries")
        st.markdown("**Instructions:** Read both summaries and choose the one you prefer. Your choice helps train the AI model.")
        
        # Display summaries side by side
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("### 📋 Summary A (Extractive Style)")
            st.markdown("*Focuses on selecting key sentences from the original text*")
            
            summary_a_container = st.container()
            with summary_a_container:
                st.markdown(f"""
                <div style="padding: 20px; border: 2px solid #e0e0e0; border-radius: 10px; background-color: #f9f9f9;">
                {episode['summary_a']}
                </div>
                """, unsafe_allow_html=True)
            
            # Summary A metrics
            with st.expander("📊 Summary A Details"):
                metadata = episode.get('metadata', {})
                st.write(f"**Length:** {len(episode['summary_a'])} characters")
                st.write(f"**Words:** {len(episode['summary_a'].split())} words")
                st.write(f"**Tokens:** {metadata.get('tokens_a', 0)}")
        
        with col2:
            st.markdown("### 📝 Summary B (Abstractive Style)")
            st.markdown("*Creates new text by understanding and rephrasing the content*")
            
            summary_b_container = st.container()
            with summary_b_container:
                st.markdown(f"""
                <div style="padding: 20px; border: 2px solid #e0e0e0; border-radius: 10px; background-color: #f0f8ff;">
                {episode['summary_b']}
                </div>
                """, unsafe_allow_html=True)
            
            # Summary B metrics
            with st.expander("📊 Summary B Details"):
                metadata = episode.get('metadata', {})
                st.write(f"**Length:** {len(episode['summary_b'])} characters")
                st.write(f"**Words:** {len(episode['summary_b'].split())} words")
                st.write(f"**Tokens:** {metadata.get('tokens_b', 0)}")
        
        st.markdown("---")
        
        # Preference selection
        st.subheader("🗳️ Make Your Choice")
        
        col1, col2, col3 = st.columns([2, 1, 2])
        
        with col1:
            if st.button("👍 I Prefer Summary A", key="choose_a", use_container_width=True):
                submit_preference("A", episode, session_manager, api_client)
        
        with col2:
            st.markdown("<div style='text-align: center; margin-top: 10px;'>OR</div>", unsafe_allow_html=True)
        
        with col3:
            if st.button("👍 I Prefer Summary B", key="choose_b", use_container_width=True):
                submit_preference("B", episode, session_manager, api_client)
        
        # Optional feedback
        st.markdown("### 💬 Optional Feedback")
        reasoning = st.text_area(
            "Why did you prefer this summary? (Optional)",
            placeholder="e.g., More comprehensive, better structure, clearer language...",
            height=100
        )
        
        confidence = st.slider(
            "How confident are you in your choice?",
            min_value=0.1,
            max_value=1.0,
            value=1.0,
            step=0.1,
            help="1.0 = Very confident, 0.1 = Not very confident"
        )
        
        # Store reasoning and confidence for preference submission
        st.session_state['preference_reasoning'] = reasoning
        st.session_state['preference_confidence'] = confidence
        
        # Episode metadata
        with st.expander("🔍 Episode Information"):
            st.write(f"**Episode ID:** {episode['episode_id']}")
            st.write(f"**Model Version:** {episode.get('model_version', 'Unknown')}")
            
            metadata = episode.get('metadata', {})
            if metadata:
                st.write(f"**Generation Time:** {metadata.get('generation_time_ms', 0):.0f}ms")
                st.write(f"**Total Tokens:** {metadata.get('tokens_a', 0) + metadata.get('tokens_b', 0)}")
        
        # Clear session button
        if st.button("🔄 Start New A/B Test"):
            session_manager.clear_ab_testing_episode()
            if 'preference_reasoning' in st.session_state:
                del st.session_state['preference_reasoning']
            if 'preference_confidence' in st.session_state:
                del st.session_state['preference_confidence']
            st.experimental_rerun()
    
    # Show preference statistics
    st.markdown("---")
    st.subheader("📈 Your Preference History")
    
    preference_stats = session_manager.get_preference_stats()
    
    if preference_stats['total'] > 0:
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.metric("Total Preferences", preference_stats['total'])
        
        with col2:
            st.metric("Summary A Chosen", f"{preference_stats['A']} ({preference_stats['rate_A']:.1%})")
        
        with col3:
            st.metric("Summary B Chosen", f"{preference_stats['B']} ({preference_stats['rate_B']:.1%})")
        
        # Preference chart
        if preference_stats['total'] >= 2:
            import plotly.graph_objects as go
            
            fig = go.Figure(data=[
                go.Bar(x=['Summary A (Extractive)', 'Summary B (Abstractive)'], 
                       y=[preference_stats['A'], preference_stats['B']],
                       marker_color=['lightblue', 'lightgreen'])
            ])
            fig.update_layout(
                title="Your Preference Distribution",
                xaxis_title="Summary Type",
                yaxis_title="Number of Times Chosen",
                height=400
            )
            
            st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("📊 No preferences recorded yet. Make your first choice above!")


def submit_preference(choice: str, episode: dict, session_manager: SessionManager, api_client: APIClient):
    """Submit user preference to the backend."""
    
    reasoning = st.session_state.get('preference_reasoning', '')
    confidence = st.session_state.get('preference_confidence', 1.0)
    
    with st.spinner(f"📤 Submitting preference: Summary {choice}..."):
        # Submit to API
        result = api_client.submit_preference(
            episode_id=episode['episode_id'],
            preference=choice,
            reasoning=reasoning,
            confidence=confidence
        )
        
        if result:
            st.success(f"✅ Thank you! You chose Summary {choice}")
            st.balloons()
            
            # Add to session
            session_manager.add_preference(
                episode_id=episode['episode_id'],
                preference=choice,
                reasoning=reasoning
            )
            
            # Clear current episode
            session_manager.clear_ab_testing_episode()
            
            # Show impact message
            st.info("""
            🎯 **Your feedback has been recorded!**
            
            Your preference will help improve the AI model through reinforcement learning.
            The system uses Direct Preference Optimization (DPO) to align the model with human preferences.
            """)
            
            # Check training eligibility
            with st.spinner("🔍 Checking training requirements..."):
                requirements = api_client.check_training_requirements()
                
                if requirements and requirements.get('can_train'):
                    st.success("🚀 Enough preferences collected! The model can be trained with your feedback.")
                    
                    if st.button("🎓 Start Training Now"):
                        st.switch_page("pages/4_📊_Analytics.py")
                else:
                    if requirements:
                        needed = requirements.get('requirements', {}).get('min_new_preferences', 20) - requirements.get('new_preferences', 0)
                        st.info(f"📈 {needed} more preferences needed before model training.")
        else:
            st.error("❌ Failed to submit preference. Please try again.")


if __name__ == "__main__":
    main()