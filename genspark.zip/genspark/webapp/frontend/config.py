"""
Streamlit frontend configuration.
"""

import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    """Frontend configuration class."""
    
    # API Configuration
    API_BASE_URL = os.environ.get('FLASK_API_URL', 'http://localhost:5000')
    API_TIMEOUT = int(os.environ.get('API_TIMEOUT', 30))
    
    # Streamlit Configuration
    STREAMLIT_PORT = int(os.environ.get('STREAMLIT_PORT', 8501))
    
    # UI Configuration
    PAGE_TITLE = "RL Document Summarization"
    PAGE_ICON = "📄"
    LAYOUT = "wide"
    
    # File Upload Configuration
    MAX_UPLOAD_SIZE_MB = int(os.environ.get('MAX_DOCUMENT_SIZE_MB', 50))
    ALLOWED_FILE_TYPES = ['pdf', 'txt', 'docx', 'doc']
    
    # Display Configuration
    MAX_SUMMARY_DISPLAY_LENGTH = 2000
    ITEMS_PER_PAGE = 20
    
    # Session Configuration
    SESSION_TIMEOUT_MINUTES = 30
    
    # Development
    DEBUG_MODE = os.environ.get('DEV_MODE', 'false').lower() == 'true'