"""
Frontend utility modules.

This package contains utility functions for the Streamlit frontend:
- api_client: HTTP client for backend API communication
- session_manager: Streamlit session state management
- formatters: Text and data formatting utilities
"""