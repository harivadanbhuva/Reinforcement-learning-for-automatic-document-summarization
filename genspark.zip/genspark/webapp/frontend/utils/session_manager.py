"""
Session state management for Streamlit.

Handles user session initialization, state persistence,
and session-specific data management.
"""

import streamlit as st
import uuid
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional


class SessionManager:
    """Manages Streamlit session state and user data."""
    
    def __init__(self):
        """Initialize the session manager."""
        self.session_timeout = timedelta(minutes=30)
    
    def initialize_session(self) -> None:
        """Initialize session state with default values."""
        
        # Generate unique session ID if not exists
        if 'session_id' not in st.session_state:
            st.session_state['session_id'] = str(uuid.uuid4())
        
        # Session metadata
        if 'session_created' not in st.session_state:
            st.session_state['session_created'] = datetime.now()
        
        if 'last_activity' not in st.session_state:
            st.session_state['last_activity'] = datetime.now()
        
        # User state
        if 'user_stats' not in st.session_state:
            st.session_state['user_stats'] = {
                'documents_uploaded': 0,
                'queries_made': 0,
                'preferences_given': 0,
                'sessions_count': 1,
                'active_model': 'Unknown'
            }
        
        # Document state
        if 'uploaded_documents' not in st.session_state:
            st.session_state['uploaded_documents'] = []
        
        if 'current_document' not in st.session_state:
            st.session_state['current_document'] = None
        
        if 'has_uploaded_document' not in st.session_state:
            st.session_state['has_uploaded_document'] = False
        
        # Query and summary state
        if 'query_history' not in st.session_state:
            st.session_state['query_history'] = []
        
        if 'current_summaries' not in st.session_state:
            st.session_state['current_summaries'] = None
        
        if 'ab_testing_episode' not in st.session_state:
            st.session_state['ab_testing_episode'] = None
        
        # Preference state
        if 'preference_history' not in st.session_state:
            st.session_state['preference_history'] = []
        
        # Training state
        if 'active_training' not in st.session_state:
            st.session_state['active_training'] = None
        
        if 'training_history' not in st.session_state:
            st.session_state['training_history'] = []
        
        # UI state
        if 'selected_page' not in st.session_state:
            st.session_state['selected_page'] = 'Upload Documents'
        
        if 'show_advanced_options' not in st.session_state:
            st.session_state['show_advanced_options'] = False
        
        # Notifications
        if 'notifications' not in st.session_state:
            st.session_state['notifications'] = []
        
        # Recent activity
        if 'recent_activity' not in st.session_state:
            st.session_state['recent_activity'] = []
        
        # Update last activity
        self.update_activity()
    
    def update_activity(self) -> None:
        """Update last activity timestamp."""
        st.session_state['last_activity'] = datetime.now()
    
    def is_session_expired(self) -> bool:
        """Check if session has expired."""
        if 'last_activity' not in st.session_state:
            return True
        
        return datetime.now() - st.session_state['last_activity'] > self.session_timeout
    
    def add_uploaded_document(self, doc_info: Dict[str, Any]) -> None:
        """
        Add uploaded document to session state.
        
        Args:
            doc_info: Document information dictionary
        """
        if doc_info not in st.session_state['uploaded_documents']:
            st.session_state['uploaded_documents'].append(doc_info)
        
        st.session_state['current_document'] = doc_info
        st.session_state['has_uploaded_document'] = True
        st.session_state['user_stats']['documents_uploaded'] += 1
        
        # Add to activity
        self.add_activity('document_upload', f"Uploaded: {doc_info.get('filename', 'Unknown')}")
    
    def add_query(self, query: str, summary_data: Dict[str, Any] = None) -> None:
        """
        Add query to history.
        
        Args:
            query: User query string
            summary_data: Summary response data
        """
        query_entry = {
            'query': query,
            'timestamp': datetime.now().isoformat(),
            'doc_id': st.session_state.get('current_document', {}).get('doc_id'),
            'summary_data': summary_data
        }
        
        st.session_state['query_history'].append(query_entry)
        st.session_state['user_stats']['queries_made'] += 1
        
        if summary_data:
            st.session_state['current_summaries'] = summary_data
        
        # Add to activity
        self.add_activity('query', f"Asked: {query[:50]}{'...' if len(query) > 50 else ''}")
    
    def add_preference(self, episode_id: str, preference: str, reasoning: str = None) -> None:
        """
        Add user preference to history.
        
        Args:
            episode_id: Episode identifier
            preference: User preference (A or B)
            reasoning: Optional reasoning
        """
        preference_entry = {
            'episode_id': episode_id,
            'preference': preference,
            'reasoning': reasoning,
            'timestamp': datetime.now().isoformat()
        }
        
        st.session_state['preference_history'].append(preference_entry)
        st.session_state['user_stats']['preferences_given'] += 1
        
        # Add to activity
        self.add_activity('preference', f"Chose summary {preference}")
    
    def set_ab_testing_episode(self, episode_data: Dict[str, Any]) -> None:
        """
        Set current A/B testing episode.
        
        Args:
            episode_data: Episode information
        """
        st.session_state['ab_testing_episode'] = episode_data
    
    def clear_ab_testing_episode(self) -> None:
        """Clear current A/B testing episode."""
        st.session_state['ab_testing_episode'] = None
    
    def start_training(self, training_info: Dict[str, Any]) -> None:
        """
        Mark training as started.
        
        Args:
            training_info: Training session information
        """
        st.session_state['active_training'] = training_info
        
        # Add to activity
        self.add_activity('training_start', f"Started DPO training: {training_info.get('training_id', 'Unknown')}")
    
    def complete_training(self, training_result: Dict[str, Any]) -> None:
        """
        Mark training as completed.
        
        Args:
            training_result: Training completion result
        """
        if st.session_state.get('active_training'):
            st.session_state['training_history'].append({
                'started': st.session_state['active_training'],
                'completed': training_result,
                'timestamp': datetime.now().isoformat()
            })
        
        st.session_state['active_training'] = None
        
        # Update active model if provided
        if 'model_version_after' in training_result:
            st.session_state['user_stats']['active_model'] = training_result['model_version_after']
        
        # Add to activity
        status = training_result.get('status', 'unknown')
        self.add_activity('training_complete', f"Training {status}")
    
    def add_activity(self, activity_type: str, description: str) -> None:
        """
        Add activity to recent activity log.
        
        Args:
            activity_type: Type of activity
            description: Activity description
        """
        activity = {
            'type': activity_type,
            'description': description,
            'timestamp': datetime.now().strftime('%H:%M:%S')
        }
        
        st.session_state['recent_activity'].append(activity)
        
        # Keep only last 20 activities
        if len(st.session_state['recent_activity']) > 20:
            st.session_state['recent_activity'] = st.session_state['recent_activity'][-20:]
    
    def add_notification(self, message: str, notification_type: str = 'info') -> None:
        """
        Add notification to display queue.
        
        Args:
            message: Notification message
            notification_type: Type ('info', 'success', 'warning', 'error')
        """
        notification = {
            'message': message,
            'type': notification_type,
            'timestamp': datetime.now(),
            'id': str(uuid.uuid4())
        }
        
        st.session_state['notifications'].append(notification)
    
    def get_notifications(self, clear: bool = True) -> List[Dict[str, Any]]:
        """
        Get pending notifications.
        
        Args:
            clear: Whether to clear notifications after retrieving
        
        Returns:
            List of notifications
        """
        notifications = st.session_state.get('notifications', [])
        
        if clear:
            st.session_state['notifications'] = []
        
        return notifications
    
    def get_session_info(self) -> Dict[str, Any]:
        """Get session information summary."""
        return {
            'session_id': st.session_state.get('session_id'),
            'created': st.session_state.get('session_created'),
            'last_activity': st.session_state.get('last_activity'),
            'documents_uploaded': len(st.session_state.get('uploaded_documents', [])),
            'queries_made': len(st.session_state.get('query_history', [])),
            'preferences_given': len(st.session_state.get('preference_history', [])),
            'has_current_document': st.session_state.get('current_document') is not None,
            'has_active_training': st.session_state.get('active_training') is not None
        }
    
    def clear_session_data(self) -> None:
        """Clear all session data (logout)."""
        keys_to_keep = ['session_id']  # Keep session ID
        
        for key in list(st.session_state.keys()):
            if key not in keys_to_keep:
                del st.session_state[key]
        
        # Reinitialize
        self.initialize_session()
    
    def export_session_data(self) -> Dict[str, Any]:
        """Export session data for analysis or backup."""
        return {
            'session_info': self.get_session_info(),
            'user_stats': st.session_state.get('user_stats', {}),
            'query_history': st.session_state.get('query_history', []),
            'preference_history': st.session_state.get('preference_history', []),
            'training_history': st.session_state.get('training_history', []),
            'recent_activity': st.session_state.get('recent_activity', [])
        }
    
    def get_current_document_id(self) -> Optional[str]:
        """Get current document ID if available."""
        current_doc = st.session_state.get('current_document')
        return current_doc.get('doc_id') if current_doc else None
    
    def set_current_document(self, doc_info: Dict[str, Any]) -> None:
        """Set current active document."""
        st.session_state['current_document'] = doc_info
    
    def get_preference_stats(self) -> Dict[str, Any]:
        """Get user preference statistics."""
        preferences = st.session_state.get('preference_history', [])
        
        if not preferences:
            return {'total': 0, 'A': 0, 'B': 0, 'rate_A': 0, 'rate_B': 0}
        
        total = len(preferences)
        count_A = len([p for p in preferences if p.get('preference') == 'A'])
        count_B = len([p for p in preferences if p.get('preference') == 'B'])
        
        return {
            'total': total,
            'A': count_A,
            'B': count_B,
            'rate_A': count_A / total if total > 0 else 0,
            'rate_B': count_B / total if total > 0 else 0
        }