"""
API client for communication with the Flask backend.

Handles all HTTP requests to the RL Document Summarization API
with proper error handling, timeouts, and response formatting.
"""

import requests
import streamlit as st
from typing import Dict, Any, Optional, List
from config import Config


class APIClient:
    """Client for interacting with the backend API."""
    
    def __init__(self):
        """Initialize the API client."""
        self.base_url = Config.API_BASE_URL
        self.timeout = Config.API_TIMEOUT
        self.session = requests.Session()
        
        # Set default headers
        self.session.headers.update({
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        })
    
    def _make_request(self, method: str, endpoint: str, **kwargs) -> Optional[Dict[str, Any]]:
        """
        Make HTTP request to the API.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            endpoint: API endpoint path
            **kwargs: Additional request arguments
        
        Returns:
            Response data or None if error
        """
        url = f"{self.base_url}{endpoint}"
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                timeout=self.timeout,
                **kwargs
            )
            
            # Handle different response codes
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 404:
                st.error(f"Resource not found: {endpoint}")
                return None
            elif response.status_code >= 500:
                st.error(f"Server error: {response.status_code}")
                return None
            else:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get('error', f'Request failed with status {response.status_code}')
                st.error(f"API Error: {error_msg}")
                return None
                
        except requests.exceptions.Timeout:
            st.error("Request timed out. Please try again.")
            return None
        except requests.exceptions.ConnectionError:
            st.error("Cannot connect to the backend service. Please check if the server is running.")
            return None
        except requests.exceptions.RequestException as e:
            st.error(f"Request failed: {str(e)}")
            return None
        except Exception as e:
            st.error(f"Unexpected error: {str(e)}")
            return None
    
    def get_health_status(self) -> Optional[Dict[str, Any]]:
        """Get system health status."""
        return self._make_request('GET', '/health')
    
    # Document Management
    def upload_document(self, file) -> Optional[Dict[str, Any]]:
        """
        Upload a document file.
        
        Args:
            file: Streamlit uploaded file object
        
        Returns:
            Upload response data
        """
        try:
            # Remove Content-Type header for file upload
            headers = {k: v for k, v in self.session.headers.items() if k != 'Content-Type'}
            
            files = {'file': (file.name, file, file.type)}
            
            response = requests.post(
                f"{self.base_url}/api/upload",
                files=files,
                headers=headers,
                timeout=self.timeout * 3  # Extended timeout for uploads
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                error_data = response.json() if response.content else {}
                error_msg = error_data.get('error', 'Upload failed')
                st.error(f"Upload failed: {error_msg}")
                return None
                
        except Exception as e:
            st.error(f"Upload error: {str(e)}")
            return None
    
    def list_documents(self) -> Optional[Dict[str, Any]]:
        """Get list of all documents."""
        return self._make_request('GET', '/api/documents')
    
    def get_document(self, doc_id: str) -> Optional[Dict[str, Any]]:
        """Get document information by ID."""
        return self._make_request('GET', f'/api/documents/{doc_id}')
    
    def delete_document(self, doc_id: str) -> Optional[Dict[str, Any]]:
        """Delete a document by ID."""
        return self._make_request('DELETE', f'/api/documents/{doc_id}')
    
    def search_documents(self, query: str, top_k: int = 5) -> Optional[Dict[str, Any]]:
        """Search documents using semantic similarity."""
        data = {'query': query, 'top_k': top_k}
        return self._make_request('POST', '/api/documents/search', json=data)
    
    # Summarization
    def generate_rag_summary(self, query: str, doc_id: str = None, mode: str = 'extractive') -> Optional[Dict[str, Any]]:
        """
        Generate RAG-based summary.
        
        Args:
            query: User query
            doc_id: Optional document filter
            mode: 'extractive' or 'abstractive'
        
        Returns:
            Summary generation response
        """
        data = {'query': query, 'mode': mode}
        if doc_id:
            data['doc_id'] = doc_id
        
        return self._make_request('POST', '/api/summarize/rag', json=data)
    
    def generate_qwen_summaries(self, query: str, context: str = None, doc_id: str = None) -> Optional[Dict[str, Any]]:
        """
        Generate dual summaries using Qwen model.
        
        Args:
            query: User query
            context: Context text (optional)
            doc_id: Document ID (optional)
        
        Returns:
            Dual summary response
        """
        data = {'query': query}
        if context:
            data['context'] = context
        if doc_id:
            data['doc_id'] = doc_id
        
        return self._make_request('POST', '/api/summarize/qwen', json=data)
    
    def get_summary_history(self, doc_id: str = None, phase: str = None, limit: int = 20) -> Optional[Dict[str, Any]]:
        """Get summarization history."""
        params = {'limit': limit}
        if doc_id:
            params['doc_id'] = doc_id
        if phase:
            params['phase'] = phase
        
        return self._make_request('GET', '/api/summarize/history', params=params)
    
    # Preferences
    def submit_preference(self, episode_id: str, preference: str, reasoning: str = None, confidence: float = 1.0) -> Optional[Dict[str, Any]]:
        """
        Submit user preference for A/B testing.
        
        Args:
            episode_id: Episode identifier
            preference: 'A' or 'B'
            reasoning: Optional explanation
            confidence: Confidence score (0-1)
        
        Returns:
            Preference submission response
        """
        data = {
            'episode_id': episode_id,
            'preference': preference,
            'confidence': confidence
        }
        if reasoning:
            data['reasoning'] = reasoning
        
        return self._make_request('POST', '/api/preference', json=data)
    
    def get_preferences(self, limit: int = 50, model_version: str = None) -> Optional[Dict[str, Any]]:
        """Get user preferences data."""
        params = {'limit': limit}
        if model_version:
            params['model_version'] = model_version
        
        return self._make_request('GET', '/api/preferences', params=params)
    
    def get_preference_statistics(self, days: int = 30) -> Optional[Dict[str, Any]]:
        """Get preference statistics."""
        params = {'days': days}
        return self._make_request('GET', '/api/preferences/stats', params=params)
    
    # Training
    def trigger_dpo_training(self, config: Dict[str, Any] = None, force: bool = False) -> Optional[Dict[str, Any]]:
        """
        Trigger DPO training.
        
        Args:
            config: Training configuration
            force: Force training even if requirements not met
        
        Returns:
            Training trigger response
        """
        data = {'force': force}
        if config:
            data.update(config)
        
        return self._make_request('POST', '/api/train/dpo', json=data)
    
    def get_training_status(self, training_id: str) -> Optional[Dict[str, Any]]:
        """Get training job status."""
        return self._make_request('GET', f'/api/train/status/{training_id}')
    
    def get_training_history(self, limit: int = 20) -> Optional[Dict[str, Any]]:
        """Get training history."""
        params = {'limit': limit}
        return self._make_request('GET', '/api/train/history', params=params)
    
    def check_training_requirements(self) -> Optional[Dict[str, Any]]:
        """Check if training requirements are met."""
        return self._make_request('GET', '/api/train/requirements')
    
    # Models
    def get_model_info(self) -> Optional[Dict[str, Any]]:
        """Get current model information."""
        return self._make_request('GET', '/api/model/info')
    
    def list_model_versions(self) -> Optional[Dict[str, Any]]:
        """Get list of available model versions."""
        return self._make_request('GET', '/api/model/versions')
    
    def load_model_version(self, version: str) -> Optional[Dict[str, Any]]:
        """Load a specific model version."""
        return self._make_request('POST', f'/api/model/load/{version}')
    
    def get_model_metrics(self, version: str = None, days: int = 30) -> Optional[Dict[str, Any]]:
        """Get model performance metrics."""
        params = {'days': days}
        if version:
            params['version'] = version
        
        return self._make_request('GET', '/api/model/metrics', params=params)
    
    def benchmark_model(self, test_queries: List[str], doc_id: str = None) -> Optional[Dict[str, Any]]:
        """Run model benchmark tests."""
        data = {'test_queries': test_queries}
        if doc_id:
            data['doc_id'] = doc_id
        
        return self._make_request('POST', '/api/model/benchmark', json=data)