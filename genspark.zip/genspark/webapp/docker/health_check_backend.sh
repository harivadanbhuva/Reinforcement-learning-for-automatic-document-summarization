#!/bin/bash

# Health check script for backend service
# This script validates that all backend services are running correctly

set -e

# Configuration
HOST="localhost"
PORT="5000"
TIMEOUT=10
MAX_RETRIES=3

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${YELLOW}🔍 Starting backend health check...${NC}"

# Function to check if service is responding
check_service() {
    local endpoint=$1
    local description=$2
    
    echo -e "⏳ Checking $description..."
    
    if curl -f -s --connect-timeout $TIMEOUT "http://$HOST:$PORT$endpoint" > /dev/null; then
        echo -e "${GREEN}✅ $description is healthy${NC}"
        return 0
    else
        echo -e "${RED}❌ $description is not responding${NC}"
        return 1
    fi
}

# Function to check Redis connection
check_redis() {
    echo -e "⏳ Checking Redis connection..."
    
    if python3 -c "
import redis
import os
try:
    redis_url = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    r = redis.from_url(redis_url)
    r.ping()
    print('Redis connection successful')
    exit(0)
except Exception as e:
    print(f'Redis connection failed: {e}')
    exit(1)
" 2>/dev/null; then
        echo -e "${GREEN}✅ Redis connection is healthy${NC}"
        return 0
    else
        echo -e "${RED}❌ Redis connection failed${NC}"
        return 1
    fi
}

# Function to check Ollama connection
check_ollama() {
    echo -e "⏳ Checking Ollama connection..."
    
    ollama_host=${OLLAMA_HOST:-"http://localhost:11434"}
    
    if curl -f -s --connect-timeout $TIMEOUT "$ollama_host/api/tags" > /dev/null; then
        echo -e "${GREEN}✅ Ollama connection is healthy${NC}"
        return 0
    else
        echo -e "${YELLOW}⚠️  Ollama connection failed (may not be critical)${NC}"
        return 1
    fi
}

# Main health check function
main() {
    local failed=0
    
    # Check basic health endpoint
    if ! check_service "/health" "Basic health endpoint"; then
        ((failed++))
    fi
    
    # Check API endpoints
    if ! check_service "/api/health" "API health endpoint"; then
        ((failed++))
    fi
    
    # Check Redis (critical)
    if ! check_redis; then
        ((failed++))
    fi
    
    # Check Ollama (non-critical but important)
    if ! check_ollama; then
        echo -e "${YELLOW}ℹ️  Note: Some features may be limited without Ollama${NC}"
    fi
    
    # Summary
    if [ $failed -eq 0 ]; then
        echo -e "\n${GREEN}🎉 All critical services are healthy!${NC}"
        exit 0
    else
        echo -e "\n${RED}💥 $failed critical service(s) failed health check${NC}"
        exit 1
    fi
}

# Run with retries
retry_count=0
while [ $retry_count -lt $MAX_RETRIES ]; do
    if main; then
        exit 0
    fi
    
    ((retry_count++))
    if [ $retry_count -lt $MAX_RETRIES ]; then
        echo -e "${YELLOW}🔄 Retry $retry_count/$MAX_RETRIES in 5 seconds...${NC}"
        sleep 5
    fi
done

echo -e "${RED}💀 Health check failed after $MAX_RETRIES retries${NC}"
exit 1