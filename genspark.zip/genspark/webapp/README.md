# Reinforcement Learning for Automatic Document Summarization

An intelligent document summarization system that learns from user preferences through reinforcement learning, combining extractive and abstractive summarization with real-time model improvement via DPO-RLHF (Direct Preference Optimization - Reinforcement Learning from Human Feedback).

## 🚀 Key Features

✅ **Groq-Powered RAG**: Ultra-fast summary generation with gpt-oss-120b model
✅ **Intelligent Agents**: Autonomous DuckDuckGo + Wikipedia browsing for external knowledge
✅ **Two-Stage Fine-Tuning**: Pre-training (Phase 2.5) + Active learning (Phase 4)
✅ **Qwen Model Control**: Fine-tuned Qwen2.5-7B generates both extractive and abstractive summaries
✅ **Human-in-the-Loop**: A/B testing captures real user preferences
✅ **Progressive Learning**: Model continuously improves via DPO-RLHF
✅ **Complete Audit Trail**: JSONL logging for every phase

## 📋 System Architecture

### Core Components

1. **Base Model**: Qwen/Qwen2.5-7B-Instruct (Hugging Face)
2. **RAG Model**: Groq API (gpt-oss-120b) for summary generation
3. **Embedding Model**: Ollama embeddings
4. **Vector Store**: FAISS for efficient similarity search
5. **Agents**: DuckDuckGo + Wikipedia search agents
6. **Framework**: LangChain for orchestration
7. **Storage**: JSONL files for episode/conversation logging

### Workflow Phases

- **Phase 1**: Document Ingestion & Embedding
- **Phase 2**: Query Processing & RAG-based Summarization with Agents
- **Phase 2.5**: Supervised Fine-Tuning (Pre-Phase 3 Setup)
- **Phase 3**: A/B Testing with Fine-Tuned Model
- **Phase 4**: Active Reinforcement Learning via DPO-RLHF

## 🛠️ Installation & Setup

### Prerequisites

- Python 3.9+
- CUDA-capable GPU (for model training)
- 16GB+ RAM recommended
- Redis server
- Ollama installed locally

### Quick Start

1. **Clone Repository**
```bash
git clone <repository_url>
cd rl-document-summarization
```

2. **Install Dependencies**
```bash
pip install -r requirements.txt
cd backend && pip install -r requirements.txt
cd ../frontend && pip install -r requirements.txt
```

3. **Setup Environment Variables**
```bash
cp .env.example .env
# Edit .env: Add GROQ_API_KEY, HUGGING_FACE_TOKEN
```

4. **Initialize Services**
```bash
# Initialize FAISS index
python scripts/setup_faiss.py

# Download and fine-tune base model (Phase 2.5)
python scripts/initial_fine_tune.py
```

5. **Start Services**
```bash
# Terminal 1: Start Ollama
ollama serve

# Terminal 2: Start Redis
redis-server

# Terminal 3: Start Celery Worker
cd backend
celery -A celery_app.celery worker --loglevel=info

# Terminal 4: Start Flask API
cd backend
python run.py

# Terminal 5: Start Streamlit
cd frontend
streamlit run app.py
```

6. **Access Application**
- Frontend: http://localhost:8501
- API: http://localhost:5000
- API Documentation: http://localhost:5000/docs

## 📊 Implementation Stack

| Component | Technology |
|-----------|-----------|
| RAG Generator | Groq API (gpt-oss-120b) |
| A/B Testing Model | Qwen/Qwen2.5-7B-Instruct (Fine-tuned) |
| Pre-training Dataset | thepowerfuldeez/Qwen-summarize-dataset-train |
| Embeddings | Ollama |
| Vector Database | FAISS |
| Agents | LangChain (DuckDuckGo, Wikipedia) |
| RL Algorithm | DPO (Direct Preference Optimization) |
| Storage | JSONL files |
| Frontend | Streamlit |
| Backend | Flask + Celery |
| Cache | Redis |

## 📁 Project Structure

```
rl-document-summarization/
├── 📂 data/                    # Data storage
├── 📂 models/                  # Model checkpoints and logs
├── 📂 backend/                 # Flask API Backend
├── 📂 frontend/                # Streamlit Frontend
├── 📂 scripts/                 # Utility scripts
├── 📂 tests/                   # Unit and integration tests
├── 📂 configs/                 # Configuration files
├── 📂 docker/                  # Docker configuration
└── 📂 docs/                    # Documentation
```

## 🔄 Usage Workflow

1. **Upload Documents**: Use Streamlit interface to upload PDF/TXT/DOCX files
2. **Query Documents**: Ask questions about your uploaded documents
3. **Compare Summaries**: View extractive vs abstractive summaries side-by-side
4. **Select Preferences**: Choose your preferred summary style
5. **Model Learning**: System automatically improves based on your feedback

## 📈 Model Training Pipeline

### Phase 2.5: Initial Training
- Supervised fine-tuning on Qwen-summarize-dataset-train
- DPO initialization with general summarization preferences

### Phase 4: Active Learning
- Collect user preferences from A/B testing
- Periodic DPO fine-tuning updates model
- Continuous improvement loop

## 🔧 Configuration

### Environment Variables
```bash
GROQ_API_KEY=your_groq_api_key
HUGGING_FACE_TOKEN=your_hf_token
REDIS_URL=redis://localhost:6379
OLLAMA_HOST=http://localhost:11434
```

### Training Configuration
- Model: Qwen2.5-7B-Instruct
- Batch Size: 64
- Learning Rate: 5e-6
- DPO Beta: 0.1

## 📊 Monitoring & Analytics

The system provides comprehensive analytics through the Streamlit dashboard:
- User preference distributions
- Model performance metrics
- Training progress tracking
- Summary quality assessments

## 🐳 Docker Deployment

```bash
docker-compose up -d
```

See `docker/docker-compose.yml` for complete container orchestration.

## 🧪 Testing

```bash
# Run unit tests
python -m pytest tests/unit/

# Run integration tests
python -m pytest tests/integration/

# Run all tests
python -m pytest
```

## 📚 Documentation

- [API Documentation](docs/API.md)
- [Setup Guide](docs/SETUP.md)
- [Deployment Guide](docs/DEPLOYMENT.md)
- [Architecture Overview](docs/ARCHITECTURE.md)

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Qwen team for the base language model
- Groq for high-speed inference API
- Ollama for local embeddings
- LangChain for agent orchestration
- Streamlit for rapid UI development

## 📞 Support

For questions and support, please open an issue in the GitHub repository.

---

**Built with ❤️ for intelligent document processing**