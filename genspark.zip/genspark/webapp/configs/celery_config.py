"""
Celery Configuration Module

Provides configuration for distributed task processing using Celery.
Includes task routing, worker settings, and monitoring configuration.
"""

from celery import Celery
from celery.schedules import crontab
import os
from typing import Dict, Any


class CeleryConfig:
    """Celery configuration class"""
    
    # Broker and backend
    broker_url = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    result_backend = os.getenv('REDIS_URL', 'redis://localhost:6379/0')
    
    # Task serialization
    task_serializer = 'json'
    accept_content = ['json']
    result_serializer = 'json'
    timezone = 'UTC'
    enable_utc = True
    
    # Task routing
    task_routes = {
        'tasks.embedding_tasks.*': {'queue': 'embedding'},
        'tasks.training_tasks.*': {'queue': 'training'},
        'tasks.inference_tasks.*': {'queue': 'inference'},
        'tasks.maintenance_tasks.*': {'queue': 'maintenance'},
    }
    
    # Worker settings
    worker_prefetch_multiplier = 1
    task_acks_late = True
    worker_max_tasks_per_child = 1000
    worker_disable_rate_limits = True
    
    # Task execution
    task_always_eager = False
    task_eager_propagates = True
    task_ignore_result = False
    task_store_eager_result = True
    
    # Result backend settings
    result_expires = 3600  # 1 hour
    result_persistent = True
    
    # Task retry settings
    task_retry_delay = 60  # 1 minute
    task_max_retries = 3
    
    # Beat schedule for periodic tasks
    beat_schedule = {
        'cleanup-old-results': {
            'task': 'tasks.maintenance_tasks.cleanup_old_results',
            'schedule': crontab(hour=2, minute=0),  # Daily at 2 AM
        },
        'backup-episode-logs': {
            'task': 'tasks.maintenance_tasks.backup_episode_logs',
            'schedule': crontab(hour=3, minute=0),  # Daily at 3 AM
        },
        'check-model-performance': {
            'task': 'tasks.maintenance_tasks.check_model_performance',
            'schedule': crontab(minute=0),  # Every hour
        },
        'trigger-training-if-needed': {
            'task': 'tasks.training_tasks.check_and_trigger_training',
            'schedule': crontab(minute='*/15'),  # Every 15 minutes
        },
    }
    
    # Monitoring
    worker_send_task_events = True
    task_send_sent_event = True
    
    # Security
    worker_hijack_root_logger = False
    worker_log_color = True


def create_celery_app(app_name: str = "rl_summarization") -> Celery:
    """
    Create and configure Celery application.
    
    Args:
        app_name: Name for the Celery application
        
    Returns:
        Configured Celery application instance
    """
    
    celery_app = Celery(app_name)
    celery_app.config_from_object(CeleryConfig)
    
    # Update configuration with environment variables
    celery_app.conf.update(
        broker_url=os.getenv('REDIS_URL', 'redis://localhost:6379/0'),
        result_backend=os.getenv('REDIS_URL', 'redis://localhost:6379/0'),
    )
    
    return celery_app


def get_task_queues() -> Dict[str, Dict[str, Any]]:
    """
    Get task queue configurations.
    
    Returns:
        Dictionary of queue configurations
    """
    
    return {
        'embedding': {
            'exchange': 'embedding',
            'exchange_type': 'direct',
            'routing_key': 'embedding',
            'queue_arguments': {'x-max-priority': 5}
        },
        'training': {
            'exchange': 'training',
            'exchange_type': 'direct',
            'routing_key': 'training',
            'queue_arguments': {'x-max-priority': 10}
        },
        'inference': {
            'exchange': 'inference',
            'exchange_type': 'direct',
            'routing_key': 'inference',
            'queue_arguments': {'x-max-priority': 8}
        },
        'maintenance': {
            'exchange': 'maintenance',
            'exchange_type': 'direct',
            'routing_key': 'maintenance',
            'queue_arguments': {'x-max-priority': 1}
        },
    }


def get_worker_configs() -> Dict[str, Dict[str, Any]]:
    """
    Get worker-specific configurations.
    
    Returns:
        Dictionary of worker configurations
    """
    
    return {
        'embedding_worker': {
            'queues': ['embedding'],
            'concurrency': 2,
            'max_tasks_per_child': 100,
            'time_limit': 300,  # 5 minutes
            'soft_time_limit': 240,  # 4 minutes
        },
        'training_worker': {
            'queues': ['training'],
            'concurrency': 1,  # GPU-intensive, limit concurrency
            'max_tasks_per_child': 10,
            'time_limit': 3600,  # 1 hour
            'soft_time_limit': 3300,  # 55 minutes
        },
        'inference_worker': {
            'queues': ['inference'],
            'concurrency': 4,
            'max_tasks_per_child': 200,
            'time_limit': 120,  # 2 minutes
            'soft_time_limit': 90,  # 1.5 minutes
        },
        'maintenance_worker': {
            'queues': ['maintenance'],
            'concurrency': 1,
            'max_tasks_per_child': 50,
            'time_limit': 600,  # 10 minutes
            'soft_time_limit': 540,  # 9 minutes
        },
    }


# Task priority levels
class TaskPriority:
    """Task priority constants"""
    URGENT = 10
    HIGH = 8
    NORMAL = 5
    LOW = 3
    BACKGROUND = 1


# Task configuration templates
TASK_CONFIG_TEMPLATES = {
    'embedding_task': {
        'bind': True,
        'autoretry_for': (Exception,),
        'retry_kwargs': {'max_retries': 3, 'countdown': 60},
        'priority': TaskPriority.HIGH,
    },
    'training_task': {
        'bind': True,
        'autoretry_for': (Exception,),
        'retry_kwargs': {'max_retries': 2, 'countdown': 300},  # 5 minutes
        'priority': TaskPriority.URGENT,
    },
    'inference_task': {
        'bind': True,
        'autoretry_for': (Exception,),
        'retry_kwargs': {'max_retries': 3, 'countdown': 30},
        'priority': TaskPriority.NORMAL,
    },
    'maintenance_task': {
        'bind': True,
        'autoretry_for': (Exception,),
        'retry_kwargs': {'max_retries': 2, 'countdown': 600},  # 10 minutes
        'priority': TaskPriority.BACKGROUND,
    },
}


def get_task_config(task_type: str) -> Dict[str, Any]:
    """
    Get configuration for a specific task type.
    
    Args:
        task_type: Type of task (embedding_task, training_task, etc.)
        
    Returns:
        Task configuration dictionary
    """
    return TASK_CONFIG_TEMPLATES.get(task_type, TASK_CONFIG_TEMPLATES['inference_task'])


# Monitoring and metrics configuration
MONITORING_CONFIG = {
    'collect_statistics': True,
    'statistics_interval': 30,  # seconds
    'enable_heartbeat': True,
    'heartbeat_interval': 30,  # seconds
    'enable_task_tracking': True,
    'track_task_duration': True,
    'track_task_memory': True,
}


def setup_celery_logging(celery_app: Celery):
    """
    Setup logging for Celery workers.
    
    Args:
        celery_app: Celery application instance
    """
    
    from celery.utils.log import get_task_logger
    from configs.logging_config import setup_logging
    
    # Setup structured logging
    setup_logging(
        level=os.getenv('LOG_LEVEL', 'INFO'),
        log_file='./logs/celery.log',
        json_format=True,
        colored_console=False
    )
    
    # Get Celery logger
    logger = get_task_logger(__name__)
    logger.info("Celery logging configured")


def get_celery_health_check() -> Dict[str, Any]:
    """
    Get Celery health check configuration.
    
    Returns:
        Health check configuration
    """
    
    return {
        'check_broker': True,
        'check_workers': True,
        'check_queues': True,
        'timeout': 10,  # seconds
        'retry_count': 3,
    }


# Export main configuration
celery_config = CeleryConfig()