"""
Application Configuration Module

This module contains all configuration settings for the RL Document Summarization system.
Different configurations are provided for development, testing, and production environments.
"""

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Any, Optional
import logging


@dataclass
class DatabaseConfig:
    """Database configuration settings"""
    redis_url: str = "redis://localhost:6379/0"
    redis_max_connections: int = 20
    redis_retry_on_timeout: bool = True
    redis_socket_keepalive: bool = True
    redis_socket_keepalive_options: Dict[str, Any] = None

    def __post_init__(self):
        if self.redis_socket_keepalive_options is None:
            self.redis_socket_keepalive_options = {
                'TCP_KEEPINTVL': 1,
                'TCP_KEEPCNT': 3,
                'TCP_KEEPIDLE': 1
            }


@dataclass
class ModelConfig:
    """Model configuration settings"""
    # Base model settings
    base_model_name: str = "Qwen/Qwen2.5-7B-Instruct"
    cache_dir: str = "./models/cache"
    
    # Groq API settings
    groq_api_key: str = ""
    groq_model: str = "gpt-oss-120b"
    groq_max_tokens: int = 1000
    groq_temperature: float = 0.7
    groq_timeout: int = 30
    
    # Ollama settings
    ollama_host: str = "http://localhost:11434"
    ollama_model: str = "nomic-embed-text"
    ollama_timeout: int = 60
    
    # Training settings
    batch_size: int = 8
    learning_rate: float = 1e-5
    max_epochs: int = 3
    warmup_steps: int = 100
    weight_decay: float = 0.01
    gradient_accumulation_steps: int = 4
    
    # DPO settings
    dpo_beta: float = 0.1
    reference_model_cache: str = "./models/reference"
    
    # Fine-tuning dataset
    pretrain_dataset: str = "thepowerfuldeez/Qwen-summarize-dataset-train"
    dataset_split: str = "train"
    max_dataset_size: Optional[int] = 10000


@dataclass
class EmbeddingConfig:
    """Embedding and vector store configuration"""
    dimension: int = 768
    faiss_index_type: str = "IndexFlatIP"  # Inner Product for cosine similarity
    faiss_index_path: str = "./data/embeddings/faiss_index"
    chunk_size: int = 512
    chunk_overlap: int = 50
    max_chunks_per_document: int = 100
    similarity_threshold: float = 0.7
    top_k_retrieval: int = 5


@dataclass
class RagConfig:
    """RAG pipeline configuration"""
    max_context_length: int = 4000
    summary_max_length: int = 500
    extractive_ratio: float = 0.3  # Percentage of original text for extractive summaries
    abstractive_min_length: int = 50
    abstractive_max_length: int = 200
    
    # Agent settings
    enable_web_search: bool = True
    enable_wikipedia: bool = True
    max_search_results: int = 5
    search_timeout: int = 30


@dataclass
class TrainingConfig:
    """Training and evaluation configuration"""
    save_steps: int = 500
    eval_steps: int = 100
    logging_steps: int = 50
    max_grad_norm: float = 1.0
    
    # Model versioning
    model_checkpoint_dir: str = "./models/checkpoints"
    training_logs_dir: str = "./models/logs"
    
    # DPO training
    preference_threshold: float = 0.6  # Minimum confidence for preference data
    min_preference_pairs: int = 10  # Minimum pairs needed to trigger training
    training_trigger_interval: int = 100  # Check for training every N preferences
    
    # Evaluation metrics
    eval_batch_size: int = 16
    eval_max_samples: int = 500


@dataclass
class CeleryConfig:
    """Celery task queue configuration"""
    broker_url: str = "redis://localhost:6379/0"
    result_backend: str = "redis://localhost:6379/0"
    task_serializer: str = "json"
    accept_content: list = None
    result_serializer: str = "json"
    timezone: str = "UTC"
    enable_utc: bool = True
    
    # Task routing
    task_routes: Dict[str, Dict[str, str]] = None
    
    # Worker settings
    worker_prefetch_multiplier: int = 1
    task_acks_late: bool = True
    worker_max_tasks_per_child: int = 1000
    
    def __post_init__(self):
        if self.accept_content is None:
            self.accept_content = ["json"]
        
        if self.task_routes is None:
            self.task_routes = {
                'tasks.embedding_tasks.*': {'queue': 'embedding'},
                'tasks.training_tasks.*': {'queue': 'training'},
                'tasks.inference_tasks.*': {'queue': 'inference'},
            }


@dataclass
class LoggingConfig:
    """Logging configuration"""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file_path: str = "./logs/app.log"
    max_bytes: int = 10 * 1024 * 1024  # 10MB
    backup_count: int = 5
    
    # Episode logging
    episode_log_dir: str = "./data/episodes"
    episode_log_format: str = "jsonl"


@dataclass
class SecurityConfig:
    """Security configuration"""
    secret_key: str = "dev-key-change-in-production"
    jwt_secret_key: str = "jwt-dev-key-change-in-production"
    jwt_access_token_expires: int = 3600  # 1 hour
    
    # CORS settings
    cors_origins: list = None
    
    # Rate limiting
    rate_limit_per_minute: int = 60
    upload_max_size: int = 100 * 1024 * 1024  # 100MB
    
    def __post_init__(self):
        if self.cors_origins is None:
            self.cors_origins = ["http://localhost:8501", "http://localhost:3000"]


class BaseConfig:
    """Base configuration class"""
    
    def __init__(self):
        # Core directories
        self.base_dir = Path(__file__).parent.parent.absolute()
        self.data_dir = self.base_dir / "data"
        self.models_dir = self.base_dir / "models"
        self.logs_dir = self.base_dir / "logs"
        
        # Ensure directories exist
        for dir_path in [self.data_dir, self.models_dir, self.logs_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)
        
        # Configuration components
        self.database = DatabaseConfig()
        self.model = ModelConfig()
        self.embedding = EmbeddingConfig()
        self.rag = RagConfig()
        self.training = TrainingConfig()
        self.celery = CeleryConfig()
        self.logging = LoggingConfig()
        self.security = SecurityConfig()
        
        # Environment-specific overrides
        self._load_environment_variables()
    
    def _load_environment_variables(self):
        """Load configuration from environment variables"""
        
        # Database
        if redis_url := os.getenv("REDIS_URL"):
            self.database.redis_url = redis_url
            self.celery.broker_url = redis_url
            self.celery.result_backend = redis_url
        
        # Model API keys
        if groq_key := os.getenv("GROQ_API_KEY"):
            self.model.groq_api_key = groq_key
        
        if hf_token := os.getenv("HUGGING_FACE_TOKEN"):
            # Set for transformers library
            os.environ["HF_TOKEN"] = hf_token
        
        # Ollama
        if ollama_host := os.getenv("OLLAMA_HOST"):
            self.model.ollama_host = ollama_host
        
        # Directories
        if data_dir := os.getenv("DATA_DIR"):
            self.data_dir = Path(data_dir)
            self.data_dir.mkdir(parents=True, exist_ok=True)
        
        if models_dir := os.getenv("MODELS_DIR"):
            self.models_dir = Path(models_dir)
            self.models_dir.mkdir(parents=True, exist_ok=True)
        
        # Security
        if secret_key := os.getenv("SECRET_KEY"):
            self.security.secret_key = secret_key
        
        if jwt_key := os.getenv("JWT_SECRET_KEY"):
            self.security.jwt_secret_key = jwt_key
    
    def get_absolute_path(self, relative_path: str) -> Path:
        """Convert relative path to absolute based on base directory"""
        return self.base_dir / relative_path
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert configuration to dictionary"""
        return {
            "database": self.database.__dict__,
            "model": self.model.__dict__,
            "embedding": self.embedding.__dict__,
            "rag": self.rag.__dict__,
            "training": self.training.__dict__,
            "celery": self.celery.__dict__,
            "logging": self.logging.__dict__,
            "security": self.security.__dict__,
            "directories": {
                "base_dir": str(self.base_dir),
                "data_dir": str(self.data_dir),
                "models_dir": str(self.models_dir),
                "logs_dir": str(self.logs_dir)
            }
        }


class DevelopmentConfig(BaseConfig):
    """Development environment configuration"""
    
    def __init__(self):
        super().__init__()
        
        # Override for development
        self.logging.level = "DEBUG"
        self.model.batch_size = 4  # Smaller batch size for dev
        self.training.save_steps = 100
        self.training.eval_steps = 50
        self.security.cors_origins = ["*"]  # Allow all origins in dev


class ProductionConfig(BaseConfig):
    """Production environment configuration"""
    
    def __init__(self):
        super().__init__()
        
        # Override for production
        self.logging.level = "WARNING"
        self.model.batch_size = 16  # Larger batch size for production
        self.training.save_steps = 1000
        self.security.secret_key = os.getenv("SECRET_KEY", "CHANGE_ME_IN_PRODUCTION")
        self.security.jwt_secret_key = os.getenv("JWT_SECRET_KEY", "CHANGE_ME_IN_PRODUCTION")


class TestingConfig(BaseConfig):
    """Testing environment configuration"""
    
    def __init__(self):
        super().__init__()
        
        # Override for testing
        self.logging.level = "DEBUG"
        self.database.redis_url = "redis://localhost:6379/1"  # Different DB for tests
        self.model.batch_size = 2
        self.training.max_epochs = 1
        self.training.save_steps = 10
        self.model.max_dataset_size = 100  # Small dataset for tests


def get_config(env: str = None) -> BaseConfig:
    """
    Factory function to get configuration based on environment.
    
    Args:
        env: Environment name ('development', 'production', 'testing')
             If None, uses FLASK_ENV environment variable
    
    Returns:
        Configuration instance for the specified environment
    """
    if env is None:
        env = os.getenv("FLASK_ENV", "development")
    
    config_map = {
        "development": DevelopmentConfig,
        "production": ProductionConfig,
        "testing": TestingConfig
    }
    
    config_class = config_map.get(env, DevelopmentConfig)
    return config_class()


# Global configuration instance
config = get_config()