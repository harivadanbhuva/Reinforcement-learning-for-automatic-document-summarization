"""
Logging Configuration Module

Provides centralized logging configuration for the entire RL Document Summarization system.
Supports structured logging, different log levels, and multiple output formats.
"""

import logging
import logging.handlers
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional
import os


class JSONFormatter(logging.Formatter):
    """Custom JSON formatter for structured logging"""
    
    def format(self, record):
        """Format log record as JSON"""
        log_obj = {
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno
        }
        
        # Add exception info if present
        if record.exc_info:
            log_obj['exception'] = self.formatException(record.exc_info)
        
        # Add extra fields from record
        extra_fields = {
            k: v for k, v in record.__dict__.items()
            if k not in {
                'name', 'msg', 'args', 'levelname', 'levelno', 'pathname',
                'filename', 'module', 'exc_info', 'exc_text', 'stack_info',
                'lineno', 'funcName', 'created', 'msecs', 'relativeCreated',
                'thread', 'threadName', 'processName', 'process', 'message'
            }
        }
        
        if extra_fields:
            log_obj['extra'] = extra_fields
        
        return json.dumps(log_obj)


class ColoredFormatter(logging.Formatter):
    """Colored formatter for console output"""
    
    COLORS = {
        'DEBUG': '\033[36m',    # Cyan
        'INFO': '\033[32m',     # Green
        'WARNING': '\033[33m',  # Yellow
        'ERROR': '\033[31m',    # Red
        'CRITICAL': '\033[35m', # Magenta
        'RESET': '\033[0m'      # Reset
    }
    
    def format(self, record):
        """Format log record with colors"""
        color = self.COLORS.get(record.levelname, self.COLORS['RESET'])
        reset = self.COLORS['RESET']
        
        # Color the level name
        record.levelname = f"{color}{record.levelname}{reset}"
        
        # Format the message
        formatted = super().format(record)
        
        return formatted


class EpisodeLogger:
    """Specialized logger for episode/conversation tracking"""
    
    def __init__(self, log_dir: str = "./data/episodes"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
    
    def log_episode(self, episode_data: Dict[str, Any], session_id: str = None):
        """Log episode data to JSONL file"""
        
        # Add metadata
        episode_data['logged_at'] = datetime.utcnow().isoformat() + 'Z'
        episode_data['session_id'] = session_id
        
        # Determine log file based on date
        date_str = datetime.utcnow().strftime('%Y-%m-%d')
        log_file = self.log_dir / f"episodes_{date_str}.jsonl"
        
        # Append to JSONL file
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(episode_data) + '\n')
    
    def get_episodes(self, date: str = None, session_id: str = None) -> list:
        """Retrieve episodes from logs"""
        episodes = []
        
        if date:
            log_file = self.log_dir / f"episodes_{date}.jsonl"
            if log_file.exists():
                with open(log_file, 'r', encoding='utf-8') as f:
                    for line in f:
                        episode = json.loads(line.strip())
                        if session_id is None or episode.get('session_id') == session_id:
                            episodes.append(episode)
        else:
            # Get all episodes from all files
            for log_file in self.log_dir.glob("episodes_*.jsonl"):
                with open(log_file, 'r', encoding='utf-8') as f:
                    for line in f:
                        episode = json.loads(line.strip())
                        if session_id is None or episode.get('session_id') == session_id:
                            episodes.append(episode)
        
        return episodes


class TrainingLogger:
    """Specialized logger for training metrics and progress"""
    
    def __init__(self, log_dir: str = "./models/logs"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
    
    def log_training_step(self, training_id: str, step_data: Dict[str, Any]):
        """Log training step metrics"""
        
        step_data['logged_at'] = datetime.utcnow().isoformat() + 'Z'
        step_data['training_id'] = training_id
        
        log_file = self.log_dir / f"training_{training_id}.jsonl"
        
        with open(log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(step_data) + '\n')
    
    def get_training_history(self, training_id: str) -> list:
        """Get training history for a specific training run"""
        log_file = self.log_dir / f"training_{training_id}.jsonl"
        
        if not log_file.exists():
            return []
        
        history = []
        with open(log_file, 'r', encoding='utf-8') as f:
            for line in f:
                history.append(json.loads(line.strip()))
        
        return history


def setup_logging(
    level: str = "INFO",
    log_file: Optional[str] = None,
    json_format: bool = False,
    colored_console: bool = True
) -> Dict[str, logging.Logger]:
    """
    Setup logging configuration for the application.
    
    Args:
        level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Path to log file (optional)
        json_format: Whether to use JSON format for file logging
        colored_console: Whether to use colored output for console
    
    Returns:
        Dictionary of configured loggers
    """
    
    # Clear existing handlers
    logging.root.handlers = []
    
    # Set root logger level
    numeric_level = getattr(logging, level.upper(), None)
    if not isinstance(numeric_level, int):
        raise ValueError(f'Invalid log level: {level}')
    
    logging.root.setLevel(numeric_level)
    
    # Create formatters
    if json_format and log_file:
        file_formatter = JSONFormatter()
    else:
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    
    if colored_console:
        console_formatter = ColoredFormatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    else:
        console_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
    
    # Console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(console_formatter)
    logging.root.addHandler(console_handler)
    
    # File handler (if specified)
    if log_file:
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = logging.handlers.RotatingFileHandler(
            log_file,
            maxBytes=10 * 1024 * 1024,  # 10MB
            backupCount=5
        )
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(file_formatter)
        logging.root.addHandler(file_handler)
    
    # Create specific loggers
    loggers = {
        'app': logging.getLogger('app'),
        'rag': logging.getLogger('rag'),
        'training': logging.getLogger('training'),
        'embedding': logging.getLogger('embedding'),
        'celery': logging.getLogger('celery'),
        'api': logging.getLogger('api'),
        'frontend': logging.getLogger('frontend')
    }
    
    # Configure third-party loggers
    logging.getLogger('transformers').setLevel(logging.WARNING)
    logging.getLogger('torch').setLevel(logging.WARNING)
    logging.getLogger('datasets').setLevel(logging.WARNING)
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    logging.getLogger('requests').setLevel(logging.WARNING)
    
    return loggers


def setup_production_logging():
    """Setup logging configuration optimized for production"""
    
    log_dir = Path("./logs")
    log_dir.mkdir(exist_ok=True)
    
    # Setup main application logging
    loggers = setup_logging(
        level="INFO",
        log_file="./logs/app.log",
        json_format=True,
        colored_console=False
    )
    
    # Add error-specific handler
    error_handler = logging.handlers.RotatingFileHandler(
        "./logs/errors.log",
        maxBytes=5 * 1024 * 1024,  # 5MB
        backupCount=10
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(JSONFormatter())
    
    for logger in loggers.values():
        logger.addHandler(error_handler)
    
    return loggers


def setup_development_logging():
    """Setup logging configuration optimized for development"""
    
    return setup_logging(
        level="DEBUG",
        log_file="./logs/dev.log",
        json_format=False,
        colored_console=True
    )


def get_logger(name: str) -> logging.Logger:
    """Get a logger instance with the specified name"""
    return logging.getLogger(name)


# Global logger instances
episode_logger = EpisodeLogger()
training_logger = TrainingLogger()

# Setup based on environment
env = os.getenv("FLASK_ENV", "development")
if env == "production":
    loggers = setup_production_logging()
else:
    loggers = setup_development_logging()

# Export commonly used loggers
app_logger = loggers['app']
rag_logger = loggers['rag']
training_logger_std = loggers['training']
embedding_logger = loggers['embedding']